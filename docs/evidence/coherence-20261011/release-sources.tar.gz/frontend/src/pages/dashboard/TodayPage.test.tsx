import { act, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { beforeEach, describe, expect, it, vi } from 'vitest';

import { newAuth } from '@/lib/auth_new';
import { LEAD_JOURNEY_STORAGE_KEY } from '@/lib/leadJourney';
import { TodayPage } from './TodayPage';

const languageMock = vi.hoisted(() => ({ current: 'ru' }));

vi.mock('@/lib/auth_new', () => ({ newAuth: { makeRequest: vi.fn() } }));
vi.mock('@/i18n/LanguageContext.logic', () => ({ useLanguage: () => ({ language: languageMock.current }) }));

const ContextRoute = () => <Outlet context={{ currentBusinessId: 'business-1' }} />;
const NetworkContextRoute = () => <Outlet context={{ currentBusinessId: 'business-1', controlScope: { kind: 'network', id: 'network-1', name: 'Сеть' } }} />;
const renderPage = () => render(<MemoryRouter><Routes><Route element={<ContextRoute />}><Route index element={<TodayPage />} /></Route></Routes></MemoryRouter>);
const LocationProbe = () => {
  const location = useLocation();
  return <div>{`${location.pathname}${location.search}`}</div>;
};

describe('TodayPage', () => {
  beforeEach(() => {
    vi.mocked(newAuth.makeRequest).mockReset();
    languageMock.current = 'ru';
    window.localStorage.clear();
  });

  it.each([false, true])('keeps the chosen direction one click away when only other work exists (urgent=%s)', async (urgent) => {
    const otherWork = { id: 'review-1', title: 'Ответьте на отзыв', flow: 'maps', urgency: urgent ? 'urgent' : 'normal', action: { label: 'Открыть отзыв', url: '/dashboard/card?tab=reviews' } };
    vi.mocked(newAuth.makeRequest).mockResolvedValue({
      preference: { scope_type: 'business', scope_id: 'business-1', primary_flow: 'influencers', suggestions_enabled: true, revision: 1 },
      focus_action: { title: 'Обновите финансовые данные', screen: 'finance' },
      work_sections: { needs_decision: urgent ? [otherWork] : [], continue_work: urgent ? [] : [otherWork], results: [] },
    });
    render(<MemoryRouter initialEntries={['/dashboard/today']}><Routes><Route element={<ContextRoute />}>
      <Route path="/dashboard/today" element={<TodayPage />} />
      <Route path="/dashboard/influencers" element={<LocationProbe />} />
    </Route></Routes></MemoryRouter>);
    const action = await screen.findByRole('button', { name: 'Открыть инфлюенсеров' });
    const titles = screen.getAllByRole('heading').map((heading) => heading.textContent);
    expect(titles[1]).toBe('Ответьте на отзыв');
    fireEvent.click(action);
    expect(screen.getByText('/dashboard/influencers')).toBeInTheDocument();
  });

  it('ignores an unbound registration direction from a different business', async () => {
    window.localStorage.setItem(LEAD_JOURNEY_STORAGE_KEY, 'maps');
    vi.mocked(newAuth.makeRequest).mockResolvedValue({ active_work: [], changes_24h: [], completed_results: [] });

    render(
      <MemoryRouter initialEntries={['/dashboard/today']}>
        <Routes>
          <Route element={<ContextRoute />}>
            <Route path="/dashboard/today" element={<TodayPage />} />
            <Route path="/dashboard/progress" element={<LocationProbe />} /><Route path="/dashboard/content" element={<LocationProbe />} />
          </Route>
        </Routes>
      </MemoryRouter>,
    );

    expect(await screen.findByRole('heading', { name: 'Подготовьте следующий материал' })).toBeInTheDocument();
    expect(screen.queryByText('Проверьте карточку на картах')).not.toBeInTheDocument();
    expect(screen.queryByText('Вы выбрали до регистрации')).not.toBeInTheDocument();
    expect(screen.queryByText(/зафиксирует статус или результат/)).not.toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: 'Открыть контент' }));
    expect(screen.getByText('/dashboard/content')).toBeInTheDocument();
  });

  it('keeps a loading state until the operational summary is available', async () => {
    let resolveRequest: (value: unknown) => void = () => undefined;
    vi.mocked(newAuth.makeRequest).mockReturnValue(new Promise((resolve) => { resolveRequest = resolve; }));
    renderPage();
    expect(screen.getByText('Загружаем новые события и текущие задачи.')).toBeInTheDocument();
    resolveRequest({ active_work: [], changes_24h: [], completed_results: [] });
    await screen.findByText('В доступных данных нет начатых задач.');
  });

  it('shows an evidence-led empty state without inventing changes or active work', async () => {
    vi.mocked(newAuth.makeRequest).mockResolvedValue({ active_work: [], changes_24h: [], completed_results: [] });
    renderPage();
    expect(await screen.findByText('В доступных данных нет начатых задач.')).toBeInTheDocument();
    expect(screen.queryByRole('heading', { name: 'Что изменилось' })).not.toBeInTheDocument();
    expect(screen.queryByText('Что LocalOS делает сейчас')).not.toBeInTheDocument();
    expect(screen.queryByText('1. Действие')).not.toBeInTheDocument();
    expect(screen.getAllByRole('button', { name: 'Посмотреть результаты' })).toHaveLength(1);
    expect(screen.getByRole('heading', { name: 'Нужно ваше решение' })).toBeInTheDocument();
  });

  it('uses a single-column-first responsive layout for narrow screens', async () => {
    vi.mocked(newAuth.makeRequest).mockResolvedValue({
      active_work: [{ id: 'work-1', title: 'Подготовить ответ' }],
      changes_24h: [{ id: 'change-1', title: 'Получен отзыв' }],
      completed_results: [],
    });
    const { container } = renderPage();
    await waitFor(() => expect(screen.getByText('Что изменилось')).toBeInTheDocument());
    expect(container.querySelector('.lg\\:grid-cols-2')).not.toBeInTheDocument();
  });

  it('keeps external changes separate from LocalOS results', async () => {
    vi.mocked(newAuth.makeRequest).mockResolvedValue({
      active_work: [],
      changes_24h: [{ id: 'change-1', title: 'Получен новый отзыв' }],
      completed_results: [{ id: 'result-1', title: 'Публикация подтверждена', status: 'published', screen: 'content', occurred_at: '2026-10-11T10:00:00Z' }],
    });
    renderPage();

    expect(await screen.findByText('Получен новый отзыв')).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: 'Завершено' })).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: 'Публикация подтверждена' })).toBeInTheDocument();
  });

  it('does not say there is no work while a primary decision is on screen', async () => {
    vi.mocked(newAuth.makeRequest).mockResolvedValue({
      work_sections: { needs_decision: [{ id: 'decision-1', title: 'Подтвердите черновик', description: 'Проверьте условия.' }], continue_work: [], results: [] },
      active_work: [], changes_24h: [], completed_results: [],
    });
    renderPage();
    expect(await screen.findByRole('heading', { name: 'Подтвердите черновик' })).toBeInTheDocument();
    expect(screen.queryByText('Сейчас у LocalOS нет активных задач.')).not.toBeInTheDocument();
    expect(screen.getByText('Следующий шаг показан выше. Других записей в этом разделе нет.')).toBeInTheDocument();
    expect(screen.queryByText('В доступных данных нет задач, ожидающих вашего решения.')).not.toBeInTheDocument();
  });

  it('shows the static decision heading and instruction in Spanish without rewriting API decision text', async () => {
    languageMock.current = 'es';
    vi.mocked(newAuth.makeRequest).mockResolvedValue({
      preference: { scope_type: 'business', scope_id: 'business-1', primary_flow: 'content', suggestions_enabled: true, revision: 1 },
      work_sections: {
        needs_decision: [
          { id: 'decision-primary', title: 'Проверьте подготовленный ответ', description: 'Это подпись из API.' },
          { id: 'decision-follow-up', title: 'Выберите следующий шаг', description: 'Это подпись из API.' },
        ],
        continue_work: [],
        results: [],
      },
      active_work: [], changes_24h: [], completed_results: [],
    });

    renderPage();

    expect(await screen.findByText('Requiere tu decisión')).toBeInTheDocument();
    expect(screen.getByText('Revisa el resultado preparado y elige el siguiente paso.')).toBeInTheDocument();
    expect(screen.getByText('Выберите следующий шаг')).toBeInTheDocument();
    expect(vi.mocked(newAuth.makeRequest)).toHaveBeenCalledTimes(1);
    expect(vi.mocked(newAuth.makeRequest)).toHaveBeenCalledWith('/operator/today?scope_type=business&scope_id=business-1', { method: 'GET' });
  });

  it('shows the priority preference label in Spanish without posting', async () => {
    languageMock.current = 'es';
    vi.mocked(newAuth.makeRequest).mockResolvedValue({
      preference: { scope_type: 'business', scope_id: 'business-1', primary_flow: 'content', suggestions_enabled: true, revision: 1 },
      active_work: [], changes_24h: [], completed_results: [],
    });

    renderPage();

    expect(await screen.findByText('Qué mostrar primero en Hoy: Contenido')).toBeInTheDocument();
    expect(vi.mocked(newAuth.makeRequest)).toHaveBeenCalledTimes(1);
    expect(vi.mocked(newAuth.makeRequest)).toHaveBeenCalledWith('/operator/today?scope_type=business&scope_id=business-1', { method: 'GET' });
  });

  it('localizes coded system work copy without translating titles or changing the deep link', async () => {
    languageMock.current = 'es';
    const target = '/dashboard/agents?blueprint_id=blueprint-1&run_id=run-1&business_id=business-1';
    vi.mocked(newAuth.makeRequest).mockResolvedValue({
      work_sections: {
        needs_decision: [{
          id: 'agent_run:run-1', title: 'Проверка записей на завтра',
          description: 'Результат записи неизвестен. Сверьте таблицу перед следующими действиями.',
          message_code: 'today.automation.provider_reconciliation_required',
          action: { label: 'Открыть', label_code: 'today.open', url: target },
        }, {
          id: 'agent_run:run-2', title: 'Моя вторая задача',
          description: 'Запись требует внимания. Откройте результат, чтобы проверить причину.',
          message_code: 'today.automation.provider_failed',
        }],
        continue_work: [{ id: 'work-3', title: 'Моя работа', description: 'Выполняется запись в таблицу.', message_code: 'today.automation.provider_executing' }],
        results: [{ id: 'result-4', status: 'completed', occurred_at: '2026-10-11T10:00:00Z', screen: 'agents', title: 'Мой результат', description: 'Пользовательский текст без перевода', message_code: 'future.unknown' }],
      },
    });
    render(<MemoryRouter initialEntries={['/dashboard/today']}><Routes><Route element={<ContextRoute />}>
      <Route path="/dashboard/today" element={<TodayPage />} />
      <Route path="/dashboard/agents" element={<LocationProbe />} />
    </Route></Routes></MemoryRouter>);

    expect(await screen.findByRole('heading', { name: 'Проверка записей на завтра' })).toBeInTheDocument();
    expect(screen.getByText('Se desconoce el resultado de la escritura. Revisa la hoja antes de continuar.')).toBeInTheDocument();
    expect(screen.getByText('La escritura requiere atención. Abre el resultado para comprobar la causa.')).toBeInTheDocument();
    expect(screen.getByText('Se está escribiendo en la hoja.')).toBeInTheDocument();
    expect(screen.getByText('Пользовательский текст без перевода')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Revisar' }));
    expect(screen.getByText(target)).toBeInTheDocument();
    expect(newAuth.makeRequest).toHaveBeenCalledTimes(1);
    expect(newAuth.makeRequest).toHaveBeenCalledWith('/operator/today?scope_type=business&scope_id=business-1', { method: 'GET' });
  });

  it.each([undefined, 'future.action', 'toString'])('preserves uncoded or unknown action labels (%s)', async (labelCode) => {
    languageMock.current = 'es';
    vi.mocked(newAuth.makeRequest).mockResolvedValue({ work_sections: { needs_decision: [{
      id: 'legacy', title: 'Моя задача', description: 'Неизвестное описание', message_code: 'toString',
      action: { label: 'Моя кнопка', label_code: labelCode, url: '/dashboard/content' },
    }] } });
    renderPage();
    expect(await screen.findByRole('button', { name: 'Моя кнопка' })).toBeInTheDocument();
    expect(screen.getByText('Неизвестное описание')).toBeInTheDocument();
  });

  it('shows empty preferred content in Spanish and keeps its route navigation free of requests', async () => {
    languageMock.current = 'es';
    vi.mocked(newAuth.makeRequest).mockResolvedValue({
      preference: { scope_type: 'business', scope_id: 'business-1', primary_flow: 'content', suggestions_enabled: true, revision: 1 },
      active_work: [], changes_24h: [], completed_results: [],
    });

    render(
      <MemoryRouter initialEntries={['/dashboard/today']}>
        <Routes>
          <Route element={<ContextRoute />}>
            <Route path="/dashboard/today" element={<TodayPage />} />
            <Route path="/dashboard/content" element={<LocationProbe />} />
          </Route>
        </Routes>
      </MemoryRouter>,
    );

    expect(await screen.findByRole('heading', { name: 'Prepara el siguiente contenido' })).toBeInTheDocument();
    expect(screen.getByText('Abre tu plan de contenido, crea un borrador o continúa con un contenido ya iniciado.')).toBeInTheDocument();
    expect(vi.mocked(newAuth.makeRequest)).toHaveBeenCalledTimes(1);
    expect(vi.mocked(newAuth.makeRequest)).toHaveBeenCalledWith('/operator/today?scope_type=business&scope_id=business-1', { method: 'GET' });

    fireEvent.click(screen.getByRole('button', { name: 'Abrir contenido' }));

    expect(screen.getByText('/dashboard/content')).toBeInTheDocument();
    expect(vi.mocked(newAuth.makeRequest)).toHaveBeenCalledTimes(1);
  });

  it.each([
    ['content', 'Подготовьте следующий материал', 'Открыть контент'],
    ['influencers', 'Продолжите работу с инфлюенсерами', 'Открыть инфлюенсеров'],
    ['automation', 'Проверьте автоматизацию', 'Открыть автоматизацию'],
  ])('gives an empty %s priority a direct next action', async (primaryFlow, title, button) => {
    vi.mocked(newAuth.makeRequest).mockResolvedValue({
      preference: { scope_type: 'business', scope_id: 'business-1', primary_flow: primaryFlow, suggestions_enabled: true, revision: 1 },
      active_work: [], changes_24h: [], completed_results: [],
    });
    renderPage();

    expect(await screen.findByRole('heading', { name: title })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: button })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Открыть прогресс' })).not.toBeInTheDocument();
  });

  it('opens the influencer workspace from its empty-priority action', async () => {
    vi.mocked(newAuth.makeRequest).mockResolvedValue({
      preference: { scope_type: 'business', scope_id: 'business-1', primary_flow: 'influencers', suggestions_enabled: true, revision: 1 },
      active_work: [], changes_24h: [], completed_results: [],
    });
    render(
      <MemoryRouter initialEntries={['/dashboard/today']}>
        <Routes>
          <Route element={<ContextRoute />}>
            <Route path="/dashboard/today" element={<TodayPage />} />
            <Route path="/dashboard/influencers" element={<LocationProbe />} />
          </Route>
        </Routes>
      </MemoryRouter>,
    );

    fireEvent.click(await screen.findByRole('button', { name: 'Открыть инфлюенсеров' }));
    expect(screen.getByText('/dashboard/influencers')).toBeInTheDocument();
  });

  it('keeps the target publication when opening a story-facts action', async () => {
    vi.mocked(newAuth.makeRequest).mockResolvedValue({
      focus_action: {
        id: 'content_story_facts:item-1',
        title: 'Добавьте факты для истории',
        reason: 'Для истории не хватает реального эпизода.',
        expected_outcome: 'После фактов LocalOS подготовит текст.',
        cta_label: 'Добавить факты',
        screen: 'content',
        plan_id: 'plan-1',
        item_id: 'item-1',
      },
      active_work: [],
      changes_24h: [],
      completed_results: [],
    });

    render(
      <MemoryRouter initialEntries={['/dashboard/today']}>
        <Routes>
          <Route element={<ContextRoute />}>
            <Route path="/dashboard/today" element={<TodayPage />} />
            <Route path="/dashboard/content" element={<LocationProbe />} />
          </Route>
        </Routes>
      </MemoryRouter>,
    );

    fireEvent.click(await screen.findByRole('button', { name: 'Добавить факты' }));

    expect(screen.getByText('/dashboard/content?plan_id=plan-1&item_id=item-1&focus=story_facts')).toBeInTheDocument();
  });

  it('opens unanswered reviews with the unanswered filter preserved', async () => {
    vi.mocked(newAuth.makeRequest).mockResolvedValue({
      focus_action: {
        id: 'reviews_unanswered',
        title: 'Ответьте на отзывы без ответа',
        reason: 'Клиенты ждут ответа.',
        expected_outcome: 'Все новые отзывы будут обработаны.',
        cta_label: 'Открыть отзывы без ответа',
        screen: 'reviews',
      },
      active_work: [],
      changes_24h: [],
      completed_results: [],
    });

    render(
      <MemoryRouter initialEntries={['/dashboard/today']}>
        <Routes>
          <Route element={<ContextRoute />}>
            <Route path="/dashboard/today" element={<TodayPage />} />
            <Route path="/dashboard/card" element={<LocationProbe />} />
          </Route>
        </Routes>
      </MemoryRouter>,
    );

    fireEvent.click(await screen.findByRole('button', { name: 'Открыть отзывы без ответа' }));

    expect(screen.getByText('/dashboard/card?tab=reviews&review_filter=needs_reply')).toBeInTheDocument();
  });

  it('does not show an empty generic outcome for an operator task', async () => {
    vi.mocked(newAuth.makeRequest).mockResolvedValue({
      focus_action: {
        id: 'reviews_unanswered',
        title: 'Отзывы без ответа',
        reason: 'Есть новые отзывы.',
        expected_outcome: '',
        cta_label: 'Открыть задачу',
        screen: 'reviews',
      },
      active_work: [],
      changes_24h: [],
      completed_results: [],
    });

    renderPage();

    expect(await screen.findByRole('heading', { name: 'Отзывы без ответа' })).toBeInTheDocument();
    expect(screen.queryByText('После этого:')).not.toBeInTheDocument();
  });

  it('puts an urgent decision ahead of a finance focus and does not duplicate it below', async () => {
    vi.mocked(newAuth.makeRequest).mockResolvedValue({
      focus_action: { title: 'Обновите финансовые данные', reason: 'Нет сводки', cta_label: 'Загрузить данные', screen: 'finance' },
      work_sections: { needs_decision: [{ id: 'urgent-1', title: 'Подтвердите ответ клиенту', description: 'Сообщение ждёт решения', urgency: 'urgent', action: { label: 'Проверить', url: '/dashboard/card?review=1' } }], continue_work: [], results: [] },
      active_work: [], changes_24h: [], completed_results: [],
    });
    renderPage();
    expect(await screen.findByRole('heading', { name: 'Подтвердите ответ клиенту' })).toBeInTheDocument();
    expect(screen.getAllByText('Подтвердите ответ клиенту')).toHaveLength(1);
  });

  it('keeps preference controls behind settings and sends the scoped revision', async () => {
    vi.mocked(newAuth.makeRequest)
      .mockResolvedValueOnce({ preference: { scope_type: 'business', scope_id: 'business-1', primary_flow: 'overview', suggestions_enabled: true, revision: 4, available_flows: ['overview', 'content'] }, active_work: [], changes_24h: [], completed_results: [] })
      .mockResolvedValueOnce({ preference: { scope_type: 'business', scope_id: 'business-1', primary_flow: 'content', suggestions_enabled: true, revision: 5 } });
    renderPage();
    expect(await screen.findByText('Что показывать первым на «Сегодня»: Обзор')).toBeInTheDocument();
    expect(screen.getByText('Что показывать первым на «Сегодня»: Обзор').closest('details')).not.toHaveAttribute('open');
    fireEvent.click(screen.getByText('Что показывать первым на «Сегодня»: Обзор'));
    fireEvent.click(screen.getByRole('button', { name: 'Контент' }));
    await waitFor(() => expect(vi.mocked(newAuth.makeRequest)).toHaveBeenLastCalledWith('/operator/today/preference?scope_type=business&scope_id=business-1', { method: 'POST', body: JSON.stringify({ action: 'set', expected_revision: 4, primary_flow: 'content' }) }));
  });

  it('clears a previously loaded overview when the current scope becomes unavailable', async () => {
    const forbidden = Object.assign(new Error('Доступ отозван'), { status: 403 });
    vi.mocked(newAuth.makeRequest)
      .mockResolvedValueOnce({ active_work: [{ id: 'private-work', title: 'Закрытая задача' }], changes_24h: [], completed_results: [] })
      .mockRejectedValueOnce(forbidden);
    renderPage();

    expect(await screen.findByText('Закрытая задача')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Обновить' }));

    expect(await screen.findByText('Страница временно недоступна')).toBeInTheDocument();
    expect(screen.queryByText('Закрытая задача')).not.toBeInTheDocument();
  });

  it('keeps a confirmed overview visible after a transient refresh failure', async () => {
    const unavailable = Object.assign(new Error('Сервис временно недоступен'), { status: 503 });
    vi.mocked(newAuth.makeRequest)
      .mockResolvedValueOnce({ active_work: [{ id: 'work-1', title: 'Продолжить контент' }], changes_24h: [], completed_results: [] })
      .mockRejectedValueOnce(unavailable);
    renderPage();

    expect(await screen.findByText('Продолжить контент')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Обновить' }));

    expect(await screen.findByRole('status')).toHaveTextContent('Попробуйте ещё раз');
    expect(screen.getByText('Продолжить контент')).toBeInTheDocument();
  });

  it('refreshes scoped work after a priority choice while urgent work remains first', async () => {
    vi.mocked(newAuth.makeRequest)
      .mockResolvedValueOnce({
        preference: { scope_type: 'business', scope_id: 'business-1', primary_flow: 'content', suggestions_enabled: true, revision: 4, available_flows: ['content', 'influencers'] },
        work_sections: {
          needs_decision: [{ id: 'urgent-1', title: 'Подтвердите договор', urgency: 'urgent' }],
          continue_work: [{ id: 'content-1', title: 'Продолжить контент' }],
          results: [],
        },
        changes_24h: [], completed_results: [],
      })
      .mockResolvedValueOnce({ preference: { scope_type: 'business', scope_id: 'business-1', primary_flow: 'influencers', suggestions_enabled: true, revision: 5 } })
      .mockResolvedValueOnce({
        preference: { scope_type: 'business', scope_id: 'business-1', primary_flow: 'influencers', suggestions_enabled: true, revision: 5, available_flows: ['content', 'influencers'] },
        work_sections: {
          needs_decision: [{ id: 'urgent-1', title: 'Подтвердите договор', urgency: 'urgent' }],
          continue_work: [{ id: 'influencer-1', title: 'Согласуйте инфлюенсера' }],
          results: [],
        },
        changes_24h: [], completed_results: [],
      });
    renderPage();

    expect(await screen.findByRole('heading', { name: 'Подтвердите договор' })).toBeInTheDocument();
    fireEvent.click(screen.getByText('Что показывать первым на «Сегодня»: Контент'));
    fireEvent.click(screen.getByRole('button', { name: 'Инфлюенсеры' }));

    expect(await screen.findByText('Согласуйте инфлюенсера')).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: 'Подтвердите договор' })).toBeInTheDocument();
    expect(screen.queryByText('Продолжить контент')).not.toBeInTheDocument();
  });

  it('removes a proposal when the preference response explicitly returns null', async () => {
    vi.mocked(newAuth.makeRequest)
      .mockResolvedValueOnce({
        preference: { scope_type: 'business', scope_id: 'business-1', primary_flow: 'content', suggestions_enabled: true, revision: 4 },
        priority_proposal: { id: 'proposal-1', flow: 'influencers', active_days: 3, confirmed_actions: 5, reason_code: 'activity_shift' },
        active_work: [], changes_24h: [], completed_results: [],
      })
      .mockResolvedValueOnce({
        preference: { scope_type: 'business', scope_id: 'business-1', primary_flow: 'content', suggestions_enabled: true, revision: 5 },
        priority_proposal: null,
      })
      .mockResolvedValueOnce({
        preference: { scope_type: 'business', scope_id: 'business-1', primary_flow: 'content', suggestions_enabled: true, revision: 5 },
        priority_proposal: null,
        active_work: [], changes_24h: [], completed_results: [],
      });
    renderPage();

    expect(await screen.findByText(/Вы стали чаще работать с/)).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Не сейчас' }));

    await waitFor(() => expect(screen.queryByText(/Вы стали чаще работать с/)).not.toBeInTheDocument());
  });

  it('does not let a late response from the previous scope overwrite the selected business', async () => {
    let resolveFirst = (_value: unknown) => undefined;
    let resolveSecond = (_value: unknown) => undefined;
    const firstRequest = new Promise((resolve) => { resolveFirst = resolve; });
    const secondRequest = new Promise((resolve) => { resolveSecond = resolve; });
    vi.mocked(newAuth.makeRequest)
      .mockImplementationOnce(() => firstRequest)
      .mockImplementationOnce(() => secondRequest);
    const page = (businessId: string) => (
      <MemoryRouter>
        <Routes>
          <Route element={<Outlet context={{ currentBusinessId: businessId }} />}>
            <Route index element={<TodayPage />} />
          </Route>
        </Routes>
      </MemoryRouter>
    );
    const view = render(page('business-1'));
    await waitFor(() => expect(vi.mocked(newAuth.makeRequest)).toHaveBeenCalledTimes(1));
    view.rerender(page('business-2'));
    await waitFor(() => expect(vi.mocked(newAuth.makeRequest)).toHaveBeenCalledTimes(2));

    await act(async () => { resolveSecond({ active_work: [{ id: 'second-work', title: 'Задача второго бизнеса' }], changes_24h: [], completed_results: [] }); });
    expect(await screen.findByText('Задача второго бизнеса')).toBeInTheDocument();
    await act(async () => { resolveFirst({ active_work: [{ id: 'first-work', title: 'Закрытая задача первого бизнеса' }], changes_24h: [], completed_results: [] }); });

    expect(screen.getByText('Задача второго бизнеса')).toBeInTheDocument();
    expect(screen.queryByText('Закрытая задача первого бизнеса')).not.toBeInTheDocument();
  });

  it('loads the neutral today endpoint for the selected network scope', async () => {
    vi.mocked(newAuth.makeRequest).mockResolvedValue({ active_work: [], changes_24h: [], completed_results: [] });
    render(<MemoryRouter><Routes><Route element={<NetworkContextRoute />}><Route index element={<TodayPage />} /></Route></Routes></MemoryRouter>);
    await screen.findByText('В доступных данных нет начатых задач.');
    expect(vi.mocked(newAuth.makeRequest)).toHaveBeenCalledWith('/operator/today?scope_type=network&scope_id=network-1', { method: 'GET' });
  });

  it('explains data, results, and the next action without abstract product language', async () => {
    vi.mocked(newAuth.makeRequest).mockResolvedValue({
      focus_action: {
        title: 'Обновите финансовые данные',
        reason: 'Нет финансовых данных для аналитики.',
        expected_outcome: 'LocalOS сможет показать актуальную финансовую картину и точки роста.',
        cta_label: 'Загрузить данные',
      },
      data_rhythm: { coverage: 25, completed_periods_8w: 2 },
      analytics_modules: [{ key: 'trend', label: 'Динамика и доказательные рекомендации', status: 'locked' }],
      active_work: [],
      changes_24h: [],
      completed_results: [{ id: 'result-1', title: 'Контент-план создан', source: 'Прогресс LocalOS' }],
      community_pulse: [{ id: 'pulse-1', title: 'Вопрос из Telegram' }],
      data_health: { status: 'missing', source: 'unknown', missing: ['продажи'] },
    });
    const { container } = renderPage();

    expect(await screen.findByText('Финансовая сводка ещё не загружена.')).toBeInTheDocument();
    expect(screen.getByText(/После загрузки здесь появятся выручка/).closest('details')).not.toHaveAttribute('open');
    expect(screen.getByText('Данные для анализа')).toBeInTheDocument();
    expect(screen.getByText('Данные для анализа').closest('details')).not.toHaveAttribute('open');
    expect(screen.getByText('Сравнение показателей по неделям: загрузите сводку')).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: 'Завершено' })).toBeInTheDocument();
    expect(screen.queryByText('Контент-план создан')).not.toBeInTheDocument();
    expect(screen.queryByText('Что обсуждают в ваших источниках')).not.toBeInTheDocument();
    expect(screen.getByText('Источник финансовых данных:', { exact: false })).toBeInTheDocument();
    expect(screen.getByText('Источник не указан', { exact: false })).toBeInTheDocument();
    expect(container.textContent).not.toMatch(/выбранного контура|ритм данных|финансовую картину|точки роста|доказательные рекомендации|пульс сообщества|путь роста/i);
  });
});
