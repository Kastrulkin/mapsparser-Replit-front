import { workCoherenceCopy } from '@/i18n/workCoherenceCopy';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { useLatestCallback } from '@/hooks/useLatestCallback';
import { useLanguage } from '@/i18n/LanguageContext.logic';
import { chatDateLocale, getChatsWorkspaceCopy } from '@/i18n/chatsWorkspaceCopy';
import { newAuth } from '@/lib/auth_new';
import { browserAuthenticationAvailable } from '@/lib/browserSessionFetch';
import { errorMessage } from '@/lib/errorMessage';
import { Bot, FlaskConical, Pause, Play, Send, User as UserIcon } from 'lucide-react';
import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { useOutletContext } from 'react-router-dom';

interface Conversation {
  id: string;
  client_phone: string;
  client_name: string | null;
  current_state: string;
  last_message_at: string;
  is_agent_paused: number;
  unread_count?: number;
}

interface Message {
  id: string;
  content: string;
  sender: 'client' | 'agent' | 'operator';
  message_type: string;
  created_at: string;
}

interface AgentInfo {
  id: string;
  name: string;
  type: 'marketing' | 'booking';
  description: string | null;
}

interface SandboxMessage {
  role: 'user' | 'assistant';
  content: string;
  meta?: {
    runtime?: string;
    state?: string;
    decisionTrace?: unknown;
    toolCalls?: unknown[];
    bridgeError?: string | null;
  };
}

export const ChatsPage: React.FC = () => {
 const { currentBusinessId } = useOutletContext<{ currentBusinessId: string }>();
 return <ChatsWorkspace key={currentBusinessId} />;
};
export const EmployeeChatTest = () => {
 const { currentBusinessId } = useOutletContext<{ currentBusinessId: string }>();
 return <ChatsWorkspace key={currentBusinessId} testing />;
};
const ChatsWorkspace = ({ testing = false }: { testing?: boolean }) => {
  const { currentBusinessId } = useOutletContext<{ currentBusinessId: string }>();
  const [agents, setAgents] = useState<AgentInfo[]>([]);
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [sandboxMessages, setSandboxMessages] = useState<SandboxMessage[]>([]);
  const [sandboxInput, setSandboxInput] = useState('');
  const [sandboxLoading, setSandboxLoading] = useState(false);
  const [workspaceMode, setWorkspaceMode] = useState<'dialogs' | 'agent' | 'outreach'>(testing ? 'agent' : 'dialogs');
  const selectedScope = useRef({ agent: selectedAgentId, conversation: selectedConversationId });
  selectedScope.current = { agent: selectedAgentId, conversation: selectedConversationId };
  const lifetime = useRef({ active: true });
  const [sourceError, setSourceError] = useState('');
  useLayoutEffect(() => { const token = { active: true }; lifetime.current = token; return () => { token.active = false; }; }, []);
  const isSandbox = workspaceMode === 'agent';
  const { toast } = useToast();
  const { language, t } = useLanguage();
  const copy = getChatsWorkspaceCopy(language);
  const messagesEndRef = useRef<HTMLDivElement>(null);







  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const loadAgents = useLatestCallback(async () => {
    const requestScope = lifetime.current;
    try {
      const token = await newAuth.getToken();
      if (!browserAuthenticationAvailable(token)) return;

      const response = await fetch(`/api/business/${currentBusinessId}/ai-agents`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!requestScope.active) return;
      if (response.ok) {
        const data = await response.json();
        if (!requestScope.active) return;
        if (data.success && data.agents) {
          setAgents(data.agents);
          if (data.agents.length > 0 && !selectedAgentId) {
            setSelectedAgentId(data.agents[0].id);
          }
        }
      }
      if (!response.ok) { if ([401,403,404].includes(response.status)) { setAgents([]); setConversations([]); setMessages([]); setSelectedAgentId(null); setSelectedConversationId(null); } setSourceError(workCoherenceCopy(language).messagesUnavailable); }
    } catch (error) {
      if (!requestScope.active) return;
      setSourceError(workCoherenceCopy(language).messagesUnavailable);
      console.error('Ошибка загрузки агентов:', error);
    } finally {
      if (requestScope.active) setLoading(false);
    }
  });

  useEffect(() => {
    if (currentBusinessId) {
      loadAgents();
    }
  }, [currentBusinessId, loadAgents]);

  const loadConversations = useLatestCallback(async () => {
    const requestScope = lifetime.current; const agentId = selectedAgentId;
    try {
      const token = await newAuth.getToken();
      if (!browserAuthenticationAvailable(token) || !selectedAgentId) return;

      const response = await fetch(
        `/api/business/${currentBusinessId}/conversations?agent_id=${selectedAgentId}`,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        }
      );

      if (!requestScope.active || selectedScope.current.agent !== agentId) return;
      if (response.ok) {
        const data = await response.json();
        if (!requestScope.active || selectedScope.current.agent !== agentId) return;
        if (data.success) {
          setConversations(data.conversations || []);
        }
      }
      if (!response.ok) { if ([401,403,404].includes(response.status)) { setAgents([]); setConversations([]); setMessages([]); setSelectedAgentId(null); setSelectedConversationId(null); } setSourceError(workCoherenceCopy(language).messagesUnavailable); }
    } catch (error) {
      if (!requestScope.active || selectedScope.current.agent !== agentId) return;
      setSourceError(workCoherenceCopy(language).messagesUnavailable);
      console.error('Ошибка загрузки чатов:', error);
    }
  });

  useEffect(() => {
    if (selectedAgentId && currentBusinessId) {
      loadConversations();
      // Очищаем песочницу при смене агента
      if (isSandbox) {
        setSandboxMessages([]);
      }
    }
  }, [selectedAgentId, currentBusinessId, loadConversations, isSandbox]);

  const loadMessages = useLatestCallback(async () => {
    const requestScope = lifetime.current; const conversationId = selectedConversationId;
    try {
      const token = await newAuth.getToken();
      if (!browserAuthenticationAvailable(token) || !selectedConversationId) return;

      const response = await fetch(
        `/api/conversations/${selectedConversationId}/messages`,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        }
      );

      if (!requestScope.active || selectedScope.current.conversation !== conversationId) return;
      if (response.ok) {
        const data = await response.json();
        if (!requestScope.active || selectedScope.current.conversation !== conversationId) return;
        if (data.success) {
          setMessages(data.messages || []);
        }
      }
      if (!response.ok) { if ([401,403,404].includes(response.status)) { setAgents([]); setConversations([]); setMessages([]); setSelectedAgentId(null); setSelectedConversationId(null); } setSourceError(workCoherenceCopy(language).messagesUnavailable); }
    } catch (error) {
      if (!requestScope.active || selectedScope.current.conversation !== conversationId) return;
      setSourceError(workCoherenceCopy(language).messagesUnavailable);
      console.error('Ошибка загрузки сообщений:', error);
    }
  });

  useEffect(() => {
    // Не загружаем сообщения для песочницы
    if (selectedConversationId && selectedConversationId !== 'sandbox') {
      loadMessages();
      // Автообновление сообщений каждые 3 секунды
      const interval = setInterval(loadMessages, 3000);
      return () => clearInterval(interval);
    }
  }, [loadMessages, selectedConversationId]);

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedConversationId || sending) return;

    const requestScope = lifetime.current;
    try {
      setSending(true);
      const token = await newAuth.getToken();
      if (!browserAuthenticationAvailable(token)) return;

      const response = await fetch(
        `/api/conversations/${selectedConversationId}/send-message`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: newMessage,
            sender: 'operator',
          }),
        }
      );

      if (!requestScope.active) return;
      if (response.ok) {
        setNewMessage('');
        await loadMessages();
        toast({
          title: t.common.success,
          description: t.dashboard.chats.messages.sent,
        });
      } else {
        throw new Error('Ошибка отправки сообщения');
      }
    } catch (error: unknown) {
      if (!requestScope.active) return;
      toast({
        title: t.common.error,
        description: errorMessage(error) || t.dashboard.chats.messages.error,
        variant: 'destructive',
      });
    } finally {
      if (requestScope.active) setSending(false);
    }
  };

  const handleToggleAgent = async (conversationId: string, pause: boolean) => {
    try {
      const token = await newAuth.getToken();
      if (!browserAuthenticationAvailable(token)) return;

      const response = await fetch(
        `/api/conversations/${conversationId}/toggle-agent`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ pause }),
        }
      );

      if (response.ok) {
        await loadConversations();
        if (conversationId === selectedConversationId) {
          await loadMessages();
        }
        toast({
          title: t.common.success,
          description: pause ? t.dashboard.chats.messages.agentPaused : t.dashboard.chats.messages.agentResumed,
        });
      }
    } catch (error: unknown) {
      toast({
        title: t.common.error,
        description: t.dashboard.chats.messages.statusError,
        variant: 'destructive',
      });
    }
  };

  const selectedConversation = conversations.find(c => c.id === selectedConversationId);
  const selectedAgent = agents.find(a => a.id === selectedAgentId);

  const handleSandboxSend = async () => {
    if (!sandboxInput.trim() || !selectedAgentId || sandboxLoading) return;

    try {
      setSandboxLoading(true);
      const token = await newAuth.getToken();
      if (!browserAuthenticationAvailable(token)) return;

      // Добавляем сообщение пользователя в историю
      const userMessage = { role: 'user' as const, content: sandboxInput };
      const updatedHistory = [...sandboxMessages, userMessage];
      setSandboxMessages(updatedHistory);
      setSandboxInput('');

      // Формируем историю для отправки
      const conversationHistory = updatedHistory.slice(0, -1).map(msg => ({
        role: msg.role === 'user' ? 'client' : 'agent',
        content: msg.content
      }));

      const response = await fetch(
        `/api/business/${currentBusinessId}/ai-agents/${selectedAgentId}/test`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: sandboxInput,
            conversation_history: conversationHistory,
            dry_run: true,
          }),
        }
      );

      if (response.ok) {
        const data = await response.json();
        if (data.success) {
          // Добавляем ответ агента в историю
          setSandboxMessages([
            ...updatedHistory,
            {
              role: 'assistant',
              content: data.response,
              meta: {
                runtime: data.runtime || 'local',
                state: data.state || '',
                decisionTrace: data.decision_trace || {},
                toolCalls: Array.isArray(data.tool_calls) ? data.tool_calls : [],
                bridgeError: data.bridge_error || null,
              },
            },
          ]);
        } else {
          throw new Error(data.error || t.dashboard.chats.messages.error);
        }
      } else {
        const errorData = await response.json();
        throw new Error(errorData.error || t.dashboard.chats.messages.error);
      }
    } catch (error: unknown) {
      toast({
        title: t.common.error,
        description: errorMessage(error) || t.dashboard.chats.messages.error,
        variant: 'destructive',
      });
      // Удаляем последнее сообщение пользователя при ошибке
      setSandboxMessages(sandboxMessages);
    } finally {
      setSandboxLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="flex h-full min-h-0 flex-col gap-4">
      {sourceError ? <div role="alert"><p className="text-sm text-destructive">{sourceError}</p><Button variant="outline" onClick={() => { setSourceError(''); void loadAgents(); if(selectedAgentId) void loadConversations(); if(selectedConversationId) void loadMessages(); }}>{workCoherenceCopy(language).retry}</Button></div> : null}
      <h1 className="text-2xl font-semibold">{language === 'ru' ? (testing ? 'Проверить диалог сотрудника' : 'Сообщения клиентов') : (testing ? 'Test employee conversation' : 'Customer messages')}</h1>
      <div className="flex min-h-0 flex-1 flex-col gap-4 lg:flex-row">
      {/* Левая панель: Агенты */}
      <div className="w-full shrink-0 bg-white rounded-lg border border-gray-200 p-4 lg:w-64">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">{copy.agents}</h2>
        <div className="space-y-2">
          {agents.map((agent) => (
            <button
              key={agent.id}
              onClick={() => {
                setSelectedAgentId(agent.id);
                setSelectedConversationId(null); setConversations([]); setMessages([]);
              }}
              className={`w-full text-left p-3 rounded-lg border transition-colors ${selectedAgentId === agent.id
                  ? 'bg-blue-50 border-blue-200 text-blue-700'
                  : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                }`}
            >
              <div className="flex items-center gap-2">
                <Bot className="w-4 h-4" />
                <div className="flex-1">
                  <div className="font-medium">{agent.type === 'booking' ? copy.bookingAgent : copy.marketingAgent}</div>
                  <div className="text-xs text-gray-500">
                    {agent.type === 'marketing' ? copy.marketingAgent : copy.bookingAgent}
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Средняя панель: Список чатов */}
      <div className={`w-full shrink-0 bg-white rounded-lg border border-gray-200 flex-col lg:w-80 ${isSandbox ? 'hidden lg:flex' : 'flex'}`}>
        <div className="p-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">
            {selectedAgent ? `${copy.chats}: ${selectedAgent.type === 'booking' ? copy.bookingAgent : copy.marketingAgent}` : copy.chats}
          </h2>
        </div>
        <ScrollArea className="flex-1">
          <div className="p-2">
            {conversations.length === 0 ? sourceError ? null : (
              <div className="text-center text-gray-500 py-8">
                {copy.noChats}
              </div>
            ) : (
              conversations.map((conv) => (
                <button
                  key={conv.id}
                  onClick={() => {setSelectedConversationId(conv.id); setMessages([]);}}
                  className={`w-full text-left p-3 rounded-lg border mb-2 transition-colors ${selectedConversationId === conv.id
                      ? 'bg-blue-50 border-blue-200'
                      : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                    }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-gray-900 truncate">
                        {conv.client_name || conv.client_phone}
                      </div>
                      <div className="text-xs text-gray-500">
                        {new Date(conv.last_message_at).toLocaleString(chatDateLocale[language])}
                      </div>
                    </div>
                    {conv.is_agent_paused === 1 && (
                      <Pause className="w-4 h-4 text-orange-500" />
                    )}
                  </div>
                </button>
              ))
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Правая панель: Детали чата */}
      <div className="min-h-[28rem] flex-1 bg-white rounded-lg border border-gray-200 flex flex-col">
        {isSandbox ? (
          <>
            <div className="p-4 border-b border-gray-200 flex items-center gap-2">
              <FlaskConical className="w-5 h-5 text-purple-500" />
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{copy.sandboxTitle}</h3>
                <div className="text-sm text-gray-500">
                  {copy.sandboxSubtitle}: {selectedAgent ? (selectedAgent.type === 'booking' ? copy.bookingAgent : copy.marketingAgent) : copy.noAgent}
                </div>
              </div>
            </div>

            <div className="mx-4 mt-4 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
              <div className="font-medium">{copy.dryRunTitle}</div>
              <div>{copy.dryRunDescription}</div>
            </div>

            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {sandboxMessages.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    {copy.sandboxEmpty}
                  </div>
                ) : (
                  sandboxMessages.map((msg, idx) => (
                    <div
                      key={idx}
                      className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'
                        }`}
                    >
                      <div
                        className={`max-w-[70%] rounded-lg p-3 ${msg.role === 'user'
                            ? 'bg-blue-100 text-blue-900'
                            : 'bg-green-100 text-green-900'
                          }`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          {msg.role === 'user' ? (
                            <UserIcon className="w-4 h-4" />
                          ) : (
                            <Bot className="w-4 h-4" />
                          )}
                          <span className="text-xs font-medium">
                            {msg.role === 'user' ? copy.user : copy.agent}
                          </span>
                        </div>
                        <div className="text-sm whitespace-pre-wrap">{msg.content}</div>
                        {msg.role === 'assistant' && msg.meta && (
                          <div className="mt-2 rounded border border-green-200 bg-white/70 p-2 text-xs">
                            <div className="text-[11px] text-gray-600">
                              runtime: <span className="font-medium text-gray-800">{msg.meta.runtime || 'local'}</span>
                              {msg.meta.state ? `, state: ${msg.meta.state}` : ''}
                            </div>
                            {msg.meta.bridgeError ? (
                              <div className="mt-1 text-[11px] text-amber-700">
                                bridge fallback: {msg.meta.bridgeError}
                              </div>
                            ) : null}
                            {msg.meta.toolCalls && msg.meta.toolCalls.length > 0 ? (
                              <div className="mt-1 text-[11px] text-gray-700">
                                tool calls: {msg.meta.toolCalls.length}
                              </div>
                            ) : null}
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
                {sandboxLoading && (
                  <div className="flex justify-start">
                    <div className="bg-gray-100 rounded-lg p-3">
                      <div className="flex items-center gap-2">
                        <Bot className="w-4 h-4" />
                        <span className="text-xs font-medium">{copy.agentTyping}</span>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            <div className="p-4 border-t border-gray-200">
              <div className="flex gap-2">
                <Input
                  value={sandboxInput}
                  onChange={(e) => setSandboxInput(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSandboxSend();
                    }
                  }}
                  placeholder={copy.sandboxPlaceholder}
                  disabled={sandboxLoading || !selectedAgentId}
                />
                <Button variant="product"
                  onClick={handleSandboxSend}
                  disabled={sandboxLoading || !sandboxInput.trim() || !selectedAgentId}
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              {!selectedAgentId && (
                <div className="text-xs text-orange-600 mt-2">
                  {copy.noAgent}
                </div>
              )}
            </div>
          </>
        ) : selectedConversation ? (
          <>
            <div className="p-4 border-b border-gray-200 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">
                  {selectedConversation.client_name || selectedConversation.client_phone}
                </h3>
                <div className="text-sm text-gray-500">
                  {selectedConversation.client_phone}
                </div>
              </div>
              <div className="flex items-center gap-2">
                {selectedConversation.is_agent_paused === 1 ? (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleToggleAgent(selectedConversation.id, false)}
                  >
                    <Play className="w-4 h-4 mr-2" />
                    {t.dashboard.chats.controls.resume}
                  </Button>
                ) : (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleToggleAgent(selectedConversation.id, true)}
                  >
                    <Pause className="w-4 h-4 mr-2" />
                    {t.dashboard.chats.controls.pause}
                  </Button>
                )}
              </div>
            </div>

            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.sender === 'client' ? 'justify-start' : 'justify-end'
                      }`}
                  >
                    <div
                      className={`max-w-[70%] rounded-lg p-3 ${msg.sender === 'client'
                          ? 'bg-gray-100 text-gray-900'
                          : msg.sender === 'operator'
                            ? 'bg-blue-100 text-blue-900'
                            : 'bg-green-100 text-green-900'
                        }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        {msg.sender === 'client' ? (
                          <UserIcon className="w-4 h-4" />
                        ) : msg.sender === 'operator' ? (
                          <UserIcon className="w-4 h-4" />
                        ) : (
                          <Bot className="w-4 h-4" />
                        )}
                        <span className="text-xs font-medium">
                          {msg.sender === 'client'
                            ? t.dashboard.chats.roles.client
                            : msg.sender === 'operator'
                              ? t.dashboard.chats.roles.operator
                              : t.dashboard.chats.roles.agent}
                        </span>
                      </div>
                      <div className="text-sm whitespace-pre-wrap">{msg.content}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(msg.created_at).toLocaleString(chatDateLocale[language])}
                      </div>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            <div className="p-4 border-t border-gray-200">
              <div className="flex gap-2">
                <Input
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  placeholder={t.dashboard.chats.input.placeholder}
                  disabled={sending || selectedConversation.is_agent_paused !== 1}
                />
                <Button variant="product"
                  onClick={handleSendMessage}
                  disabled={sending || !newMessage.trim() || selectedConversation.is_agent_paused !== 1}
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              {selectedConversation.is_agent_paused === 1 && (
                <div className="text-xs text-orange-600 mt-2">
                  {t.dashboard.chats.input.agentPaused}
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500">
            {copy.selectWorkspace}
          </div>
        )}
      </div>
      </div>
    </div>
  );
};
