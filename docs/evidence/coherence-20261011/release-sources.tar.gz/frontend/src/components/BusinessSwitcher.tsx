import { useClickOutside } from '@/hooks/useClickOutside';
import { Building2, ChevronDown, Users } from 'lucide-react';
import React, { useCallback, useEffect, useRef, useState } from 'react';

interface Business {
  id: string;
  name: string;
  description?: string;
  address?: string;
  industry?: string;
  owner_email?: string;
  owner_name?: string;
  network_id?: string;
  network_name?: string;
  created_at?: string;
  moderation_status?: string;
  entity_group?: string;
  is_lead_business?: boolean;
}

interface BusinessSwitcherProps {
  businesses: Business[];
  currentBusinessId?: string;
  onBusinessChange: (businessId: string) => void;
  isSuperadmin: boolean;
}

export const BusinessSwitcher: React.FC<BusinessSwitcherProps> = ({
  businesses,
  currentBusinessId,
  onBusinessChange,
  isSuperadmin
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedBusiness, setSelectedBusiness] = useState<Business | null>(null);
  const switcherRef = useRef<HTMLDivElement | null>(null);
  const closeSwitcher = useCallback(() => setIsOpen(false), []);
  useClickOutside(switcherRef, closeSwitcher, { enabled: isOpen });
  const isLeadBusiness = (business?: Business | null) => {
    const moderationStatus = String(business?.moderation_status || '').trim().toLowerCase();
    const entityGroup = String(business?.entity_group || '').trim().toLowerCase();
    const description = String(business?.description || '').trim().toLowerCase();
    return (
      business?.is_lead_business === true ||
      moderationStatus === 'lead_outreach' ||
      entityGroup === 'lead' ||
      description.startsWith('lead shadow business for outreach lead')
    );
  };
  const visibleBusinesses = React.useMemo(
    () => {
      return businesses.filter((business) => !isLeadBusiness(business));
    },
    [businesses]
  );

  const getBusinessDisplayName = (business: Business) => {
    return String(business.name || '').trim() || 'Без названия';
  };

  useEffect(() => {
    if (visibleBusinesses.length > 0) {
      const current = visibleBusinesses.find((business) => business.id === currentBusinessId);
      if (current) {
        setSelectedBusiness(current);
      } else {
        setSelectedBusiness((selected) => selected || visibleBusinesses[0]);
      }
    }
  }, [businesses, visibleBusinesses, currentBusinessId]);

  const handleBusinessSelect = (business: Business) => {
    setSelectedBusiness(business);
    onBusinessChange(business.id);
    setIsOpen(false);
  };

  const hasBusinesses = visibleBusinesses.length > 0;

  return (
    <div ref={switcherRef} className="relative min-w-0 shrink-0">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
        className="flex h-12 w-[clamp(11rem,18vw,16rem)] min-w-0 max-w-full items-center gap-3 rounded-xl border border-gray-300 bg-white px-3 py-2 transition-colors hover:bg-gray-50"
      >
        <Building2 className="h-5 w-5 shrink-0 text-gray-600" />
        <div className="min-w-0 flex-1 text-left">
          <div className="truncate text-sm font-medium text-gray-900">
            {selectedBusiness ? getBusinessDisplayName(selectedBusiness) : 'Выберите бизнес'}
          </div>
          {isSuperadmin && selectedBusiness?.owner_name && (
            <div className="truncate text-xs text-gray-500">
              {selectedBusiness.owner_name}
            </div>
          )}
        </div>
        <ChevronDown className={`h-4 w-4 shrink-0 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div role="listbox" aria-label="Бизнесы" className="absolute left-0 top-full z-50 mt-2 max-h-[min(70vh,34rem)] w-[min(34rem,calc(100vw-2rem))] overflow-y-auto overflow-x-hidden rounded-2xl border border-gray-200 bg-white shadow-xl ring-1 ring-black/5">
          {hasBusinesses && visibleBusinesses.map((business) => (
            <button
              key={business.id}
              type="button"
              role="option"
              aria-selected={selectedBusiness?.id === business.id}
              onClick={() => handleBusinessSelect(business)}
              className={`w-full px-4 py-3 text-left transition-colors hover:bg-gray-50 ${selectedBusiness?.id === business.id ? 'border-l-4 border-blue-500 bg-blue-50 pl-3' : ''
                }`}
            >
              <div className="flex items-start gap-3">
                <Building2 className="mt-0.5 h-5 w-5 shrink-0 text-gray-600" />
                <div className="min-w-0 flex-1">
                  <div className="break-words text-base font-medium leading-6 text-gray-900">
                    {getBusinessDisplayName(business)}
                  </div>
                  {business.id === business.network_id && (
                    <div className="mt-1 text-xs text-gray-500">Сеть · точки выбираются отдельно</div>
                  )}
                  {(business.address || business.description) && (
                    <div className="mt-1 line-clamp-2 break-words text-sm leading-5 text-gray-500">
                      {business.address || business.description}
                    </div>
                  )}
                  {business.network_name && (
                    <div className="mt-1 text-xs text-gray-500">{business.network_name}</div>
                  )}
                  {isSuperadmin && business.owner_name && (
                    <div className="mt-2 flex items-center gap-1">
                      <Users className="h-3.5 w-3.5 shrink-0 text-gray-400" />
                      <span className="min-w-0 break-words text-sm text-gray-500">
                        {business.owner_name}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
