import { useMemo } from 'react';

export type PartnershipDerivedLead = {
  id: string;
  phone?: string;
  email?: string;
  website?: string;
  telegram_url?: string;
  whatsapp_url?: string;
  source_kind?: string;
  source_provider?: string;
  partnership_stage?: string;
  pipeline_status?: string;
  pilot_cohort?: string;
  parse_status?: string;
  deferred_until?: string;
  search_payload_json?: Record<string, any> | null;
  enrich_payload_json?: {
    provider?: string;
    found_fields?: string[];
  } | null;
  next_best_action?: {
    code?: string;
  };
};

export type PartnershipDerivedDraft = {
  learning_note_json?: { campaign_id?: string; search_task_id?: string; manual_review_required?: boolean };
  id: string;
  lead_id: string;
  status?: string;
  lead_status?: string;
  lead_pipeline_status?: string;
  lead_partnership_stage?: string;
  created_at?: string;
  updated_at?: string;
};

export type PartnershipDerivedBatch = {
  id: string;
  status: string;
  items?: Array<{
    id: string;
    lead_id?: string;
    delivery_status?: string;
    latest_outcome?: string | null;
    latest_human_outcome?: string | null;
    [key: string]: any;
  }>;
};

export type PartnershipDerivedReaction = {
  id: string;
  lead_id: string;
  classified_outcome?: string | null;
  human_confirmed_outcome?: string | null;
  [key: string]: any;
};

type SourceDescriptor = {
  source_kind?: string;
  source_provider?: string;
};

type PartnershipDerivedArgs<TLead extends PartnershipDerivedLead> = {
  items: TLead[];
  selectedLeadId: string | null;
  auditData: any;
  leadView: string;
  leadBucket: 'active' | 'deferred';
  preferredSourceFilter: SourceDescriptor | null;
  lastGeoSearchLeadIds: string[];
  ralphLoop: any;
  batches: PartnershipDerivedBatch[];
  drafts: PartnershipDerivedDraft[];
  reactions: PartnershipDerivedReaction[];
  draftView: string;
  queueView: string;
  reactionView: string;
  outcomes: any;
};

const ACTIVE_PIPELINE_STAGES = [
  'audited',
  'matched',
  'proposal_draft_ready',
  'selected_for_outreach',
  'channel_selected',
  'approved_for_send',
  'sent',
];

const AUDITED_FLOW_STAGES = ['audited', 'matched', 'proposal_draft_ready', 'proposal_approved', 'queued_for_send', 'sent'];
const MATCHED_FLOW_STAGES = ['matched', 'proposal_draft_ready', 'proposal_approved', 'queued_for_send', 'sent'];
const DRAFT_READY_FLOW_STAGES = ['proposal_draft_ready', 'proposal_approved', 'queued_for_send', 'sent'];
const ACTIVE_PIPELINE_STATUSES = ['in_progress', 'contacted', 'waiting_reply', 'second_message_sent', 'replied', 'converted'];
const DRAFT_EXCLUDED_PIPELINE_STATUSES = ['not_relevant', 'disqualified', 'closed_lost'];
const DRAFT_EXCLUDED_LEAD_STATUSES = ['not_relevant', 'disqualified', 'rejected', 'shortlist_rejected'];
const DRAFT_EXCLUDED_PARTNERSHIP_STAGES = ['rejected', 'shortlist_rejected'];

export const getLeadPipelineStatus = (item: PartnershipDerivedLead) => {
  const explicit = String(item.pipeline_status || '').trim().toLowerCase();
  if (explicit === 'approved_for_send' || explicit === 'queued_for_send') return 'in_progress';
  if (explicit === 'qualified') return 'in_progress';
  if (explicit === 'disqualified') return 'not_relevant';
  if (explicit === 'deferred') return 'postponed';
  if (explicit === 'sent' || explicit === 'delivered') return 'contacted';
  if (explicit === 'responded') return 'replied';
  if (explicit === 'closed') return 'closed_lost';
  if (explicit) return explicit;
  const stageValue = String(item.partnership_stage || '').trim().toLowerCase();
  if (stageValue === 'deferred') return 'postponed';
  if (['rejected', 'shortlist_rejected'].includes(stageValue)) return 'not_relevant';
  if (['sent', 'delivered'].includes(stageValue)) return 'contacted';
  if (ACTIVE_PIPELINE_STAGES.includes(stageValue)) return 'in_progress';
  return 'unprocessed';
};

const hasAnyContact = (item: PartnershipDerivedLead) =>
  Boolean(item.phone || item.email || item.telegram_url || item.whatsapp_url || item.website);

const sameSource = (left?: SourceDescriptor | null, right?: SourceDescriptor | null) => {
  if (!left || !right) return false;
  return (
    String(left.source_kind || '').toLowerCase() === String(right.source_kind || '').toLowerCase() &&
    String(left.source_provider || '').toLowerCase() === String(right.source_provider || '').toLowerCase()
  );
};

const sourceLeadsForIds = (items: PartnershipDerivedLead[], ids: string[]) =>
  items.filter((item) => ids.includes(item.id));

const draftSortTime = (draft: PartnershipDerivedDraft) => {
  const value = Date.parse(String(draft.updated_at || draft.created_at || ''));
  return Number.isFinite(value) ? value : 0;
};

export function usePartnershipWorkspaceDerivedData<TLead extends PartnershipDerivedLead>({
  items,
  selectedLeadId,
  auditData,
  leadView,
  leadBucket,
  preferredSourceFilter,
  lastGeoSearchLeadIds,
  ralphLoop,
  batches,
  drafts,
  reactions,
  draftView,
  queueView,
  reactionView,
  outcomes,
}: PartnershipDerivedArgs<TLead>) {
  const selectedLead = useMemo(
    () => items.find((item) => item.id === selectedLeadId) || null,
    [items, selectedLeadId]
  );

  const selectedLeadLogo = useMemo(() => {
    if (auditData?.preview_meta?.logo_url) return String(auditData.preview_meta.logo_url);
    if (selectedLead?.search_payload_json?.logo_url) return String(selectedLead.search_payload_json.logo_url);
    return '';
  }, [auditData, selectedLead]);

  const selectedLeadPhotos = useMemo(() => {
    const fromAudit = auditData?.preview_meta?.photo_urls;
    if (Array.isArray(fromAudit) && fromAudit.length > 0) {
      return fromAudit.map((item: unknown) => String(item || '').trim()).filter(Boolean).slice(0, 8);
    }
    const fromLead = selectedLead?.search_payload_json?.photos;
    if (Array.isArray(fromLead) && fromLead.length > 0) {
      return fromLead.map((item: unknown) => String(item || '').trim()).filter(Boolean).slice(0, 8);
    }
    return [];
  }, [auditData, selectedLead]);

  const visibleLeads = useMemo(() => {
    const todayIso = new Date().toISOString().slice(0, 10);
    return items.filter((item) => {
      const parseStatus = String(item.parse_status || '').toLowerCase();
      const pipelineStatus = getLeadPipelineStatus(item);
      const nextCode = String(item.next_best_action?.code || '').toLowerCase();
      const deferredUntil = String(item.deferred_until || '').slice(0, 10);
      const isDeferred = pipelineStatus === 'postponed';
      const isOverdueReturn = isDeferred && Boolean(deferredUntil) && deferredUntil <= todayIso;
      if (leadBucket === 'deferred' && !isDeferred) return false;
      if (leadBucket === 'active' && isDeferred) return false;
      if (leadView === 'deferred') return isDeferred;
      if (leadView === 'overdue_return') return isOverdueReturn;
      if (leadView === 'requires_action') {
        return ['captcha', 'error'].includes(parseStatus) || ['resolve_captcha', 'inspect_parse_error', 'fill_contacts'].includes(nextCode);
      }
      if (leadView === 'no_parse') return !parseStatus || ['pending', 'queued', 'imported'].includes(parseStatus);
      if (leadView === 'ready_for_letter') return ['draft', 'approve_draft'].includes(nextCode);
      if (leadView === 'errors') return ['error', 'failed'].includes(parseStatus);
      if (leadView === 'last_geo_search') return lastGeoSearchLeadIds.includes(item.id);
      if (leadView === 'ready_next_step') {
        return [
          'resolve_and_parse', 'run_parse', 'run_audit', 'run_match', 'draft_offer',
          'approve_draft', 'queue_for_send', 'approve_batch', 'record_outcome',
        ].includes(nextCode);
      }
      if (leadView === 'parsed') return parseStatus === 'completed';
      if (leadView === 'with_contacts') return hasAnyContact(item);
      if (leadView === 'best_source') return sameSource(item, preferredSourceFilter);
      return true;
    });
  }, [items, leadView, leadBucket, preferredSourceFilter, lastGeoSearchLeadIds]);

  const bestSourceThisWeek = useMemo(() => {
    if (!Array.isArray(ralphLoop?.source_performance) || ralphLoop.source_performance.length === 0) return null;
    return ralphLoop.source_performance[0] || null;
  }, [ralphLoop]);

  const lastGeoSearchSourceSummary = useMemo(() => {
    const sourceLeads = sourceLeadsForIds(items, lastGeoSearchLeadIds);
    if (sourceLeads.length === 0) return null;
    const counts = new Map<string, { source_kind?: string; source_provider?: string; count: number }>();
    sourceLeads.forEach((item) => {
      const sourceKind = String(item.source_kind || '').trim() || undefined;
      const sourceProvider = String(item.source_provider || '').trim() || undefined;
      const key = `${sourceKind || 'unknown'}::${sourceProvider || 'unknown'}`;
      const current = counts.get(key) || { source_kind: sourceKind, source_provider: sourceProvider, count: 0 };
      current.count += 1;
      counts.set(key, current);
    });
    return Array.from(counts.values()).sort((a, b) => b.count - a.count)[0] || null;
  }, [items, lastGeoSearchLeadIds]);

  const lastGeoSearchMatchesBestSource = useMemo(
    () => sameSource(bestSourceThisWeek, lastGeoSearchSourceSummary),
    [bestSourceThisWeek, lastGeoSearchSourceSummary]
  );

  const lastGeoSearchStats = useMemo(() => {
    const sourceLeads = sourceLeadsForIds(items, lastGeoSearchLeadIds);
    if (sourceLeads.length === 0) return null;
    return {
      total: sourceLeads.length,
      parsedCompleted: sourceLeads.filter((item) => String(item.parse_status || '').toLowerCase() === 'completed').length,
      withContacts: sourceLeads.filter(hasAnyContact).length,
      enriched: sourceLeads.filter((item) => {
        const payload = item.enrich_payload_json;
        return Boolean(payload?.provider || (Array.isArray(payload?.found_fields) && payload.found_fields.length > 0));
      }).length,
      readyForDraft: sourceLeads.filter((item) => String(item.next_best_action?.code || '').toLowerCase() === 'draft').length,
    };
  }, [items, lastGeoSearchLeadIds]);

  const allQueueItems = useMemo(
    () => batches.flatMap((batch) => (batch.items || []).map((item) => ({ ...item, batch_status: batch.status, batch_id: batch.id }))),
    [batches]
  );

  const lastGeoSearchFlowSummary = useMemo(() => {
    const sourceLeads = sourceLeadsForIds(items, lastGeoSearchLeadIds);
    if (sourceLeads.length === 0) return null;
    const leadIds = new Set(sourceLeads.map((item) => item.id));
    const sourceDrafts = drafts.filter((draft) => leadIds.has(String(draft.lead_id || '')));
    const sourceQueueItems = allQueueItems.filter((item) => leadIds.has(String(item.lead_id || '')));
    const sourceReactions = reactions.filter((item) => leadIds.has(String(item.lead_id || '')));
    return {
      total: sourceLeads.length,
      audited: sourceLeads.filter((item) => AUDITED_FLOW_STAGES.includes(String(item.partnership_stage || '').toLowerCase())).length,
      matched: sourceLeads.filter((item) => MATCHED_FLOW_STAGES.includes(String(item.partnership_stage || '').toLowerCase())).length,
      draftReady: sourceLeads.filter((item) => DRAFT_READY_FLOW_STAGES.includes(String(item.partnership_stage || '').toLowerCase())).length,
      draftsApproved: sourceDrafts.filter((draft) => String(draft.status || '').toLowerCase() === 'approved').length,
      queued: sourceQueueItems.filter((item) => ['queued', 'sending', 'retry', 'sent', 'delivered', 'failed'].includes(String(item.delivery_status || '').toLowerCase())).length,
      sent: sourceQueueItems.filter((item) => ['sent', 'delivered'].includes(String(item.delivery_status || '').toLowerCase())).length,
      positive: sourceReactions.filter((item) => String(item.human_confirmed_outcome || item.classified_outcome || '').toLowerCase() === 'positive').length,
    };
  }, [items, lastGeoSearchLeadIds, drafts, allQueueItems, reactions]);

  const selectedLeadFlowStatus = useMemo(() => {
    if (!selectedLead) return null;
    const leadId = String(selectedLead.id || '');
    const leadDrafts = drafts.filter((draft) => String(draft.lead_id || '') === leadId);
    const leadQueueItems = allQueueItems.filter((item) => String(item.lead_id || '') === leadId);
    const leadReactions = reactions.filter((item) => String(item.lead_id || '') === leadId);
    return {
      draftsTotal: leadDrafts.length,
      draftsApproved: leadDrafts.filter((draft) => String(draft.status || '').toLowerCase() === 'approved').length,
      queueTotal: leadQueueItems.length,
      sentTotal: leadQueueItems.filter((item) => ['sent', 'delivered'].includes(String(item.delivery_status || '').toLowerCase())).length,
      outcomeFinal: leadReactions[0]?.human_confirmed_outcome || leadReactions[0]?.classified_outcome || null,
    };
  }, [selectedLead, drafts, allQueueItems, reactions]);

  const latestDraftsByLead = useMemo(() => {
    const byLead = new Map<string, PartnershipDerivedDraft>();
    drafts.forEach((draft) => {
      const leadId = String(draft.lead_id || '').trim();
      if (!leadId) return;
      const current = byLead.get(leadId);
      if (!current || draftSortTime(draft) >= draftSortTime(current)) {
        byLead.set(leadId, draft);
      }
    });
    return Array.from(byLead.values());
  }, [drafts]);

  const visibleDrafts = useMemo(() => latestDraftsByLead.filter((draft) => {
    const lead = items.find((item) => String(item.id || '') === String(draft.lead_id || ''));
    const leadPipelineStatus = String(draft.lead_pipeline_status || (lead ? getLeadPipelineStatus(lead) : '')).toLowerCase();
    const leadStatus = String(draft.lead_status || '').toLowerCase();
    const partnershipStage = String(draft.lead_partnership_stage || lead?.partnership_stage || '').toLowerCase();
    if (
      DRAFT_EXCLUDED_PIPELINE_STATUSES.includes(leadPipelineStatus) ||
      DRAFT_EXCLUDED_LEAD_STATUSES.includes(leadStatus) ||
      DRAFT_EXCLUDED_PARTNERSHIP_STAGES.includes(partnershipStage)
    ) {
      return false;
    }
    const status = String(draft.status || '').toLowerCase();
    if (draftView === 'needs_approval') return !status || status === 'generated' || status === 'draft';
    if (draftView === 'approved') return status === 'approved';
    return true;
  }), [latestDraftsByLead, draftView, items]);

  const visibleBatches = useMemo(() => batches
    .map((batch) => {
      const items = (batch.items || []).filter((item) => {
        const delivery = String(item.delivery_status || '').toLowerCase();
        const outcome = String(item.latest_human_outcome || item.latest_outcome || '').toLowerCase();
        if (queueView === 'needs_approval') return String(batch.status || '').toLowerCase() === 'draft';
        if (queueView === 'waiting_delivery') return ['queued', 'pending', 'created', 'draft', ''].includes(delivery);
        if (queueView === 'waiting_outcome') return delivery === 'sent' && !outcome;
        if (queueView === 'failed') return delivery === 'failed';
        return true;
      });
      return { ...batch, items };
    })
    .filter((batch) => queueView === 'needs_approval' ? String(batch.status || '').toLowerCase() === 'draft' : (batch.items || []).length > 0),
    [batches, queueView]
  );

  const visibleReactions = useMemo(() => reactions.filter((reaction) => {
    const finalOutcome = String(reaction.human_confirmed_outcome || reaction.classified_outcome || '').toLowerCase();
    if (reactionView === 'needs_confirmation') return !reaction.human_confirmed_outcome;
    if (reactionView !== 'all') return finalOutcome === reactionView;
    return true;
  }), [reactions, reactionView]);

  const pilotSummary = useMemo(() => ({
    total: items.length,
    parsed: items.filter((item) => String(item.parse_status || '').toLowerCase() === 'completed').length,
    readyForDraft: items.filter((item) => String(item.next_best_action?.code || '') === 'draft').length,
    waitingApproval: drafts.filter((draft) => {
      const status = String(draft.status || '').toLowerCase();
      return !status || status === 'generated' || status === 'draft';
    }).length,
    waitingOutcome: allQueueItems.filter((item) => {
      const delivery = String(item.delivery_status || '').toLowerCase();
      return delivery === 'sent' && !(item.latest_human_outcome || item.latest_outcome);
    }).length,
    acceptance: Number(outcomes?.summary?.positive_rate_pct || 0),
  }), [items, drafts, allQueueItems, outcomes]);

  const deferredLeadsCount = useMemo(
    () => items.filter((item) => getLeadPipelineStatus(item) === 'postponed').length,
    [items]
  );

  const overdueDeferredLeadsCount = useMemo(() => {
    const todayIso = new Date().toISOString().slice(0, 10);
    return items.filter((item) => {
      const pipelineStatus = getLeadPipelineStatus(item);
      const deferredUntil = String(item.deferred_until || '').slice(0, 10);
      return pipelineStatus === 'postponed' && Boolean(deferredUntil) && deferredUntil <= todayIso;
    }).length;
  }, [items]);

  const activeLeadsCount = useMemo(
    () => items.filter((item) => getLeadPipelineStatus(item) !== 'postponed').length,
    [items]
  );

  const rawLeads = useMemo(() => visibleLeads.filter((item) => getLeadPipelineStatus(item) === 'unprocessed'), [visibleLeads]);
  const rawLeadCount = rawLeads.length;
  const pipelineLeads = useMemo(() => visibleLeads.filter((item) => {
    const pipelineStatus = getLeadPipelineStatus(item);
    return pipelineStatus && pipelineStatus !== 'unprocessed';
  }), [visibleLeads]);
  const pipelineLeadCount = pipelineLeads.length;
  const lastGeoSearchLeadCount = lastGeoSearchLeadIds.length;

  const pipelineSummary = useMemo(() => ({
    raw: rawLeadCount,
    withAudit: items.filter((item) => ACTIVE_PIPELINE_STAGES.includes(String(item.partnership_stage || '').toLowerCase())).length,
    readyToContact: items.filter((item) => ['proposal_draft_ready', 'selected_for_outreach', 'channel_selected'].includes(String(item.partnership_stage || '').toLowerCase())).length,
    deferred: deferredLeadsCount,
  }), [items, rawLeadCount, deferredLeadsCount]);

  const rawLeadStatusSummary = useMemo(() => {
    const imported = rawLeads.filter((item) => {
      const pipelineStatus = getLeadPipelineStatus(item);
      return !pipelineStatus || pipelineStatus === 'unprocessed';
    }).length;
    const inPipeline = rawLeads.filter((item) => ACTIVE_PIPELINE_STATUSES.includes(getLeadPipelineStatus(item))).length;
    const deferred = rawLeads.filter((item) => getLeadPipelineStatus(item) === 'postponed').length;
    const rejected = rawLeads.filter((item) => getLeadPipelineStatus(item) === 'not_relevant').length;
    return { imported, inPipeline, deferred, rejected };
  }, [rawLeads]);

  return {
    selectedLead,
    selectedLeadLogo,
    selectedLeadPhotos,
    visibleLeads,
    bestSourceThisWeek,
    lastGeoSearchSourceSummary,
    lastGeoSearchMatchesBestSource,
    lastGeoSearchStats,
    allQueueItems,
    lastGeoSearchFlowSummary,
    selectedLeadFlowStatus,
    visibleDrafts,
    visibleBatches,
    visibleReactions,
    pilotSummary,
    deferredLeadsCount,
    overdueDeferredLeadsCount,
    activeLeadsCount,
    rawLeads,
    rawLeadCount,
    pipelineLeads,
    pipelineLeadCount,
    lastGeoSearchLeadCount,
    pipelineSummary,
    rawLeadStatusSummary,
  };
}
