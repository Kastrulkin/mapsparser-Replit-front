from flask import Flask

from api import operator_api


class FakeConnection:
    def __init__(self):
        self.cursor_instance = FakeCursor()
        self.commits = 0
        self.rollbacks = 0
        self.closed = False

    def cursor(self):
        return self.cursor_instance

    def commit(self):
        self.commits += 1

    def rollback(self):
        self.rollbacks += 1


class FakeCursor:
    def fetchone(self):
        return None

    def fetchall(self):
        return []

    def execute(self, query, params=None):
        return None


class FakeDatabaseManager:
    instances = []

    def __init__(self):
        self.conn = FakeConnection()
        self.closed = False
        FakeDatabaseManager.instances.append(self)

    def close(self):
        self.closed = True


def _client(monkeypatch):
    app = Flask(__name__)
    app.register_blueprint(operator_api.operator_bp)
    monkeypatch.setattr(operator_api, "DatabaseManager", FakeDatabaseManager)
    monkeypatch.setattr(operator_api, "require_auth_from_request", lambda: {"user_id": "user-1", "id": "user-1"})
    monkeypatch.setattr(operator_api, "verify_business_access", lambda cursor, business_id, user_data: (True, "user-1"))
    monkeypatch.setattr(operator_api, "verify_business_write_access", lambda cursor, business_id, user_data: (True, "user-1"))
    monkeypatch.setattr(
        operator_api,
        "_scope_capability_access",
        lambda cursor, scope, capability, is_superadmin=False: {
            "allowed": True,
            "capability": capability,
            "status": "available",
        },
    )
    monkeypatch.setattr(operator_api, "_scope_subscription_access", lambda *args: {"active": True, "capabilities": ["operator", "maps", "maps.reviews", "maps.services", "social_content"]})
    monkeypatch.setattr(operator_api, "record_operator_event", lambda *args, **kwargs: None)
    return app.test_client()


def test_operator_chat_rule_based_refresh_does_not_call_ai_router(monkeypatch) -> None:
    client = _client(monkeypatch)
    calls = {"refresh": 0, "ai": 0}

    def refresh(cursor, *, business_id, user_id, explicit_url=None, channel="web"):
        calls["refresh"] += 1
        return {
            "status": "queued",
            "intent": "fresh_reviews_refresh",
            "chat_response": "Запустил обновление карточки.",
            "queue_id": "queue-1",
            "blocked_reasons": [],
        }

    def ai_router(*args, **kwargs):
        calls["ai"] += 1
        raise AssertionError("AI router must not run for rule-based refresh")

    monkeypatch.setattr(operator_api, "refresh_reviews_from_operator", refresh)
    monkeypatch.setattr(operator_api, "classify_operator_intent_with_ai", ai_router)

    response = client.post("/api/operator/chat", json={"business_id": "biz-1", "message": "Обнови карточку"})
    body = response.get_json()

    assert response.status_code == 200
    assert body["success"] is True
    assert body["operator_result"]["queue_id"] == "queue-1"
    assert "ai_router" not in body["operator_result"]
    assert calls == {"refresh": 1, "ai": 0}


def test_operator_chat_cheap_gate_skips_ai_router_for_smalltalk(monkeypatch) -> None:
    client = _client(monkeypatch)
    calls = {"ai": 0}

    def ai_router(*args, **kwargs):
        calls["ai"] += 1
        raise AssertionError("AI router must not run for smalltalk")

    monkeypatch.setattr(operator_api, "classify_operator_intent_with_ai", ai_router)

    response = client.post("/api/operator/chat", json={"business_id": "biz-1", "message": "привет"})
    body = response.get_json()

    assert response.status_code == 200
    assert body["success"] is False
    assert body["operator_result"]["status"] == "unsupported"
    assert body["operator_result"]["credit_charged"] is False
    assert calls["ai"] == 0


def test_operator_chat_ai_fallback_card_refresh(monkeypatch) -> None:
    client = _client(monkeypatch)
    calls = {"refresh": 0, "ai": 0}

    def ai_router(cursor, *, business_id, user_id, message, channel="web"):
        calls["ai"] += 1
        return {
            "status": "completed",
            "intent": "operator_intent_ai_router",
            "normalized_intent": "card_refresh",
            "charged_credits": 1,
            "credit_charged": True,
            "finalization_result": {
                "status": "charged",
                "charge_credits": 1,
                "release_credits": 0,
                "side_effects": {"credit_charged": True},
            },
        }

    def refresh(cursor, *, business_id, user_id, explicit_url=None, channel="web"):
        calls["refresh"] += 1
        return {
            "status": "queued",
            "intent": "fresh_reviews_refresh",
            "chat_response": "Запустил обновление карточки.",
            "queue_id": "queue-1",
            "blocked_reasons": [],
        }

    monkeypatch.setattr(operator_api, "classify_operator_intent_with_ai", ai_router)
    monkeypatch.setattr(operator_api, "refresh_reviews_from_operator", refresh)

    response = client.post("/api/operator/chat", json={"business_id": "biz-1", "message": "посмотри что там с карточкой"})
    body = response.get_json()

    assert response.status_code == 200
    assert body["success"] is True
    result = body["operator_result"]
    assert result["status"] == "queued"
    assert result["queue_id"] == "queue-1"
    assert result["ai_router"]["intent"] == "card_refresh"
    assert result["ai_router"]["charged_credits"] == 1
    assert "raw_response" not in result["ai_router"]
    assert calls == {"refresh": 1, "ai": 1}


def test_operator_chat_ai_manual_review_guard_does_not_add_review(monkeypatch) -> None:
    client = _client(monkeypatch)
    calls = {"process": 0, "ai": 0}
    original_process = operator_api.process_operator_chat_message

    def process(cursor, *, business_id, user_id, message, channel="web"):
        calls["process"] += 1
        return original_process(cursor, business_id=business_id, user_id=user_id, message=message, channel=channel)

    def ai_router(cursor, *, business_id, user_id, message, channel="web"):
        calls["ai"] += 1
        return {
            "status": "completed",
            "intent": "operator_intent_ai_router",
            "normalized_intent": "manual_review_add_and_reply",
            "charged_credits": 1,
            "credit_charged": True,
            "finalization_result": {
                "status": "charged",
                "charge_credits": 1,
                "release_credits": 0,
                "side_effects": {"credit_charged": True},
            },
        }

    monkeypatch.setattr(operator_api, "process_operator_chat_message", process)
    monkeypatch.setattr(operator_api, "classify_operator_intent_with_ai", ai_router)

    response = client.post("/api/operator/chat", json={"business_id": "biz-1", "message": "надо ответить людям"})
    body = response.get_json()

    assert response.status_code == 200
    assert body["success"] is False
    result = body["operator_result"]
    assert result["status"] == "blocked"
    assert "manual_review_text_not_explicit" in result["blocked_reasons"]
    assert result["external_writes_performed"] is False
    assert result["ai_router"]["intent"] == "manual_review_add_and_reply"
    assert calls == {"process": 0, "ai": 1}


def test_operator_chat_returns_structured_error_without_leaking_exception(monkeypatch) -> None:
    client = _client(monkeypatch)

    def fail_route(*_args, **_kwargs):
        raise RuntimeError("database password and internal traceback")

    monkeypatch.setattr(operator_api, "route_operator_message", fail_route)

    response = client.post("/api/operator/chat", json={"business_id": "biz-1", "message": "Проверь состояние"})
    body = response.get_json()

    assert response.status_code == 500
    assert body["success"] is False
    assert body["error_code"] == "operator_chat_failed"
    assert body["error_id"]
    assert "password" not in body["error"].lower()
    assert FakeDatabaseManager.instances[-1].conn.rollbacks == 1


def test_operator_action_confirm_passes_authenticated_tenant_scope(monkeypatch) -> None:
    client = _client(monkeypatch)
    calls = []

    def confirm(cursor, *, action_id, business_id, user_id, subscription_access=None):
        calls.append((action_id, business_id, user_id))
        return {"status": "completed", "chat_response": "Готово."}, False

    monkeypatch.setattr(operator_api, "confirm_pending_operator_action", confirm)
    response = client.post("/api/operator/actions/action-1/confirm", json={"business_id": "biz-1"})

    assert response.status_code == 200
    assert response.get_json()["success"] is True
    assert calls == [("action-1", "biz-1", "user-1")]


def test_operator_action_reject_denies_cross_tenant_access(monkeypatch) -> None:
    client = _client(monkeypatch)
    calls = []
    monkeypatch.setattr(operator_api, "verify_business_access", lambda *_args, **_kwargs: (False, "owner-2"))
    monkeypatch.setattr(
        operator_api,
        "reject_pending_operator_action",
        lambda *_args, **_kwargs: calls.append("called"),
    )

    response = client.post("/api/operator/actions/action-1/reject", json={"business_id": "other-business"})

    assert response.status_code == 403
    assert calls == []


def test_operator_action_reject_error_does_not_leak_internal_exception(monkeypatch) -> None:
    client = _client(monkeypatch)

    def fail(*_args, **_kwargs):
        raise RuntimeError("database password and internal traceback")

    monkeypatch.setattr(operator_api, "reject_pending_operator_action", fail)
    response = client.post("/api/operator/actions/action-1/reject", json={"business_id": "biz-1"})
    body = response.get_json()

    assert response.status_code == 500
    assert body["error_code"] == "operator_action_rejection_failed"
    assert body["error_id"]
    assert "password" not in body["error"].lower()


def test_operator_refresh_recovery_plan_endpoint(monkeypatch) -> None:
    client = _client(monkeypatch)

    def recovery_plan(cursor, *, business_id, user_id, queue_id):
        assert business_id == "biz-1"
        assert user_id == "user-1"
        assert queue_id == "queue-1"
        return {
            "status": "ready",
            "queue_id": queue_id,
            "retry_allowed": True,
            "release_allowed": True,
            "reservation_id": "reservation-1",
            "outstanding_credits": 10,
            "blocked_reasons": [],
            "side_effects": {"reservation_released": False},
        }

    monkeypatch.setattr(operator_api, "build_refresh_recovery_plan", recovery_plan)

    response = client.get("/api/operator/reviews/refresh-jobs/queue-1/recovery?business_id=biz-1")
    body = response.get_json()

    assert response.status_code == 200
    assert body["success"] is True
    assert body["recovery_result"]["reservation_id"] == "reservation-1"
    assert body["recovery_result"]["release_allowed"] is True


def test_operator_refresh_recovery_release_endpoint_requires_confirmation(monkeypatch) -> None:
    client = _client(monkeypatch)
    calls = {"plan": 0, "release": 0}

    def recovery_plan(cursor, *, business_id, user_id, queue_id):
        calls["plan"] += 1
        return {
            "status": "ready",
            "queue_id": queue_id,
            "retry_allowed": True,
            "release_allowed": True,
            "reservation_id": "reservation-1",
            "outstanding_credits": 10,
            "blocked_reasons": [],
            "side_effects": {"reservation_released": False},
        }

    def release(cursor, *, business_id, user_id, queue_id, confirm_release=False):
        calls["release"] += 1
        assert confirm_release is True
        return {
            "status": "released",
            "queue_id": queue_id,
            "retry_allowed": True,
            "release_allowed": True,
            "reservation_id": "reservation-1",
            "outstanding_credits": 10,
            "blocked_reasons": [],
            "side_effects": {"reservation_released": True},
        }

    monkeypatch.setattr(operator_api, "build_refresh_recovery_plan", recovery_plan)
    monkeypatch.setattr(operator_api, "release_failed_refresh_reservation", release)

    plan_response = client.post(
        "/api/operator/reviews/refresh-jobs/queue-1/recovery",
        json={"business_id": "biz-1"},
    )
    release_response = client.post(
        "/api/operator/reviews/refresh-jobs/queue-1/recovery",
        json={"business_id": "biz-1", "confirm_release": True},
    )

    assert plan_response.status_code == 200
    assert plan_response.get_json()["recovery_result"]["status"] == "ready"
    assert release_response.status_code == 200
    assert release_response.get_json()["recovery_result"]["status"] == "released"
    assert calls == {"plan": 1, "release": 1}


def test_selected_work_discussion_keeps_voice_text_and_source_identity(monkeypatch):
    client = _client(monkeypatch)
    from services import lead_journey_service, operator_chat_service
    action_id = '00000000-0000-0000-0000-000000000042'
    monkeypatch.setattr(lead_journey_service, 'load_action', lambda cursor, **kwargs: {'id': action_id, 'business_id': 'biz-1', 'entity_type': 'contentplanitem', 'status': 'draft', 'title': 'Draft'})
    received = []
    def process(cursor, **kwargs):
        received.append((kwargs['message'], kwargs['payload'].get('transcription_id')))
        result, _ = kwargs['router'](cursor, action_payload=kwargs['payload'])
        return {**result, 'conversation_id': 'chat'}
    monkeypatch.setattr(operator_chat_service, 'process_chat', process)
    monkeypatch.setattr(operator_api, 'route_operator_message', lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError('discussion must not create another task')))
    response = client.post('/api/operator/chat', json={'business_id': 'biz-1', 'message': 'Что нужно проверить?', 'journey_action_id': action_id, 'transcription_id': 'voice'})
    assert response.status_code == 200
    assert received == [('Что нужно проверить?', 'voice')]
    result = response.get_json()['operator_result']
    assert result['selected_work']['id'] == action_id
    assert result['selected_work']['status'] == 'draft'
    assert 'approval' not in result


def test_selected_work_from_another_business_is_rejected(monkeypatch):
    client = _client(monkeypatch)
    from services import lead_journey_service, operator_chat_service
    def inaccessible(*args, **kwargs):
        raise lead_journey_service.JourneyError('Нет доступа', 404, 'action_missing')
    monkeypatch.setattr(lead_journey_service, 'load_action', inaccessible)
    monkeypatch.setattr(operator_chat_service, 'process_chat', lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError('must not route')))
    response = client.post('/api/operator/chat', json={'business_id':'biz-1','message':'Открой','journey_action_id':'00000000-0000-0000-0000-000000000042'})
    assert response.status_code == 404


def test_selected_work_discussion_does_not_bypass_paid_material_access(monkeypatch):
    client = _client(monkeypatch)
    from services import lead_journey_service, operator_chat_service
    monkeypatch.setattr(lead_journey_service, 'load_action', lambda *args, **kwargs: {'id': '00000000-0000-0000-0000-000000000042', 'flow_type': 'content', 'description': 'private material'})
    monkeypatch.setattr(operator_api, 'capability_access_payload', lambda *args: {'allowed': False, 'reason': 'Plan required'})
    monkeypatch.setattr(operator_chat_service, 'process_chat', lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError('must not disclose or create work')))
    response = client.post('/api/operator/chat', json={'business_id': 'biz-1', 'message': 'Explain', 'journey_action_id': '00000000-0000-0000-0000-000000000042'})
    assert response.status_code == 402
    assert 'private material' not in str(response.get_json())
