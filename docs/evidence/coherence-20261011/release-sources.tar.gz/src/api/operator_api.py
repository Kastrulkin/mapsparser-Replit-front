from __future__ import annotations

import os
import sys
import base64
import hashlib
import json
import logging
import re
import uuid
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from flask import Blueprint, jsonify, request

from auth_system import create_session
from core.auth_helpers import require_auth_from_request, verify_business_access, verify_business_write_access
from database_manager import DatabaseManager
from services.operator_audit import list_operator_events, record_operator_event
from services.operator_capabilities import (
    build_operator_help_response,
    classify_operator_help_intent,
    classify_unanswered_reviews_status_intent,
    get_unanswered_reviews_status,
)
from services.operator_consent_policy import list_consent_policies, upsert_consent_policy
from services.operator_content_history import list_operator_content_history
from services.operator_attention import build_attention_brief
from services.operator_scope_summary import build_operator_scope_summary
from services.telegram_control_scope import (
    list_control_scopes,
    list_network_scope_locations,
    load_control_preferences,
    resolve_control_scope,
    save_scope_notification_preferences,
    toggle_favorite_control_scope,
)
from services.telegram_webapp_auth import load_localos_user_for_telegram, validate_telegram_webapp_init_data
from services.operator_fresh_reviews import classify_fresh_reviews_intent, refresh_reviews_from_operator
from services.operator_intent_ai_router import classify_operator_intent_with_ai, should_use_ai_intent_router
from services.operator_inbox import build_operator_inbox
from services.operator_manual_review import process_operator_chat_message
from services.operator_manual_publish import mark_review_reply_draft_manual_published
from services.operator_mobile_actions import confirm_mobile_action, create_mobile_action_preview
from services.operator_async_jobs import (
    cancel_operator_async_job,
    create_operator_async_job,
    list_operator_async_jobs,
    load_operator_async_job,
    retry_operator_async_job,
)
from services.operator_mobile_modules import list_operator_mobile_module
from services.operator_mobile_today import build_mobile_feed, build_mobile_progress, build_mobile_today
from services.operator_mobile_jobs import load_mobile_job
from services.operator_mobile_deep_links import resolve_mobile_deep_link
from services.product_telemetry_service import record_product_event, validate_product_event
from services.agent_run_queue import async_agent_runs_enabled, enqueue_agent_run
from services.operator_news_generation import classify_news_generate_intent, generate_news_draft_from_operator
from services.operator_paid_executor import build_paid_action_execution_attempt
from services.operator_paid_preflight import build_paid_action_preflight
from services.operator_refresh_result import build_refresh_result_status, list_refresh_jobs
from services.operator_refresh_recovery import build_refresh_recovery_plan, release_failed_refresh_reservation
from services.operator_refresh_retry import request_refresh_retry
from services.operator_review_reply_bulk import classify_bulk_review_reply_intent, generate_review_reply_drafts_for_unanswered_reviews
from services.operator_services_optimization import (
    apply_service_optimization_suggestions,
    classify_services_apply_intent,
    classify_services_optimize_intent,
    optimize_services_from_operator,
)
from services.operator_social_post_generation import classify_social_post_generate_intent, generate_social_post_draft_from_operator
from services.operator_core import (
    confirm_pending_operator_action,
    operator_capability_catalog,
    reject_pending_operator_action,
    route_operator_message,
)
from services.operator_conversations import (
    append_operator_message,
    conversation_pending_context,
    create_pending_operator_action,
    find_latest_operator_conversation,
    get_or_create_operator_conversation,
    list_pending_operator_actions,
    list_operator_messages,
    set_operator_pending_context,
)
from services.content_plan_service import create_generated_content_plan, delete_content_plan, generate_draft_for_plan_item, update_content_plan_item
from core.card_automation import get_card_automation_snapshot, save_card_automation_settings
from core.service_catalog_compression import build_service_catalog_compression_draft
from services.gigachat_client import analyze_screenshot_with_gigachat
from services.agent_source_ingestion import build_agent_source_from_upload
from services.llm import analyze_text_with_gigachat
from services.operator_map_refresh import DEFAULT_MAP_REFRESH_ESTIMATED_CREDITS, enqueue_paid_operator_map_refresh
from services.operator_review_canonicalization import CANONICAL_REVIEWS_CTE
from services.operator_services_optimization import SERVICES_OPTIMIZE_CREDITS_PER_SERVICE
from subscription_manager import build_subscription_capabilities, capability_access_payload, get_allowed_content_plan_horizons


operator_bp = Blueprint("operator_api", __name__, url_prefix="/api/operator")
logger = logging.getLogger(__name__)


def _content_handoff_status(metadata):
    from services.content_delivery_status import delivery_status
    return delivery_status(metadata)


def _inline_scope_subscription_access(scope: dict) -> dict | None:
    if "subscription_tier" not in scope and "subscription_status" not in scope:
        return None
    return build_subscription_capabilities(
        tier=str(scope.get("subscription_tier") or ""),
        status=str(scope.get("subscription_status") or ""),
        subscription_ends_at=scope.get("subscription_ends_at"),
    )


def _scope_subscription_access(cursor, scope: dict, is_superadmin: bool = False) -> dict:
    if is_superadmin or scope.get("kind") == "platform":
        return build_subscription_capabilities(tier="concierge", status="active", is_superadmin=True)
    business_ids = [str(item) for item in scope.get("business_ids") or [] if str(item)]
    if not business_ids and scope.get("kind") == "business" and scope.get("id"):
        business_ids = [str(scope.get("id"))]
    if not business_ids:
        return build_subscription_capabilities(tier="none", status="inactive")
    cursor.execute(
        """
        SELECT id, subscription_tier, subscription_status, subscription_ends_at
        FROM businesses
        WHERE id = ANY(%s)
          AND COALESCE(is_active, TRUE) = TRUE
        """,
        (business_ids,),
    )
    rows = [dict(row) for row in (cursor.fetchall() or [])]
    if len(rows) != len(business_ids):
        return build_subscription_capabilities(tier="none", status="inactive")
    row_access = [
        build_subscription_capabilities(
            tier=str(row.get("subscription_tier") or ""),
            status=str(row.get("subscription_status") or ""),
            subscription_ends_at=row.get("subscription_ends_at"),
        )
        for row in rows
    ]
    shared_capabilities = set(row_access[0].get("capabilities") or []) if row_access else set()
    for access in row_access[1:]:
        shared_capabilities.intersection_update(access.get("capabilities") or [])
    return {
        "tier": str(row_access[0].get("tier") or "none") if len(row_access) == 1 else "network",
        "tier_name": str(row_access[0].get("tier_name") or "Без тарифа") if len(row_access) == 1 else "Сеть",
        "status": str(row_access[0].get("status") or "inactive") if len(row_access) == 1 else "mixed",
        "active": bool(shared_capabilities),
        "capabilities": sorted(shared_capabilities),
    }


def _scope_capability_access(cursor, scope: dict, capability: str, is_superadmin: bool = False) -> dict:
    return capability_access_payload(_scope_subscription_access(cursor, scope, is_superadmin), capability)


def _mobile_payment_required_response(access: dict):
    return jsonify({
        "success": False,
        "error": "payment_required",
        "payment_required": True,
        **access,
        "billing_url": str((access.get("cta_target") or {}).get("url") or "/dashboard/profile?focus=subscription#subscription"),
        "return_to": request.full_path.rstrip("?"),
    }), 402


def _mobile_capability_for_action(action: str) -> str | None:
    normalized = str(action or "").strip().lower()
    for prefix, capability in MOBILE_ACTION_CAPABILITIES.items():
        if normalized.startswith(prefix):
            return capability
    return None


def _mobile_payload_item_capability(item: dict) -> str | None:
    cta = item.get("cta") if isinstance(item.get("cta"), dict) else {}
    route_text = " ".join(str(value or "").lower() for value in (
        item.get("screen"), item.get("target_screen"), item.get("category"),
        item.get("kind"), item.get("key"), item.get("capability"), cta.get("href"),
    ))
    route_markers = (
        (("average_ticket", "finance", "revenue", "sale"), "finance"),
        (("partnership", "partner"), "partnerships"),
        (("influencer", "creator"), "influencers"),
        (("agent",), "agents"),
        (("operator",), "operator"),
        (("social", "content", "post"), "social_content"),
        (("community", "feed", "radar"), "telegram_radar"),
        (("review",), "maps.reviews"),
        (("service",), "maps.services"),
        (("progress", "growth_step"), "progress"),
        (("card", "map"), "maps"),
    )
    for markers, capability in route_markers:
        if any(marker in route_text for marker in markers):
            return capability
    return None


def _mobile_filter_payload_items(value, subscription_access: dict):
    allowed_capabilities = set(subscription_access.get("capabilities") or [])
    if isinstance(value, list):
        return [
            _mobile_filter_payload_items(item, subscription_access)
            for item in value
            if not isinstance(item, dict)
            or not _mobile_payload_item_capability(item)
            or _mobile_payload_item_capability(item) in allowed_capabilities
        ]
    if isinstance(value, dict):
        return {key: _mobile_filter_payload_items(item, subscription_access) for key, item in value.items()}
    return value


def _decorate_mobile_journey_actions(payload: dict, subscription_access: dict) -> dict:
    actions = payload.get("journey_actions") if isinstance(payload.get("journey_actions"), list) else []
    decorated = []
    for raw_action in actions:
        if not isinstance(raw_action, dict):
            continue
        action = dict(raw_action)
        from api.lead_journey_api import FLOW_CAPABILITIES
        capability = FLOW_CAPABILITIES.get(str(action.get("flow_type") or ""), "management")
        access = capability_access_payload(subscription_access, capability)
        action["access"] = access
        if not access.get("allowed"):
            safe_commands = []
            if action.get("action_type") == "configure_automation" and "save_configuration" in (action.get("allowed_commands") or []):
                safe_commands.append("save_configuration")
            safe_commands.append("open_upgrade")
            action["allowed_commands"] = safe_commands
            action["cta_label"] = access.get("cta_label")
            from services.work_coherence import redact_unavailable_work
            action = redact_unavailable_work(action)
        decorated.append(action)
    payload["journey_actions"] = decorated
    if decorated and str((payload.get("focus_action") or {}).get("source") or "") == "lead_journey":
        focus = dict(payload.get("focus_action") or {})
        focus["cta_label"] = decorated[0].get("cta_label")
        focus["access"] = decorated[0].get("access")
        payload["focus_action"] = focus
    return payload


def _mobile_navigation(
    scope: dict,
    is_superadmin: bool = False,
    subscription_access: dict | None = None,
) -> list[dict]:
    kind = str(scope.get("kind") or "business")
    if subscription_access is None:
        subscription_access = _inline_scope_subscription_access(scope)
    enforce_capabilities = subscription_access is not None
    agent_runs_available = str(os.getenv("AGENT_ASYNC_RUNS_ENABLED", "false")).lower() in {"1", "true", "yes", "on"}
    items = [
        {"key": "today", "label": "Сегодня", "group": "primary", "status": "available", "available_actions": ["open_focus", "delegate"], "supported_scopes": ["business", "network", "platform"], "deep_link_targets": ["today"], "version": 2},
        {"key": "tasks", "label": "В работе", "group": "primary", "status": "available", "available_actions": ["open"], "supported_scopes": ["business", "network", "platform"], "deep_link_targets": ["task", "job", "approval"], "version": 3},
        {"key": "feed", "label": "Лента", "group": "primary", "status": "available", "available_actions": ["open_message"], "supported_scopes": ["business", "network", "platform"], "deep_link_targets": ["feed"], "version": 1},
        {"key": "reviews", "label": "Отзывы", "group": "more", "status": "available", "available_actions": ["generate_reply", "edit_draft", "mark_manual_published"], "supported_scopes": ["business", "network", "platform"], "deep_link_targets": ["review", "review_draft"], "version": 3},
        {"key": "operator", "label": "Управление через чат", "group": "primary", "status": "available", "available_actions": ["send_message", "open_result"], "supported_scopes": ["business", "network", "platform"], "deep_link_targets": ["operator_message", "operator_result"], "version": 2},
        {"key": "progress", "label": "Прогресс", "group": "primary", "status": "hidden" if kind == "platform" else "available", "reason": "Выберите бизнес или сеть" if kind == "platform" else "", "available_actions": ["open_next_step"], "supported_scopes": ["business", "network"], "deep_link_targets": ["progress", "growth_step"], "version": 3},
        {"key": "cards", "label": "Карточки", "group": "more", "status": "available", "available_actions": ["schedule_update", "refresh"], "supported_scopes": ["business", "network", "platform"], "deep_link_targets": ["card", "parse_job", "integration_error"], "version": 2},
        {"key": "content", "label": "Контент", "group": "more", "status": "available", "available_actions": ["plan_generate", "item_update", "draft_generate"], "supported_scopes": ["business", "network", "platform"], "deep_link_targets": ["content_plan", "content_item", "post"], "version": 2},
        {"key": "services", "label": "Услуги", "group": "more", "status": "available", "available_actions": ["update", "archive", "restore", "optimize", "compress"], "supported_scopes": ["business", "network", "platform"], "deep_link_targets": ["service", "service_suggestion"], "version": 2},
        {"key": "finance", "label": "Финансы", "group": "more", "status": "available", "available_actions": ["sales_import", "operation_update", "analytics_open", "crm_file_import", "crm_connection_request"], "supported_scopes": ["business", "network", "platform"], "deep_link_targets": ["finance", "sale", "finance_warning", "finance_import"], "version": 4},
        {"key": "partnerships", "label": "Партнёрства", "group": "more", "status": "available", "available_actions": ["search", "draft", "send_preview"], "supported_scopes": ["business", "network", "platform"], "deep_link_targets": ["partner", "partnership_reply", "outreach_touch"], "version": 2},
        {"key": "influencers", "label": "Инфлюенсеры", "group": "more", "status": "available", "available_actions": ["search", "prepare_offer", "open_workspace"], "supported_scopes": ["business"], "deep_link_targets": ["creator", "creator_candidate", "creator_collaboration"], "version": 1},
        {"key": "agents", "label": "ИИ-сотрудники", "group": "more", "status": "available" if agent_runs_available else "read_only", "reason": "Запуски пока не включены для этого бизнеса" if not agent_runs_available else "", "available_actions": ["run", "open_result"] if agent_runs_available else [], "supported_scopes": ["business", "network", "platform"], "deep_link_targets": ["agent", "agent_run", "agent_result"], "version": 2},
        {"key": "settings", "label": "Профиль и бизнес" if kind == "business" else "Настройки", "group": "more", "status": "available" if kind == "business" else "read_only", "reason": "Город, валюта и уведомления" if kind == "business" else "Выберите бизнес для настройки города и валюты", "available_actions": ["notifications_update", "input_settings_preview"] if kind == "business" else ["notifications_update"], "supported_scopes": ["business", "network", "platform"], "deep_link_targets": ["settings"], "version": 1},
    ]
    company_registry_miniapp_enabled = str(os.getenv("COMPANY_REGISTRY_MINIAPP_ENABLED", "false")).lower() in {"1", "true", "yes", "on"}
    if kind == "business":
        items.append({"key": "community_sources", "label": "Пульс сообщества", "group": "more", "status": "available", "available_actions": ["source_add", "subscription_update"], "supported_scopes": ["business"], "deep_link_targets": ["community_source"], "version": 2})
    if kind == "business" and company_registry_miniapp_enabled:
        items.append({"key": "company", "label": "Моя компания", "group": "more", "status": "available", "available_actions": ["open_profile", "add_to_work"], "supported_scopes": ["business"], "deep_link_targets": ["company"], "version": 2})
    if kind == "platform" and is_superadmin:
        if company_registry_miniapp_enabled:
            items.append({"key": "companies", "label": "Компании", "group": "more", "status": "available", "available_actions": ["search", "open_profile", "add_to_work"], "supported_scopes": ["platform"], "deep_link_targets": ["company"], "version": 2})
        items.append({"key": "diagnostics", "label": "Диагностика", "group": "more", "status": "available", "reason": "", "available_actions": ["retry_one"], "supported_scopes": ["platform"], "deep_link_targets": ["diagnostic_job", "integration_error"], "version": 2})
    if kind == 'business':
        items.append({'key':'work_journal','label':'Рабочий журнал','group':'more','status':'available','supported_scopes':['business'],'available_actions':['open'],'version':1})
    if enforce_capabilities:
        for item in items:
            capability = MOBILE_NAVIGATION_CAPABILITIES.get(str(item.get("key") or ""))
            if not capability or item.get("status") == "hidden":
                continue
            access = capability_access_payload(subscription_access or {}, capability)
            item["capability"] = capability
            item["required_tier"] = access.get("required_tier")
            item["required_tier_name"] = access.get("required_tier_name")
            item["billing_url"] = str((access.get("cta_target") or {}).get("url") or "")
            item["preview_available"] = not bool(access.get("allowed"))
            if not access.get("allowed"):
                if item.get("key") in {"influencers", "partnerships"}:
                    item["status"] = "available"
                    item["reason"] = "Каталог и shortlist доступны. Сообщения и отправка требуют тариф «Привлечение»."
                    item["available_actions"] = ["browse", "shortlist"]
                    item["operations_access"] = access
                    item["preview_available"] = False
                    continue
                item["status"] = "read_only"
                item["reason"] = access.get("reason")
                item["available_actions"] = []
    return items


def _mobile_active_job(cursor, *, user_id: str, scope: dict, is_superadmin: bool) -> dict | None:
    cursor.execute("SELECT to_regclass('public.operator_async_jobs') AS table_ref")
    if not dict(cursor.fetchone() or {}).get("table_ref"):
        return None
    business_ids = [str(item) for item in scope.get("business_ids") or []]
    cursor.execute(
        """
        SELECT id
        FROM operator_async_jobs
        WHERE user_id = %s
          AND status IN ('queued', 'running', 'waiting_for_review')
          AND (%s OR business_id = ANY(%s))
        ORDER BY updated_at DESC
        LIMIT 1
        """,
        (user_id, scope.get("kind") == "platform", business_ids),
    )
    active_row = cursor.fetchone()
    if not active_row:
        return None
    return load_operator_async_job(
        cursor,
        job_id=str(dict(active_row).get("id") or ""),
        user_id=user_id,
        scope=scope,
        is_superadmin=is_superadmin,
    )


def _mobile_task_item(item: dict) -> dict:
    value = dict(item)
    status = str(value.get("status") or "needs_attention")
    if status in {"draft", "generated", "pending_review", "approval_required"}:
        status = "needs_attention"
    elif status in {"queued", "running", "processing", "in_progress"}:
        status = "in_progress"
    elif status in {"completed", "manual_published", "done"}:
        status = "completed"
    value["status"] = status
    value["kind"] = str(value.get("kind") or value.get("id") or "operator_task")
    value["progress"] = value.get("progress") if value.get("progress") is not None else (100 if status == "completed" else None)
    value["available_actions"] = value.get("available_actions") or [value.get("primary_action") or "open"]
    return value


def _mobile_background_tasks(cursor, scope: dict) -> list[dict]:
    platform = scope.get("kind") == "platform"
    business_ids = [str(item) for item in scope.get("business_ids") or []]
    cursor.execute(
        """
        SELECT q.id, q.business_id, b.name AS business_name, q.status, q.task_type,
               q.error_message, q.retry_after, q.created_at, q.updated_at
        FROM parsequeue q
        LEFT JOIN businesses b ON b.id = q.business_id
        WHERE (%s OR q.business_id = ANY(%s))
          AND q.status IN ('pending', 'processing', 'completed', 'failed', 'error', 'captcha_required')
        ORDER BY q.updated_at DESC
        LIMIT 25
        """,
        (platform, business_ids),
    )
    tasks = []
    for value in cursor.fetchall() or []:
        row = dict(value)
        raw_status = str(row.get("status") or "")
        if raw_status in {"pending", "processing"}:
            status, progress, severity = "in_progress", None, "low"
            description = "Задача ждёт запуска." if raw_status == "pending" else "LocalOS собирает данные с карт. Экран можно закрыть."
        elif raw_status == "completed":
            status, progress, severity = "completed", 100, "low"
            description = "Данные собраны и готовы к просмотру."
        else:
            status, progress, severity = "needs_attention", None, "high"
            description = str(row.get("error_message") or "Обновление не завершилось. Повтор доступен только через отдельное подтверждение стоимости.")
        tasks.append({
            "id": f"refresh:{row.get('id')}",
            "object_id": row.get("id"),
            "kind": "map_refresh",
            "title": f"{'Обновление карточки'} · {row.get('business_name') or 'точка'}",
            "description": description,
            "status": status,
            "progress": progress,
            "severity": severity,
            "updated_at": row.get("updated_at"),
            "target_scope": {"kind": "business", "id": row.get("business_id")},
            "available_actions": ["open"] if status != "needs_attention" else [],
            "action_unavailable_reason": "Повтор платный и появится после preview" if status == "needs_attention" else None,
        })
    cursor.execute(
        """
        SELECT job.id, job.business_id, business.name AS business_name, job.kind,
               job.status, job.progress, job.stage, job.error_text, job.updated_at
        FROM operator_async_jobs job
        LEFT JOIN businesses business ON business.id = job.business_id
        WHERE (%s OR job.business_id = ANY(%s))
        ORDER BY job.updated_at DESC
        LIMIT 25
        """,
        (platform, business_ids),
    )
    job_titles = {
        "content_plan_generate": "Контент-план",
        "content_draft_generate": "Текст публикации",
        "finance_document_recognize": "Распознавание продаж",
        "finance_crm_sync": "Синхронизация CRM",
        "diagnostics_retry": "Повтор задачи",
    }
    for value in cursor.fetchall() or []:
        row = dict(value)
        raw_status = str(row.get("status") or "queued")
        status = "completed" if raw_status == "completed" else "needs_attention" if raw_status == "failed" else "in_progress"
        available_actions = ["open"]
        if raw_status == "failed" and str(row.get("kind") or "") in {"content_plan_generate", "content_draft_generate", "finance_document_recognize", "finance_crm_sync", "diagnostics_retry"}:
            available_actions.append("retry")
        tasks.append({
            "id": f"job:{row.get('id')}",
            "object_id": row.get("id"),
            "kind": "operator_async_job",
            "title": f"{job_titles.get(str(row.get('kind') or ''), 'Работа LocalOS')} · {row.get('business_name') or 'бизнес'}",
            "description": str(row.get("error_text") or row.get("stage") or "LocalOS выполняет задачу"),
            "status": status,
            "progress": int(row.get("progress") or 0),
            "severity": "high" if raw_status == "failed" else "low",
            "updated_at": row.get("updated_at"),
            "target_scope": {"kind": "business", "id": row.get("business_id")},
            "available_actions": available_actions,
        })
    return tasks


def _operator_mobile_route(result: dict) -> dict:
    intent = str(result.get("intent") or result.get("capability") or "").lower()
    if "review" in intent:
        return {"screen": "reviews", "filters": {"status": "drafts" if result.get("draft") or result.get("drafts") else "unanswered"}, "capability": result.get("capability") or intent}
    if "service" in intent:
        return {"screen": "services", "filters": {}, "capability": result.get("capability") or intent}
    if "news" in intent or "content" in intent or "social" in intent:
        return {"screen": "content", "filters": {}, "capability": result.get("capability") or intent}
    if "partnership" in intent or "outreach" in intent:
        return {"screen": "partnerships", "filters": {}, "capability": result.get("capability") or intent}
    return {"screen": "tasks", "filters": {}, "capability": result.get("capability") or intent or None}


def _scope_request_values(payload: dict | None = None) -> tuple[str, str | None]:
    source = payload if isinstance(payload, dict) else request.args
    kind = str(source.get("scope_type") or source.get("kind") or "").strip().lower()
    scope_id = str(source.get("scope_id") or source.get("id") or "").strip() or None
    return kind, scope_id


def _telegram_control_actor(cursor, payload: dict):
    verified = validate_telegram_webapp_init_data(payload.get("init_data"))
    if not verified:
        return None, None
    user = load_localos_user_for_telegram(cursor, str(verified.get("telegram_id") or ""))
    if not user:
        return None, None
    return verified, user


def _attach_ai_router(result: dict, ai_router: dict) -> dict:
    combined = dict(result)
    combined["ai_router"] = {
        "status": ai_router.get("status"),
        "intent": ai_router.get("normalized_intent"),
        "charged_credits": ai_router.get("charged_credits"),
        "credit_charged": ai_router.get("credit_charged"),
        "finalization_result": ai_router.get("finalization_result"),
    }
    return combined


def _unsupported_operator_result(message: str) -> dict:
    help_response = build_operator_help_response()
    return {
        "status": "unsupported",
        "intent": "unknown",
        "message": message,
        "chat_response": (
            "Не понял команду. Я могу помочь с карточкой, отзывами, новостями, постами и услугами.\n\n"
            + str(help_response.get("chat_response") or "")
        ),
        "blocked_reasons": ["unsupported_operator_chat_intent"],
        "ui_actions": help_response.get("ui_actions") or [],
        "external_calls_performed": False,
        "external_writes_performed": False,
        "manual_publication_only": True,
        "paid_actions_performed": False,
        "credit_charged": False,
    }


def _manual_review_guard_result(message: str) -> dict:
    return {
        "status": "blocked",
        "intent": "manual_review_add_and_reply",
        "message": message,
        "reply_text": "",
        "chat_response": (
            "Похоже, вы хотите добавить новый отзыв и подготовить ответ, но я не вижу явный текст отзыва. "
            "Пришлите команду в формате: «Добавь отзыв и сгенерируй ответ: текст отзыва»."
        ),
        "blocked_reasons": ["manual_review_text_not_explicit"],
        "external_calls_performed": False,
        "external_writes_performed": False,
        "manual_publication_only": True,
        "paid_actions_performed": False,
        "credit_charged": False,
    }


def _has_explicit_manual_review_text(message: str) -> bool:
    text = str(message or "").strip().lower()
    if "отзыв:" in text:
        return True
    if "добав" in text and "отзыв" in text and ":" in text:
        return True
    return False


@operator_bp.route("/scopes", methods=["GET"])
def operator_scopes():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    user_id = str(user_data.get("user_id") or user_data.get("id") or "")
    query = str(request.args.get("q") or "").strip()
    business_cursor = str(request.args.get("cursor") or "").strip()
    db = DatabaseManager()
    try:
        cursor = db.conn.cursor()
        catalog = list_control_scopes(
            cursor,
            user_id=user_id,
            search_query=query,
            business_limit=50,
            business_cursor=business_cursor,
        )
        requested_kind, requested_id = _scope_request_values()
        selected = resolve_control_scope(
            cursor,
            user_id=user_id,
            requested_kind=requested_kind,
            requested_id=requested_id,
        )
        return jsonify({"success": True, "catalog": catalog, "selected_scope": selected})
    finally:
        db.close()


@operator_bp.route("/summary", methods=["GET"])
def operator_scope_summary():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    user_id = str(user_data.get("user_id") or user_data.get("id") or "")
    kind, scope_id = _scope_request_values()
    db = DatabaseManager()
    try:
        cursor = db.conn.cursor()
        scope = resolve_control_scope(
            cursor,
            user_id=user_id,
            requested_kind=kind,
            requested_id=scope_id,
        )
        if not scope:
            return jsonify({"success": False, "error": "Контекст не найден или недоступен"}), 403
        summary = build_operator_scope_summary(cursor, scope=scope, user_id=user_id)
        return jsonify({"success": True, "summary": summary})
    finally:
        db.close()


@operator_bp.route("/telegram/bootstrap", methods=["POST"])
def operator_telegram_bootstrap():
    payload = request.get_json(silent=True) or {}
    if not isinstance(payload, dict):
        return jsonify({"success": False, "error": "Некорректный запрос"}), 400
    db = DatabaseManager()
    try:
        cursor = db.conn.cursor()
        verified, user = _telegram_control_actor(cursor, payload)
        if not verified or not user:
            return jsonify({"success": False, "error": "Telegram-сессия недействительна"}), 401
        user_id = str(user.get("id") or "")
        query = str(payload.get("q") or "").strip()
        business_cursor = str(payload.get("cursor") or "").strip()
        catalog = list_control_scopes(
            cursor,
            user_id=user_id,
            search_query=query,
            business_limit=50,
            business_cursor=business_cursor,
        )
        requested_kind, requested_id = _scope_request_values(payload)
        selected = resolve_control_scope(
            cursor,
            user_id=user_id,
            requested_kind=requested_kind,
            requested_id=requested_id,
        )
        if not selected and requested_kind:
            selected = resolve_control_scope(cursor, user_id=user_id)
        summary = build_operator_scope_summary(cursor, scope=selected, user_id=user_id) if selected else None
        preferences = load_control_preferences(cursor, user_id)
        web_session_token = None
        if not query:
            web_session_token = create_session(
                user_id,
                ip_address=request.headers.get("X-Forwarded-For") or request.remote_addr,
                user_agent="localos-telegram-mini-app",
                expires_days=1,
            )
        navigation = _mobile_navigation(
            selected or {},
            bool(user.get("is_superadmin")),
            _scope_subscription_access(cursor, selected or {}, bool(user.get("is_superadmin"))),
        )
        deep_link = resolve_mobile_deep_link(
            cursor,
            scope=selected or {},
            navigation=navigation,
            screen=str(payload.get("screen") or "today"),
            item_type=str(payload.get("item_type") or ""),
            item_id=str(payload.get("item_id") or ""),
            filters=payload.get("filters") if isinstance(payload.get("filters"), dict) else {},
        )
        active_job = _mobile_active_job(
            cursor,
            user_id=user_id,
            scope=selected or {},
            is_superadmin=bool(user.get("is_superadmin")),
        )
        return jsonify(
            {
                "success": True,
                "user": {
                    "id": user_id,
                    "name": str(user.get("name") or verified.get("first_name") or ""),
                    "is_superadmin": bool(user.get("is_superadmin")),
                },
                "catalog": catalog,
                "selected_scope": selected,
                "summary": summary,
                "preferences": preferences,
                "notification_preferences": preferences.get("notifications") if isinstance(preferences, dict) else {},
                "deep_link_targets": [item["key"] for item in navigation if item.get("status") != "hidden"],
                "resolved_deep_link": deep_link,
                "active_job": active_job,
                "web_session_token": web_session_token,
                "mini_app_v2_enabled": str(os.getenv("TELEGRAM_MINI_APP_V2_ENABLED", "true")).lower() in {"1", "true", "yes", "on"},
                "today_v2_enabled": str(os.getenv("TELEGRAM_MINI_APP_TODAY_V2_ENABLED", "true")).lower() in {"1", "true", "yes", "on"},
                "navigation": navigation,
            }
        )
    finally:
        db.close()


@operator_bp.route("/telegram/scope", methods=["POST"])
def operator_telegram_select_scope():
    payload = request.get_json(silent=True) or {}
    if not isinstance(payload, dict):
        return jsonify({"success": False, "error": "Некорректный запрос"}), 400
    kind, scope_id = _scope_request_values(payload)
    db = DatabaseManager()
    try:
        cursor = db.conn.cursor()
        verified, user = _telegram_control_actor(cursor, payload)
        if not verified or not user:
            return jsonify({"success": False, "error": "Telegram-сессия недействительна"}), 401
        user_id = str(user.get("id") or "")
        scope = resolve_control_scope(
            cursor,
            user_id=user_id,
            requested_kind=kind,
            requested_id=scope_id,
            persist=True,
            telegram_id=str(verified.get("telegram_id") or ""),
        )
        if not scope:
            db.conn.rollback()
            return jsonify({"success": False, "error": "Контекст не найден или недоступен"}), 403
        db.conn.commit()
        summary = build_operator_scope_summary(cursor, scope=scope, user_id=user_id)
        active_job = _mobile_active_job(
            cursor,
            user_id=user_id,
            scope=scope,
            is_superadmin=bool(user.get("is_superadmin")),
        )
        return jsonify({"success": True, "selected_scope": scope, "summary": summary, "active_job": active_job})
    except Exception:
        db.conn.rollback()
        raise
    finally:
        db.close()


@operator_bp.route("/mobile/network-locations", methods=["GET"])
def operator_mobile_network_locations():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    user_id = str(user_data.get("user_id") or user_data.get("id") or "")
    network_id = str(request.args.get("network_id") or "").strip()
    if not network_id:
        return jsonify({"success": False, "error": "Не указана сеть"}), 400
    try:
        offset = max(0, int(str(request.args.get("cursor") or "0")))
    except (TypeError, ValueError):
        offset = 0
    db = DatabaseManager()
    try:
        cursor = db.conn.cursor()
        scope = resolve_control_scope(
            cursor,
            user_id=user_id,
            requested_kind="network",
            requested_id=network_id,
        )
        if not scope:
            return jsonify({"success": False, "error": "Сеть недоступна"}), 403
        result = list_network_scope_locations(
            cursor,
            scope=scope,
            search_query=str(request.args.get("q") or ""),
            limit=100,
            offset=offset,
        )
        return jsonify(
            {
                "success": True,
                "scope": scope,
                "items": result["items"],
                "counts": {"total": result["total"]},
                "cursor": result["next_cursor"],
                "as_of": datetime.now(timezone.utc).isoformat(),
                "freshness": {"is_stale": False},
                "data_warnings": [],
                "available_actions": ["open_network_summary", "select_location"],
                "filters": {"search": True},
            }
        )
    finally:
        db.close()


@operator_bp.route("/telegram/favorite", methods=["POST"])
def operator_telegram_toggle_favorite():
    payload = request.get_json(silent=True) or {}
    if not isinstance(payload, dict):
        return jsonify({"success": False, "error": "Некорректный запрос"}), 400
    db = DatabaseManager()
    try:
        cursor = db.conn.cursor()
        verified, user = _telegram_control_actor(cursor, payload)
        if not verified or not user:
            return jsonify({"success": False, "error": "Telegram-сессия недействительна"}), 401
        user_id = str(user.get("id") or "")
        scope = resolve_control_scope(cursor, user_id=user_id)
        if not scope:
            return jsonify({"success": False, "error": "Рабочий раздел не найден"}), 404
        favorite = toggle_favorite_control_scope(
            cursor,
            user_id=user_id,
            telegram_id=str(verified.get("telegram_id") or ""),
            scope=scope,
        )
        db.conn.commit()
        return jsonify({"success": True, "favorite": favorite, "preferences": load_control_preferences(cursor, user_id)})
    except Exception:
        db.conn.rollback()
        raise
    finally:
        db.close()


@operator_bp.route("/attention-brief", methods=["GET"])
def operator_attention_brief():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    business_id = str(request.args.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        brief = build_attention_brief(cursor, business_id, user_id)
        record_operator_event(
            cursor,
            business_id=business_id,
            user_id=user_id,
            event_type="operator_context_built",
            input_summary={"query": brief.get("query"), "data_mode": brief.get("data_mode")},
            output_summary={
                "signals_count": (brief.get("summary") or {}).get("signals_count"),
                "paid_action_offers": len(brief.get("paid_action_offers") or []),
            },
            metadata={
                "data_mode": brief.get("data_mode"),
                "paid_refresh_required_for_fresh_data": (brief.get("freshness") or {}).get("paid_refresh_required_for_fresh_data"),
            },
        )
        db.conn.commit()
        return jsonify({"success": True, "brief": brief})
    except Exception:
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/inbox", methods=["GET"])
def operator_inbox():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    business_id = str(request.args.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        inbox = build_operator_inbox(cursor, business_id=business_id, user_id=user_id)
        record_operator_event(
            cursor,
            business_id=business_id,
            user_id=user_id,
            event_type="operator_context_built",
            status="completed",
            input_summary={"query": "operator_inbox"},
            output_summary={
                "items_count": (inbox.get("summary") or {}).get("items_count"),
                "paid_generation_offers": len(inbox.get("paid_generation_offers") or []),
            },
            metadata={
                "external_writes_performed": False,
                "manual_publication_only": True,
            },
        )
        db.conn.commit()
        return jsonify({"success": True, "inbox": inbox})
    except Exception:
        db.conn.rollback()
        error_id = str(uuid.uuid4())
        logger.exception("Operator inbox failed error_id=%s business_id=%s", error_id, business_id)
        return jsonify({
            "success": False,
            "error": "Не удалось загрузить входящие задачи. Повторите позже или сообщите код ошибки поддержке.",
            "error_code": "operator_inbox_failed",
            "error_id": error_id,
        }), 500
    finally:
        db.close()


@operator_bp.route("/actions/<action_id>/reject", methods=["POST"])
def reject_operator_action_request(action_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    payload = request.get_json(silent=True) or {}
    business_id = str(payload.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            return jsonify({"success": False, "error": "Нет доступа" if owner_id else "Бизнес не найден"}), 403 if owner_id else 404
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        result, idempotent = reject_pending_operator_action(
            cursor,
            action_id=action_id,
            business_id=business_id,
            user_id=user_id,
        )
        if "action_not_found" in list(result.get("blocked_reasons") or []):
            return jsonify({"success": False, "error": "Действие не найдено"}), 404
        db.conn.commit()
        return jsonify({
            "success": str(result.get("status") or "") == "rejected",
            "idempotent": idempotent,
            "operator_result": result,
        })
    except Exception:
        db.conn.rollback()
        error_id = str(uuid.uuid4())
        logger.exception("Operator action rejection failed error_id=%s action_id=%s", error_id, action_id)
        return jsonify({
            "success": False,
            "error": "Не удалось отклонить действие.",
            "error_code": "operator_action_rejection_failed",
            "error_id": error_id,
        }), 500
    finally:
        db.close()


@operator_bp.route("/consent-policy", methods=["GET"])
def operator_consent_policy_list():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    business_id = str(request.args.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        policies = list_consent_policies(cursor, business_id)
        return jsonify({"success": True, "policies": policies})
    except Exception:
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/consent-policy/<action_key>", methods=["PUT"])
def operator_consent_policy_update(action_key: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    payload = request.get_json(silent=True) or {}
    business_id = str(payload.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        policy, errors = upsert_consent_policy(cursor, business_id, action_key, user_id, payload)
        if errors or policy is None:
            return jsonify({"success": False, "error": "invalid_consent_policy", "details": errors}), 400
        record_operator_event(
            cursor,
            business_id=business_id,
            user_id=user_id,
            event_type="operator_consent_decision",
            action_key=action_key,
            status="completed",
            input_summary={"requested_mode": payload.get("mode")},
            output_summary={
                "mode": policy.get("mode"),
                "execution_allowed_without_prompt": policy.get("execution_allowed_without_prompt"),
            },
            metadata={
                "policy_id": policy.get("id"),
                "max_credits_per_action": policy.get("max_credits_per_action"),
                "max_credits_per_day": policy.get("max_credits_per_day"),
                "max_credits_per_month": policy.get("max_credits_per_month"),
                "low_balance_warning_threshold": policy.get("low_balance_warning_threshold"),
            },
        )
        db.conn.commit()
        return jsonify({"success": True, "policy": policy})
    except Exception:
        db.conn.rollback()
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/paid-actions/<action_key>/preflight", methods=["POST"])
def operator_paid_action_preflight(action_key: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    payload = request.get_json(silent=True) or {}
    business_id = str(payload.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        preflight = build_paid_action_preflight(
            cursor,
            business_id=business_id,
            user_id=user_id,
            action_key=action_key,
            estimated_credits=payload.get("estimated_credits"),
            explicit_consent=bool(payload.get("explicit_consent")),
        )
        record_operator_event(
            cursor,
            business_id=business_id,
            user_id=user_id,
            event_type="operator_paid_action_estimated",
            action_key=action_key,
            status=str(preflight.get("status") or "recorded"),
            reason_code=",".join(preflight.get("blocked_reasons") or []) or None,
            input_summary={
                "estimated_credits": payload.get("estimated_credits"),
                "explicit_consent": bool(payload.get("explicit_consent")),
            },
            output_summary={
                "status": preflight.get("status"),
                "would_be_allowed": preflight.get("would_be_allowed"),
                "execution_status": preflight.get("execution_status"),
            },
            metadata={
                "estimated_credits": preflight.get("estimated_credits"),
                "balance_credits": preflight.get("balance_credits"),
                "usage_window": preflight.get("usage_window"),
                "blocked_reasons": preflight.get("blocked_reasons"),
                "warnings": preflight.get("warnings"),
                "execution_status": preflight.get("execution_status"),
                "execution_enabled": preflight.get("execution_enabled"),
            },
        )
        db.conn.commit()
        return jsonify({"success": True, "preflight": preflight})
    except Exception:
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/paid-actions/<action_key>/execute", methods=["POST"])
def operator_paid_action_execute(action_key: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    payload = request.get_json(silent=True) or {}
    business_id = str(payload.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        execution = build_paid_action_execution_attempt(
            cursor,
            business_id=business_id,
            user_id=user_id,
            action_key=action_key,
            estimated_credits=payload.get("estimated_credits"),
            explicit_consent=bool(payload.get("explicit_consent")),
        )
        record_operator_event(
            cursor,
            business_id=business_id,
            user_id=user_id,
            event_type="operator_execution_blocked",
            action_key=action_key,
            status=str(execution.get("status") or "blocked"),
            reason_code=",".join(execution.get("blocked_reasons") or []) or None,
            input_summary={
                "estimated_credits": payload.get("estimated_credits"),
                "explicit_consent": bool(payload.get("explicit_consent")),
            },
            output_summary={
                "status": execution.get("status"),
                "execution_status": execution.get("execution_status"),
                "next_step": execution.get("next_step"),
            },
            metadata={
                "estimated_credits": execution.get("estimated_credits"),
                "balance_credits": execution.get("balance_credits"),
                "adapter_status": (execution.get("adapter_result") or {}).get("adapter_status"),
                "adapter_runtime_mode": (execution.get("adapter_result") or {}).get("runtime_mode"),
                "adapter_dry_run": (execution.get("adapter_result") or {}).get("dry_run"),
                "adapter_idempotency_key": (execution.get("adapter_result") or {}).get("idempotency_key"),
                "reservation_status": (execution.get("reservation_plan") or {}).get("status"),
                "reservation_requested_credits": (execution.get("reservation_plan") or {}).get("requested_credits"),
                "reservation_blocked_reasons": (execution.get("reservation_plan") or {}).get("blocked_reasons"),
                "reservation_result_status": (execution.get("reservation_result") or {}).get("status"),
                "usage_window": (execution.get("preflight") or {}).get("usage_window"),
                "finalization_result_status": (execution.get("finalization_result") or {}).get("status"),
                "rollback_result_status": (execution.get("rollback_result") or {}).get("status"),
                "credit_charged": execution.get("credit_charged"),
                "credit_released": execution.get("credit_released"),
                "internal_fake_execution_performed": execution.get("internal_fake_execution_performed"),
                "blocked_reasons": execution.get("blocked_reasons"),
                "warnings": execution.get("warnings"),
                "execution_status": execution.get("execution_status"),
                "execution_enabled": execution.get("execution_enabled"),
                "credit_reserved": execution.get("credit_reserved"),
                "parsequeue_jobs_created": execution.get("parsequeue_jobs_created"),
                "ai_generation_performed": execution.get("ai_generation_performed"),
            },
        )
        db.conn.commit()
        return jsonify({"success": True, "execution": execution})
    except Exception:
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/capabilities", methods=["GET"])
def operator_capabilities():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    return jsonify({"success": True, "capabilities": operator_capability_catalog()})


@operator_bp.route("/conversations/<conversation_id>/messages", methods=["GET"])
def operator_conversation_messages(conversation_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    business_id = str(request.args.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            return jsonify({"success": False, "error": "Нет доступа" if owner_id else "Бизнес не найден"}), 403 if owner_id else 404
        cursor.execute("SELECT id FROM operatorconversations WHERE id=%s AND business_id=%s AND user_id=%s", (conversation_id,business_id,str(user_data.get('user_id') or user_data.get('id'))))
        if not cursor.fetchone():
            return jsonify({"success": False, "error": "Диалог недоступен"}), 403
        items = list_operator_messages(
            cursor,
            conversation_id=conversation_id,
            business_id=business_id,
            limit=request.args.get("limit") or 100,
        )
        return jsonify({"success": True, "conversation_id": conversation_id, "messages": items})
    finally:
        db.close()


@operator_bp.route("/conversations/current", methods=["GET"])
def current_operator_conversation():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    business_id = str(request.args.get("business_id") or "").strip()
    channel = str(request.args.get("channel") or "web").strip() or "web"
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            return jsonify({"success": False, "error": "Нет доступа" if owner_id else "Бизнес не найден"}), 403 if owner_id else 404
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        conversation = find_latest_operator_conversation(
            cursor,
            business_id=business_id,
            user_id=user_id,
            channel=channel,
        )
        conversation_id = str(conversation.get("id") or "")
        messages = list_operator_messages(
            cursor,
            conversation_id=conversation_id,
            business_id=business_id,
            limit=request.args.get("limit") or 100,
        ) if conversation_id else []
        return jsonify({"success": True, "conversation": conversation or None, "messages": messages})
    finally:
        db.close()


@operator_bp.route('/requests', methods=['GET'])
@operator_bp.route('/requests/<receipt_id>', methods=['GET'])
@operator_bp.route('/requests/<receipt_id>/feedback', methods=['POST'])
def operator_request_history(receipt_id=None):
    from services import operator_request_history
    user = require_auth_from_request()
    if not user:
        return jsonify({'error': 'Требуется авторизация'}), 401
    payload = request.get_json(silent=True) or {}
    business_id = request.args.get('business_id') or payload.get('business_id')
    if not business_id:
        return jsonify({'error': 'Выберите бизнес'}), 400
    db = DatabaseManager()
    try:
        cursor = db.conn.cursor()
        # Preserve session restrictions (including a demo session's business).
        if not verify_business_access(cursor, business_id, user)[0]:
            raise PermissionError('Нет доступа к бизнесу')
        user_id = user.get('user_id') or user.get('id')
        if request.method == 'POST':
            result = operator_request_history.feedback(cursor, business_id, user_id, receipt_id, payload.get('comment'))
            db.conn.commit()
        elif receipt_id:
            result = operator_request_history.detail(cursor, business_id, user_id, receipt_id)
        else:
            result = operator_request_history.list_requests(cursor, business_id, user_id, request.args)
        return jsonify(result)
    except PermissionError:
        return jsonify({'error': str(sys.exception())}), 403
    except ValueError:
        return jsonify({'error': str(sys.exception())}), 400
    finally:
        db.close()


@operator_bp.route("/chat", methods=["POST"])
def operator_chat():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    payload = request.get_json(silent=True) or {}
    business_id = str(payload.get("business_id") or "").strip()
    message = str(payload.get("message") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400
    if not message:
        return jsonify({"success": False, "error": "message обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message_text = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message_text}), status_code
        business_scope = {"kind": "business", "id": business_id, "business_ids": [business_id]}
        access = _scope_capability_access(cursor, business_scope, "operator", bool(user_data.get("is_superadmin")))
        if not access.get("allowed"):
            return _mobile_payment_required_response(access)

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        record_operator_event(
            cursor,
            business_id=business_id,
            user_id=user_id,
            event_type="operator_message_received",
            status="received",
            input_summary={"message": message[:500]},
            output_summary={"channel": "web"},
        )
        selected_action = None
        selected_action_id = str(payload.get("journey_action_id") or "").strip()
        if selected_action_id:
            try:
                uuid.UUID(selected_action_id)
            except ValueError:
                return jsonify({"success": False, "error": "invalid_action_id"}), 400
            from services.lead_journey_service import load_action, JourneyError
            try:
                selected_action = load_action(cursor, action_id=selected_action_id, business_id=business_id)
            except JourneyError as failure:
                return jsonify({"success": False, "error": str(failure)}), failure.status_code
            from api.lead_journey_api import FLOW_CAPABILITIES
            capability = FLOW_CAPABILITIES.get(str(selected_action.get("flow_type") or ""))
            if capability:
                selected_access = capability_access_payload(_scope_subscription_access(cursor, business_scope, bool(user_data.get("is_superadmin"))), capability)
                if not selected_access.get("allowed"):
                    return jsonify({"success": False, "error": "payment_required", **selected_access}), 402
            payload = dict(payload)
            source_payload = selected_action.get("payload_json") or {}
            if selected_action.get("entity_type") == "work_observation" and source_payload.get("source_entry_id"):
                from services import work_review
                if not work_review.can_review(cursor, business_id, user_id):
                    return jsonify({"success": False, "error": "Нет доступа к разбору журнала"}), 403
                linked = work_review.links(cursor, business_id, user_id, source_payload["source_entry_id"])
                if not any(str(item["id"]) == selected_action_id for item in linked):
                    return jsonify({"success": False, "error": "Нет доступа к связанной задаче"}), 403
        from services.work_coherence import internal_work_ref, unavailable_work_context
        work_ref = internal_work_ref(payload.get('work_ref'), business_id)
        from services.operator_chat_service import process_chat
        def selected_work_router(selected_cursor, **arguments):
            if selected_action is not None:
                from services.work_coherence import discuss_existing_work
                return discuss_existing_work(selected_action, business_id), {}
            if work_ref and not payload.get('selected_object'):
                return unavailable_work_context(work_ref), {}
            return route_operator_message(selected_cursor, **arguments)
        result = process_chat(
            cursor, business_id=business_id, user_id=user_id,
            channel=str(payload.get("channel") or "web"), message=message, payload=payload,
            router=selected_work_router,
            subscription_access=_scope_subscription_access(cursor, business_scope, bool(user_data.get("is_superadmin"))),
            actor_context={"role": "business_owner" if owner_id == user_id else "business_user", "is_superadmin": bool(user_data.get("is_superadmin")), "permissions": ["business.access"], "session_kind": user_data.get("session_kind", "standard"), "scope_business_id": user_data.get('scope_business_id'), "impersonating": bool(user_data.get("impersonating") or user_data.get("impersonated_by"))},
            refresh_handler=refresh_reviews_from_operator, ai_router_handler=classify_operator_intent_with_ai,
            manual_review_handler=process_operator_chat_message,
        )
        conversation_id = result["conversation_id"]
        result["mobile_route"] = _operator_mobile_route(result)
        cursor.execute("UPDATE operatormessages SET result_json=%s::jsonb WHERE id=%s AND user_id=%s", (json.dumps(result,ensure_ascii=False,default=str),result.get('message_id'),user_id))
        if payload.get('request_id'):
            cursor.execute("UPDATE operator_chat_requests SET result_json=%s::jsonb WHERE user_id=%s AND business_id=%s AND channel=%s AND request_id=%s", (json.dumps(result,ensure_ascii=False,default=str),user_id,business_id,str(payload.get('channel') or 'web'),str(payload['request_id'])))
        status = str(result.get("status") or "blocked")
        review = result.get("review") if isinstance(result.get("review"), dict) else {}
        draft = result.get("draft") if isinstance(result.get("draft"), dict) else {}
        news_draft = result.get("news_draft") if isinstance(result.get("news_draft"), dict) else {}
        social_post_draft = result.get("social_post_draft") if isinstance(result.get("social_post_draft"), dict) else {}
        optimization_job = result.get("optimization_job") if isinstance(result.get("optimization_job"), dict) else {}
        drafts = result.get("drafts") if isinstance(result.get("drafts"), list) else []
        finalization = result.get("finalization_result") if isinstance(result.get("finalization_result"), dict) else {}
        tool_plan_finalization = (
            result.get("tool_plan_finalization_result")
            if isinstance(result.get("tool_plan_finalization_result"), dict)
            else {}
        )
        ai_router = result.get("ai_router") if isinstance(result.get("ai_router"), dict) else {}
        ai_router_finalization = (
            ai_router.get("finalization_result")
            if isinstance(ai_router.get("finalization_result"), dict)
            else {}
        )
        tool_trace = result.get("tool_trace") if isinstance(result.get("tool_trace"), list) else []
        for tool_step in tool_trace:
            if not isinstance(tool_step, dict):
                continue
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_tool_executed",
                action_key=str(tool_step.get("tool") or "operator_tool"),
                status=str(tool_step.get("status") or "completed"),
                input_summary={"step": tool_step.get("step")},
                output_summary={"risk_class": tool_step.get("risk_class")},
                metadata={
                    "conversation_id": conversation_id,
                    "tool": tool_step.get("tool"),
                    "external_writes_performed": bool(result.get("external_writes_performed")),
                },
            )
        if ai_router_finalization:
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_usage_charged",
                action_key="operator_intent_classify",
                status=str(ai_router_finalization.get("status") or "completed"),
                input_summary={"action_key": "operator_intent_classify"},
                output_summary={
                    "charge_credits": ai_router_finalization.get("charge_credits"),
                    "release_credits": ai_router_finalization.get("release_credits"),
                    "normalized_intent": ai_router.get("intent"),
                },
                metadata={
                    "credit_charged": bool(ai_router_finalization.get("side_effects", {}).get("credit_charged")),
                    "paid_actions_performed": bool(ai_router_finalization.get("side_effects", {}).get("credit_charged")),
                    "external_writes_performed": False,
                },
            )
        if tool_plan_finalization:
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_usage_charged",
                action_key="operator_tool_plan",
                status=str(tool_plan_finalization.get("status") or "completed"),
                input_summary={"action_key": "operator_tool_plan"},
                output_summary={
                    "charge_credits": tool_plan_finalization.get("charge_credits"),
                    "release_credits": tool_plan_finalization.get("release_credits"),
                    "planner_steps": result.get("planner_steps"),
                },
                metadata={
                    "credit_charged": bool(tool_plan_finalization.get("side_effects", {}).get("credit_charged")),
                    "paid_actions_performed": bool(tool_plan_finalization.get("side_effects", {}).get("credit_charged")),
                    "external_writes_performed": False,
                },
            )
        if review:
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_review_added",
                status="completed",
                input_summary={"source": review.get("source")},
                output_summary={"review_id": review.get("id")},
                metadata={"review_id": review.get("id"), "external_writes_performed": False},
            )
        if draft:
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_draft_created",
                action_key="review_replies_generate",
                status="completed",
                input_summary={"review_id": draft.get("review_id")},
                output_summary={"draft_id": draft.get("id")},
                metadata={"draft_id": draft.get("id"), "external_writes_performed": False},
            )
        if news_draft:
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_draft_created",
                action_key="news_generate",
                status="completed",
                input_summary={"source": "operator_chat"},
                output_summary={"news_id": news_draft.get("id")},
                metadata={
                    "news_id": news_draft.get("id"),
                    "external_writes_performed": False,
                    "manual_publication_only": True,
                },
            )
        if optimization_job:
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_draft_created",
                action_key="services_optimize",
                status="completed",
                input_summary={"source": "operator_chat"},
                output_summary={"job_id": optimization_job.get("id")},
                metadata={
                    "job_id": optimization_job.get("id"),
                    "external_writes_performed": False,
                    "manual_apply_required": True,
                },
            )
        if social_post_draft:
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_draft_created",
                action_key="social_post_generate",
                status="completed",
                input_summary={"source": "operator_chat"},
                output_summary={"draft_id": social_post_draft.get("id")},
                metadata={
                    "draft_id": social_post_draft.get("id"),
                    "external_writes_performed": False,
                    "manual_publication_only": True,
                },
            )
        for bulk_draft in drafts:
            if not isinstance(bulk_draft, dict):
                continue
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_draft_created",
                action_key="review_replies_generate",
                status="completed",
                input_summary={"review_id": bulk_draft.get("review_id")},
                output_summary={"draft_id": bulk_draft.get("id")},
                metadata={"draft_id": bulk_draft.get("id"), "external_writes_performed": False},
            )
        if finalization:
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_usage_charged",
                action_key=str(result.get("executed_intent") or result.get("intent") or "review_replies_generate"),
                status=str(finalization.get("status") or status),
                input_summary={"action_key": str(result.get("executed_intent") or result.get("intent") or "review_replies_generate")},
                output_summary={
                    "charge_credits": finalization.get("charge_credits"),
                    "release_credits": finalization.get("release_credits"),
                },
                metadata={
                    "credit_charged": bool(finalization.get("side_effects", {}).get("credit_charged")),
                    "paid_actions_performed": bool(finalization.get("side_effects", {}).get("credit_charged")),
                    "external_writes_performed": False,
                },
            )
        db.conn.commit()
        return jsonify({
            "success": status in {"completed", "queued", "processing", "clarification_required", "manual_handoff", "approval_required"},
            "conversation_id": result.get("conversation_id"),
            "operator_result": result,
        })
    except (ValueError, PermissionError):
        db.conn.rollback()
        return jsonify({"success": False, "error": "Запрос или диалог недоступен. Обновите чат и повторите."}), 400
    except Exception:
        db.conn.rollback()
        error_id = str(uuid.uuid4())
        logger.exception("Operator chat failed error_id=%s business_id=%s", error_id, business_id)
        return jsonify({
            "success": False,
            "error": "Оператор временно недоступен. Повторите запрос или сообщите код ошибки поддержке.",
            "error_code": "operator_chat_failed",
            "error_id": error_id,
        }), 500
    finally:
        db.close()


@operator_bp.route("/actions/<action_id>/confirm", methods=["POST"])
def confirm_operator_action(action_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    payload = request.get_json(silent=True) or {}
    business_id = str(payload.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            return jsonify({"success": False, "error": "Нет доступа" if owner_id else "Бизнес не найден"}), 403 if owner_id else 404
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        result, idempotent = confirm_pending_operator_action(
            cursor,
            subscription_access=_scope_subscription_access(cursor, {'kind': 'business', 'id': business_id, 'business_ids': [business_id]}, bool(user_data.get('is_superadmin'))),
            actor_context=user_data,
            action_id=action_id,
            business_id=business_id,
            user_id=user_id,
        )
        if "action_not_found" in list(result.get("blocked_reasons") or []):
            return jsonify({"success": False, "error": "Действие не найдено"}), 404
        db.conn.commit()
        return jsonify({
            "success": str(result.get("status") or "") == "completed",
            "idempotent": idempotent,
            "operator_result": result,
        })
    except Exception:
        db.conn.rollback()
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/review-replies/generate", methods=["POST"])
def operator_review_replies_generate():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    payload = request.get_json(silent=True) or {}
    business_id = str(payload.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        result = generate_review_reply_drafts_for_unanswered_reviews(
            cursor,
            business_id=business_id,
            user_id=user_id,
            limit=payload.get("limit") or 5,
            review_id=payload.get("review_id"),
            channel="web",
        )
        status = str(result.get("status") or "blocked")
        drafts = result.get("drafts") if isinstance(result.get("drafts"), list) else []
        for draft in drafts:
            if not isinstance(draft, dict):
                continue
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_draft_created",
                action_key="review_replies_generate",
                status="completed",
                input_summary={"review_id": draft.get("review_id")},
                output_summary={"draft_id": draft.get("id")},
                metadata={"draft_id": draft.get("id"), "external_writes_performed": False},
            )
        finalization = result.get("finalization_result") if isinstance(result.get("finalization_result"), dict) else {}
        if finalization:
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_usage_charged",
                action_key="review_replies_generate",
                status=str(finalization.get("status") or status),
                input_summary={"action_key": "review_replies_generate"},
                output_summary={
                    "charge_credits": finalization.get("charge_credits"),
                    "release_credits": finalization.get("release_credits"),
                },
                metadata={
                    "credit_charged": bool(finalization.get("side_effects", {}).get("credit_charged")),
                    "paid_actions_performed": bool(finalization.get("side_effects", {}).get("credit_charged")),
                    "external_writes_performed": False,
                },
            )
        db.conn.commit()
        return jsonify({"success": status == "completed", "operator_result": result})
    except Exception:
        db.conn.rollback()
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/reviews/refresh-results/<queue_id>", methods=["GET"])
def operator_review_refresh_result(queue_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    business_id = str(request.args.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        result = build_refresh_result_status(
            cursor,
            business_id=business_id,
            user_id=user_id,
            queue_id=queue_id,
        )
        record_operator_event(
            cursor,
            business_id=business_id,
            user_id=user_id,
            event_type="operator_context_built",
            action_key="map_reviews_refresh",
            status=str(result.get("status") or "blocked"),
            reason_code=",".join(result.get("blocked_reasons") or []) or None,
            input_summary={"queue_id": queue_id},
            output_summary={
                "queue_status": result.get("queue_status"),
                "new_reviews_count": result.get("new_reviews_count"),
                "new_unanswered_reviews_count": result.get("new_unanswered_reviews_count"),
            },
            metadata={
                "external_writes_performed": False,
                "manual_publication_only": True,
            },
        )
        db.conn.commit()
        return jsonify({"success": result.get("status") in {"completed", "processing"}, "refresh_result": result})
    except Exception:
        db.conn.rollback()
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/reviews/refresh-jobs", methods=["GET"])
def operator_review_refresh_jobs():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    business_id = str(request.args.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        result = list_refresh_jobs(
            cursor,
            business_id=business_id,
            user_id=user_id,
            limit=request.args.get("limit") or 10,
        )
        record_operator_event(
            cursor,
            business_id=business_id,
            user_id=user_id,
            event_type="operator_context_built",
            action_key="map_reviews_refresh",
            status=str(result.get("status") or "completed"),
            input_summary={"query": "operator_refresh_jobs"},
            output_summary=result.get("summary") or {},
            metadata={
                "external_writes_performed": False,
                "manual_publication_only": True,
            },
        )
        db.conn.commit()
        return jsonify({"success": True, "refresh_jobs": result})
    except Exception:
        db.conn.rollback()
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/reviews/refresh-jobs/<queue_id>/retry", methods=["POST"])
def operator_review_refresh_job_retry(queue_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    payload = request.get_json(silent=True) or {}
    business_id = str(payload.get("business_id") or request.args.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        result = request_refresh_retry(
            cursor,
            business_id=business_id,
            user_id=user_id,
            queue_id=queue_id,
            estimated_credits=payload.get("estimated_credits"),
            confirm_retry=bool(payload.get("confirm_retry")),
        )
        record_operator_event(
            cursor,
            business_id=business_id,
            user_id=user_id,
            event_type="operator_tool_executed" if result.get("status") == "queued" else "operator_execution_blocked",
            action_key="map_reviews_refresh",
            status=str(result.get("status") or "blocked"),
            reason_code=",".join(result.get("blocked_reasons") or []) or None,
            input_summary={"queue_id": queue_id, "retry": True},
            output_summary={
                "new_queue_id": result.get("new_queue_id"),
                "reservation_id": result.get("reservation_id"),
                "estimated_credits": result.get("estimated_credits"),
            },
            metadata={
                "source_queue_id": queue_id,
                "retry_requested": True,
                "external_writes_performed": False,
                "manual_publication_only": True,
                "credit_reserved": bool((result.get("side_effects") or {}).get("credit_reserved")),
            },
        )
        db.conn.commit()
        return jsonify({"success": result.get("status") == "queued", "retry_result": result})
    except Exception:
        db.conn.rollback()
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/reviews/refresh-jobs/<queue_id>/recovery", methods=["GET", "POST"])
def operator_review_refresh_job_recovery(queue_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    payload = request.get_json(silent=True) or {}
    business_id = str(payload.get("business_id") or request.args.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        if request.method == "POST" and bool(payload.get("confirm_release")):
            result = release_failed_refresh_reservation(
                cursor,
                business_id=business_id,
                user_id=user_id,
                queue_id=queue_id,
                confirm_release=True,
            )
            event_type = "operator_tool_executed" if result.get("status") == "released" else "operator_execution_blocked"
            status_value = str(result.get("status") or "blocked")
        else:
            result = build_refresh_recovery_plan(
                cursor,
                business_id=business_id,
                user_id=user_id,
                queue_id=queue_id,
            )
            event_type = "operator_context_built"
            status_value = str(result.get("status") or "blocked")

        record_operator_event(
            cursor,
            business_id=business_id,
            user_id=user_id,
            event_type=event_type,
            action_key="map_reviews_refresh",
            status=status_value,
            reason_code=",".join(result.get("blocked_reasons") or []) or None,
            input_summary={"queue_id": queue_id, "recovery": True, "method": request.method},
            output_summary={
                "retry_allowed": result.get("retry_allowed"),
                "release_allowed": result.get("release_allowed"),
                "reservation_id": result.get("reservation_id"),
                "outstanding_credits": result.get("outstanding_credits"),
            },
            metadata={
                "external_writes_performed": False,
                "manual_publication_only": True,
                "reservation_released": bool((result.get("side_effects") or {}).get("reservation_released")),
            },
        )
        db.conn.commit()
        return jsonify({"success": result.get("status") in {"ready", "released"}, "recovery_result": result})
    except Exception:
        db.conn.rollback()
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/content-history", methods=["GET"])
def operator_content_history():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    business_id = str(request.args.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        history = list_operator_content_history(
            cursor,
            business_id=business_id,
            user_id=user_id,
            limit=request.args.get("limit") or 20,
        )
        record_operator_event(
            cursor,
            business_id=business_id,
            user_id=user_id,
            event_type="operator_context_built",
            action_key="content_history_read",
            status=str(history.get("status") or "completed"),
            input_summary={"query": "operator_content_history"},
            output_summary=history.get("summary") or {},
            metadata={
                "external_writes_performed": False,
                "manual_publication_only": True,
            },
        )
        db.conn.commit()
        return jsonify({"success": True, "content_history": history})
    except Exception:
        db.conn.rollback()
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/services/optimize", methods=["POST"])
def operator_services_optimize():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    payload = request.get_json(silent=True) or {}
    business_id = str(payload.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        result = optimize_services_from_operator(
            cursor,
            business_id=business_id,
            user_id=user_id,
            limit=payload.get("limit") or 5,
            channel="web",
        )
        status = str(result.get("status") or "blocked")
        optimization_job = result.get("optimization_job") if isinstance(result.get("optimization_job"), dict) else {}
        if optimization_job:
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_draft_created",
                action_key="services_optimize",
                status="completed",
                input_summary={"source": "operator_inbox"},
                output_summary={"job_id": optimization_job.get("id")},
                metadata={
                    "job_id": optimization_job.get("id"),
                    "external_writes_performed": False,
                    "manual_apply_required": True,
                },
            )
        finalization = result.get("finalization_result") if isinstance(result.get("finalization_result"), dict) else {}
        if finalization:
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_usage_charged",
                action_key="services_optimize",
                status=str(finalization.get("status") or status),
                input_summary={"action_key": "services_optimize"},
                output_summary={
                    "charge_credits": finalization.get("charge_credits"),
                    "release_credits": finalization.get("release_credits"),
                },
                metadata={
                    "credit_charged": bool(finalization.get("side_effects", {}).get("credit_charged")),
                    "paid_actions_performed": bool(finalization.get("side_effects", {}).get("credit_charged")),
                    "external_writes_performed": False,
                    "manual_apply_required": True,
                },
            )
        db.conn.commit()
        return jsonify({"success": status == "completed", "operator_result": result})
    except Exception:
        db.conn.rollback()
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/services/optimize/apply", methods=["POST"])
def operator_services_optimize_apply():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    payload = request.get_json(silent=True) or {}
    business_id = str(payload.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        result = apply_service_optimization_suggestions(
            cursor,
            business_id=business_id,
            user_id=user_id,
            job_id=payload.get("job_id"),
            item_ids=payload.get("item_ids"),
            limit=payload.get("limit") or 5,
            channel="web",
            explicit_confirmation=bool(payload.get("confirm_apply")),
        )
        status = str(result.get("status") or "blocked")
        record_operator_event(
            cursor,
            business_id=business_id,
            user_id=user_id,
            event_type="operator_tool_executed",
            action_key="services_optimize_apply",
            status=status,
            input_summary={
                "job_id": payload.get("job_id"),
                "item_ids": payload.get("item_ids") if isinstance(payload.get("item_ids"), list) else [],
            },
            output_summary={
                "applied_count": result.get("applied_count"),
                "job_status": (result.get("optimization_job") or {}).get("status") if isinstance(result.get("optimization_job"), dict) else None,
            },
            metadata={
                "external_writes_performed": False,
                "manual_approval_received": bool(result.get("manual_approval_received")),
                "explicit_confirmation": bool(payload.get("confirm_apply")),
                "paid_actions_performed": False,
                "credit_charged": False,
            },
        )
        db.conn.commit()
        return jsonify({"success": status == "completed", "operator_result": result})
    except Exception:
        db.conn.rollback()
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/social-posts/generate", methods=["POST"])
def operator_social_posts_generate():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    payload = request.get_json(silent=True) or {}
    business_id = str(payload.get("business_id") or "").strip()
    message = str(payload.get("message") or payload.get("source_text") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400
    if not message:
        return jsonify({"success": False, "error": "message обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message_text = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message_text}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        result = generate_social_post_draft_from_operator(
            cursor,
            business_id=business_id,
            user_id=user_id,
            message=message,
            channel="web",
        )
        status = str(result.get("status") or "blocked")
        social_post_draft = result.get("social_post_draft") if isinstance(result.get("social_post_draft"), dict) else {}
        if social_post_draft:
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_draft_created",
                action_key="social_post_generate",
                status="completed",
                input_summary={"source": "operator_inbox"},
                output_summary={"draft_id": social_post_draft.get("id")},
                metadata={
                    "draft_id": social_post_draft.get("id"),
                    "external_writes_performed": False,
                    "manual_publication_only": True,
                },
            )
        finalization = result.get("finalization_result") if isinstance(result.get("finalization_result"), dict) else {}
        if finalization:
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_usage_charged",
                action_key="social_post_generate",
                status=str(finalization.get("status") or status),
                input_summary={"action_key": "social_post_generate"},
                output_summary={
                    "charge_credits": finalization.get("charge_credits"),
                    "release_credits": finalization.get("release_credits"),
                },
                metadata={
                    "credit_charged": bool(finalization.get("side_effects", {}).get("credit_charged")),
                    "paid_actions_performed": bool(finalization.get("side_effects", {}).get("credit_charged")),
                    "external_writes_performed": False,
                },
            )
        db.conn.commit()
        return jsonify({"success": status == "completed", "operator_result": result})
    except Exception:
        db.conn.rollback()
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/news/generate", methods=["POST"])
def operator_news_generate():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    payload = request.get_json(silent=True) or {}
    business_id = str(payload.get("business_id") or "").strip()
    message = str(payload.get("message") or payload.get("source_text") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400
    if not message:
        return jsonify({"success": False, "error": "message обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message_text = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message_text}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        result = generate_news_draft_from_operator(
            cursor,
            business_id=business_id,
            user_id=user_id,
            message=message,
            channel="web",
        )
        status = str(result.get("status") or "blocked")
        news_draft = result.get("news_draft") if isinstance(result.get("news_draft"), dict) else {}
        if news_draft:
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_draft_created",
                action_key="news_generate",
                status="completed",
                input_summary={"source": "operator_inbox"},
                output_summary={"news_id": news_draft.get("id")},
                metadata={
                    "news_id": news_draft.get("id"),
                    "external_writes_performed": False,
                    "manual_publication_only": True,
                },
            )
        finalization = result.get("finalization_result") if isinstance(result.get("finalization_result"), dict) else {}
        if finalization:
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="operator_usage_charged",
                action_key="news_generate",
                status=str(finalization.get("status") or status),
                input_summary={"action_key": "news_generate"},
                output_summary={
                    "charge_credits": finalization.get("charge_credits"),
                    "release_credits": finalization.get("release_credits"),
                },
                metadata={
                    "credit_charged": bool(finalization.get("side_effects", {}).get("credit_charged")),
                    "paid_actions_performed": bool(finalization.get("side_effects", {}).get("credit_charged")),
                    "external_writes_performed": False,
                },
            )
        db.conn.commit()
        return jsonify({"success": status == "completed", "operator_result": result})
    except Exception:
        db.conn.rollback()
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


@operator_bp.route("/review-reply-drafts/<draft_id>/mark-manual-published", methods=["POST"])
def operator_review_reply_draft_mark_manual_published(draft_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    payload = request.get_json(silent=True) or {}
    business_id = str(payload.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        result = mark_review_reply_draft_manual_published(
            cursor,
            business_id=business_id,
            user_id=user_id,
            draft_id=draft_id,
        )
        status = str(result.get("status") or "blocked")
        record_operator_event(
            cursor,
            business_id=business_id,
            user_id=user_id,
            event_type="operator_manual_publish_marked",
            channel="web",
            action_key="review_replies_generate",
            status=status,
            reason_code=",".join(result.get("blocked_reasons") or []) or None,
            input_summary={"draft_id": draft_id},
            output_summary={"status": status},
            metadata={
                "draft_id": draft_id,
                "manual_publication_only": True,
                "external_writes_performed": False,
            },
        )
        db.conn.commit()
        return jsonify({"success": status == "completed", "manual_publish": result})
    except Exception:
        db.conn.rollback()
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()


def _resolve_mobile_scope(cursor, user_data: dict) -> dict | None:
    user_id = str(user_data.get("user_id") or user_data.get("id") or "")
    kind, scope_id = _scope_request_values()
    return resolve_control_scope(
        cursor,
        user_id=user_id,
        requested_kind=kind,
        requested_id=scope_id,
    )


def _resolve_operator_read_scope(cursor, user_data: dict) -> dict | None:
    """Resolve neutral web scope while preserving the legacy business_id query."""
    user_id = str(user_data.get("user_id") or user_data.get("id") or "")
    kind, scope_id = _scope_request_values()
    legacy_business_id = str(request.args.get("business_id") or "").strip()
    if not kind and legacy_business_id:
        kind, scope_id = "business", legacy_business_id
    if str(user_data.get("session_kind") or "standard") == "demo":
        demo_business_id = str(user_data.get("scope_business_id") or "").strip()
        if not demo_business_id or kind not in {"", "business"} or str(scope_id or demo_business_id) != demo_business_id:
            return None
        kind, scope_id = "business", demo_business_id
    return resolve_control_scope(cursor, user_id=user_id, requested_kind=kind, requested_id=scope_id)


@operator_bp.route("/mobile/workspace", methods=["GET"])
def operator_mobile_workspace():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        subscription_access = _scope_subscription_access(cursor, scope, bool(user_data.get("is_superadmin")))
        summary = build_operator_scope_summary(cursor, scope=scope, user_id=user_id)
        summary = _mobile_filter_payload_items(summary, subscription_access)
        items = list(summary.get("attention_items") or [])
        if scope.get("kind") == "business":
            inbox = build_operator_inbox(cursor, business_id=str(scope.get("id") or ""), user_id=user_id)
            items = list(inbox.get("items") or [])
        items.extend(_mobile_background_tasks(cursor, scope))
        items = [_mobile_task_item(item) for item in items]
        items = _mobile_filter_payload_items(items, subscription_access)
        attention_count = len([item for item in items if item.get("status") == "needs_attention"])
        working_count = len([item for item in items if item.get("status") == "in_progress"])
        completed_count = len([item for item in items if item.get("status") == "completed"])
        return jsonify({
            "success": True,
            "scope": scope,
            "items": items,
            "counts": {
                "attention": attention_count,
                "working": working_count,
                "completed": completed_count,
                "total": len(items),
            },
            "cursor": None,
            "as_of": datetime.now(timezone.utc).isoformat(),
            "data_warnings": summary.get("data_warnings") or [],
            "available_actions": summary.get("available_actions") or [],
            "filters": {"statuses": ["needs_attention", "in_progress", "completed"]},
            "freshness": summary.get("freshness") or {"status": "live"},
            "summary": summary,
            "navigation": _mobile_navigation(
                scope,
                bool(user_data.get("is_superadmin")),
                subscription_access,
            ),
        })
    finally:
        db.close()


@operator_bp.route("/mobile/today", methods=["GET"])
def operator_mobile_today():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    if str(os.getenv("TELEGRAM_MINI_APP_TODAY_V2_ENABLED", "true")).lower() not in {"1", "true", "yes", "on"}:
        return jsonify({"success": False, "error": "Новый экран пока не включён"}), 404
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        payload = build_mobile_today(cursor, scope=scope, user_id=user_id)
        subscription_access = _scope_subscription_access(cursor, scope, bool(user_data.get("is_superadmin")))
        payload = _mobile_filter_payload_items(payload, subscription_access)
        payload = _decorate_mobile_journey_actions(payload, subscription_access)
        return jsonify({"success": True, **payload})
    finally:
        db.close()


@operator_bp.route("/mobile/feed", methods=["GET"])
def operator_mobile_feed():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    try:
        limit = min(max(int(request.args.get("limit") or 20), 1), 50)
    except (TypeError, ValueError):
        return jsonify({"success": False, "error": "Некорректный размер страницы"}), 400
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        access = _scope_capability_access(cursor, scope, "telegram_radar", bool(user_data.get("is_superadmin")))
        if not access.get("allowed"):
            return _mobile_payment_required_response(access)
        payload = build_mobile_feed(
            cursor,
            scope=scope,
            limit=limit,
            page_cursor=str(request.args.get("cursor") or "") or None,
        )
        return jsonify({"success": True, **payload})
    finally:
        db.close()


@operator_bp.route("/feed", methods=["GET"])
def operator_feed():
    """Return the canonical community feed for authenticated product surfaces."""
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    try:
        limit = min(max(int(request.args.get("limit") or 20), 1), 50)
    except (TypeError, ValueError):
        return jsonify({"success": False, "error": "Некорректный размер страницы"}), 400
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        payload = build_mobile_feed(
            cursor,
            scope=scope,
            limit=limit,
            page_cursor=str(request.args.get("cursor") or "") or None,
        )
        return jsonify({"success": True, **payload})
    finally:
        db.close()


@operator_bp.route("/today", methods=["GET"])
def operator_today():
    """Return the canonical daily brief for authenticated web clients.

    The payload intentionally comes from the same scope-aware builder as the
    Mini App.  The web route is not coupled to the Telegram feature flag, but
    it still resolves and verifies the requested scope on the server.
    """
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_operator_read_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        if scope.get("kind") == "platform":
            return jsonify({"success": False, "error": "Выберите бизнес или сеть"}), 409
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        payload = build_mobile_today(cursor, scope=scope, user_id=user_id)
        return jsonify({"success": True, **payload})
    finally:
        db.close()


@operator_bp.route("/content/today", methods=["GET"])
def operator_content_today():
    """Read-only publication overview for the selected authorized scope or LocalOS platform."""
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_operator_read_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        if scope.get("kind") == "platform" and not bool(user_data.get("is_superadmin")):
            return jsonify({"success": False, "error": "Раздел доступен только администратору LocalOS"}), 403
        platform_scope = scope.get("kind") == "platform"
        business_ids = [str(value) for value in scope.get("business_ids") or []]
        from_date_text = str(request.args.get("from_date") or "").strip()
        to_date_text = str(request.args.get("to_date") or "").strip()
        try:
            from_date = date.fromisoformat(from_date_text) if from_date_text else None
            to_date = date.fromisoformat(to_date_text) if to_date_text else None
        except ValueError:
            return jsonify({"success": False, "error": "Дата должна быть в формате YYYY-MM-DD"}), 400
        if bool(from_date) != bool(to_date):
            return jsonify({"success": False, "error": "Укажите обе границы периода"}), 400
        if from_date and to_date and (to_date < from_date or (to_date - from_date).days > 90):
            return jsonify({"success": False, "error": "Период должен быть от 1 до 91 дня"}), 400
        cursor.execute(
            """SELECT b.id, b.name, b.address,
                      COALESCE(NULLIF(settings.timezone, ''), to_jsonb(b)->>'timezone') AS timezone
               FROM businesses b
               LEFT JOIN business_finance_settings settings ON settings.business_id = b.id
               WHERE b.entity_group = 'client' AND COALESCE(b.is_active, TRUE) = TRUE
                 AND (%s OR b.id = ANY(%s))
               ORDER BY b.name""",
            (platform_scope, business_ids),
        )
        businesses = [dict(row) for row in cursor.fetchall() or []]
        zones: dict[str, tuple[ZoneInfo, str]] = {}
        warnings: list[str] = []
        now_utc = datetime.now(timezone.utc)
        for business in businesses:
            business_id = str(business.get("id") or "")
            zone_name = str(business.get("timezone") or "").strip()
            if not zone_name:
                zones[business_id] = (ZoneInfo("UTC"), "UTC")
                warnings.append(f"{business.get('name')}: часовой пояс не задан, даты показаны по UTC.")
                continue
            try:
                zones[business_id] = (ZoneInfo(zone_name), zone_name)
            except (ZoneInfoNotFoundError, ValueError):
                zones[business_id] = (ZoneInfo("UTC"), "UTC")
                warnings.append(f"{business.get('name')}: неизвестный часовой пояс «{zone_name}», даты показаны по UTC.")
        if not businesses:
            return jsonify({"success": True, "businesses": [], "warnings": warnings})
        if from_date and to_date:
            utc_start = datetime.combine(from_date - timedelta(days=2), datetime.min.time(), tzinfo=timezone.utc)
            utc_end = datetime.combine(to_date + timedelta(days=3), datetime.min.time(), tzinfo=timezone.utc)
        else:
            utc_start, utc_end = now_utc - timedelta(days=1), now_utc + timedelta(days=2)
        cursor.execute(
            """SELECT post.id, post.business_id, post.content_plan_item_id, post.platform,
                      post.status, post.publish_mode, post.scheduled_for,
                      COALESCE(NULLIF(BTRIM(item.theme), ''), NULLIF(BTRIM(post.platform_text), ''), 'Без темы') AS title,
                      post.provider_post_url, post.metadata_json
               FROM social_posts post
               LEFT JOIN contentplanitems item ON item.id = post.content_plan_item_id
               WHERE post.business_id = ANY(%s)
                 AND post.scheduled_for >= %s AND post.scheduled_for < %s
               ORDER BY post.business_id, post.scheduled_for, post.platform""",
            ([str(item.get("id")) for item in businesses], utc_start, utc_end),
        )
        posts = [dict(row) for row in cursor.fetchall() or []]
        grouped: dict[str, list[dict]] = {str(item.get("id")): [] for item in businesses}
        scheduled_item_ids: set[str] = set()
        for post in posts:
            business_id = str(post.get("business_id") or "")
            zone_info = zones.get(business_id)
            scheduled = post.get("scheduled_for")
            if not zone_info or not isinstance(scheduled, (datetime, date)):
                continue
            if isinstance(scheduled, datetime):
                scheduled_utc = scheduled.replace(tzinfo=timezone.utc) if scheduled.tzinfo is None else scheduled.astimezone(timezone.utc)
                local_time = scheduled_utc.astimezone(zone_info[0])
            else:
                local_time = datetime.combine(scheduled, datetime.min.time(), tzinfo=zone_info[0])
            local_today = now_utc.astimezone(zone_info[0]).date()
            if from_date and to_date:
                if not (from_date <= local_time.date() <= to_date):
                    continue
            elif local_time.date() != local_today:
                continue
            metadata = post.get("metadata_json")
            if isinstance(metadata, str):
                try:
                    metadata = json.loads(metadata)
                except (TypeError, ValueError):
                    metadata = {}
            handoff_status = _content_handoff_status(metadata)
            grouped.setdefault(business_id, []).append({
                "id": str(post.get("id") or ""), "channel": str(post.get("platform") or ""),
                "status": str(post.get("status") or "unknown"), "publish_mode": str(post.get("publish_mode") or ""),
                "scheduled_for": local_time.isoformat(), "title": str(post.get("title") or "Без темы"),
                "url": str(post.get("provider_post_url") or "") or None,
                "local_date": local_time.date().isoformat(),
                "handoff_status": handoff_status,
            })
            if post.get("content_plan_item_id"):
                scheduled_item_ids.add(str(post.get("content_plan_item_id")))
        cursor.execute(
            """SELECT item.id, item.business_id, item.status, item.scheduled_for,
                      COALESCE(NULLIF(BTRIM(item.theme), ''), 'Без темы') AS title
               FROM contentplanitems item
               JOIN contentplans plan ON plan.id = item.plan_id
               WHERE item.business_id = ANY(%s)
                 AND COALESCE(plan.plan_status, '') <> 'archived'
                 AND COALESCE(item.status, '') NOT IN ('archived', 'published')
                 AND item.scheduled_for >= %s AND item.scheduled_for < %s
               ORDER BY item.business_id, item.scheduled_for""",
            ([str(item.get("id")) for item in businesses], utc_start, utc_end),
        )
        for item in cursor.fetchall() or []:
            plan_item = dict(item)
            business_id = str(plan_item.get("business_id") or "")
            item_id = str(plan_item.get("id") or "")
            if item_id in scheduled_item_ids or business_id not in zones:
                continue
            scheduled = plan_item.get("scheduled_for")
            if not isinstance(scheduled, (datetime, date)):
                continue
            zone = zones[business_id][0]
            if isinstance(scheduled, datetime):
                scheduled_utc = scheduled.replace(tzinfo=timezone.utc) if scheduled.tzinfo is None else scheduled.astimezone(timezone.utc)
                local_time = scheduled_utc.astimezone(zone)
            else:
                local_time = datetime.combine(scheduled, datetime.min.time(), tzinfo=zone)
            local_today = now_utc.astimezone(zone).date()
            if (from_date and to_date and from_date <= local_time.date() <= to_date) or (
                not from_date and local_time.date() == local_today
            ):
                grouped.setdefault(business_id, []).append({
                    "id": item_id, "channel": "не подготовлено", "status": str(plan_item.get("status") or "planned"),
                    "publish_mode": "", "scheduled_for": local_time.isoformat(),
                    "title": str(plan_item.get("title") or "Без темы"), "url": None,
                })
        return jsonify({"success": True, "date": now_utc.date().isoformat(), "businesses": [
            {"id": str(item.get("id")), "name": str(item.get("name") or "Без названия"),
             "address": str(item.get("address") or ""),
             "timezone": zones.get(str(item.get("id")), (ZoneInfo("UTC"), "UTC"))[1],
             "posts": grouped.get(str(item.get("id")), [])}
            for item in businesses
        ], "from_date": from_date.isoformat() if from_date else None,
            "to_date": to_date.isoformat() if to_date else None, "warnings": warnings})
    finally:
        db.close()


@operator_bp.route("/today/preference", methods=["GET", "POST"])
def operator_today_preference():
    from core.auth_context import AuthContext
    from services.today_preferences_service import (
        PreferenceError, change_preferences, enabled, read_preferences, schema_available,
    )
    from services.today_workspace import allowed_priority_flows
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    auth = AuthContext.from_session(user_data)
    if not enabled():
        return jsonify({"success": False, "error": "personalization_disabled"}), 404
    if request.method == "POST" and (auth.session_kind == "demo" or auth.impersonating):
        return jsonify({"success": False, "error": "read_only_session"}), 403
    command = request.get_json(silent=True) if request.method == "POST" else {}
    if not isinstance(command, dict):
        return jsonify({"success": False, "error": "invalid_command"}), 400
    db = DatabaseManager()
    try:
        cursor = db.conn.cursor()
        scope = _resolve_operator_read_scope(cursor, user_data)
        if not scope or scope.get("kind") not in {"business", "network"}:
            return jsonify({"success": False, "error": "scope_unavailable"}), 403
        if not schema_available(cursor):
            return jsonify({"success": False, "error": "personalization_unavailable"}), 503
        allowed = allowed_priority_flows(cursor, scope=scope, is_superadmin=auth.is_superadmin)
        if request.method == "GET":
            result = read_preferences(cursor, user_id=auth.user_id, scope=scope, allowed_flows=allowed)
        else:
            result = change_preferences(cursor, user_id=auth.user_id, scope=scope, command=command, allowed_flows=allowed)
            db.conn.commit()
        result["preference"]["available_flows"] = allowed
        return jsonify({"success": True, **result})
    except PreferenceError:
        db.conn.rollback()
        error = sys.exc_info()[1]
        return jsonify({"success": False, "error": error.code, "code": error.code}), error.status
    except Exception:
        db.conn.rollback()
        raise
    finally:
        db.close()


@operator_bp.route("/progress", methods=["GET"])
def operator_progress():
    """Return the canonical scope-aware progress payload for web clients."""
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_operator_read_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        if scope.get("kind") == "platform":
            return jsonify({"success": False, "error": "Выберите бизнес или сеть"}), 409
        access = _scope_capability_access(cursor, scope, "progress", bool(user_data.get("is_superadmin")))
        if not access.get("allowed"):
            return _mobile_payment_required_response(access)
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        payload = build_mobile_progress(cursor, scope=scope, user_id=user_id)
        return jsonify({"success": True, **payload})
    finally:
        db.close()


@operator_bp.route("/mobile/progress", methods=["GET"])
def operator_mobile_progress():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        access = _scope_capability_access(cursor, scope, "progress", bool(user_data.get("is_superadmin")))
        if not access.get("allowed"):
            return _mobile_payment_required_response(access)
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        payload = build_mobile_progress(cursor, scope=scope, user_id=user_id)
        if payload.get("status") == "hidden":
            return jsonify({"success": False, "error": "Прогресс доступен после выбора бизнеса или сети"}), 409
        return jsonify({"success": True, **payload})
    finally:
        db.close()


@operator_bp.route("/mobile/interaction", methods=["POST"])
def operator_mobile_interaction():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    payload = request.get_json(silent=True) or {}
    event_name = str(payload.get("event_name") or "").strip()
    _, _, validation_error = validate_product_event(event_name, "telegram_mini_app")
    if validation_error:
        return jsonify({"success": False, "error": validation_error}), 400
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        business_ids = [str(item) for item in scope.get("business_ids") or [] if str(item)]
        business_id = str(scope.get("id") or "") if scope.get("kind") == "business" else (business_ids[0] if business_ids else "")
        record_operator_event(
            cursor,
            business_id=business_id,
            user_id=str(user_data.get("user_id") or user_data.get("id") or ""),
            event_type="operator_mobile_interaction",
            channel="telegram_mini_app",
            action_key=event_name,
            status="completed",
            input_summary={"screen": payload.get("screen")},
            output_summary={"target": payload.get("target")},
            metadata={
                "event_name": event_name,
                "scope_type": scope.get("kind"),
                "scope_id": scope.get("id"),
            },
        )
        record_product_event(
            cursor,
            event_name=event_name,
            surface="telegram_mini_app",
            business_id=business_id or None,
            user_id=str(user_data.get("user_id") or user_data.get("id") or "") or None,
            scope_type=str(scope.get("kind") or "") or None,
            scope_id=str(scope.get("id") or "") or None,
            screen=str(payload.get("screen") or ""),
            target=str(payload.get("target") or ""),
        )
        db.conn.commit()
        return jsonify({"success": True})
    except Exception:
        db.conn.rollback()
        raise
    finally:
        db.close()


@operator_bp.route("/mobile/modules/<module>", methods=["GET"])
def operator_mobile_module(module: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    allowed_modules = {"cards", "content", "services", "finance", "analytics", "partnerships", "agents", "settings", "diagnostics"}
    if module not in allowed_modules or module in {"today", "tasks", "reviews", "operator"}:
        return jsonify({"success": False, "error": "Раздел пока недоступен"}), 404
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        capability = MOBILE_MODULE_CAPABILITIES.get(module)
        if capability:
            access = _scope_capability_access(cursor, scope, capability, bool(user_data.get("is_superadmin")))
            if not access.get("allowed"):
                return jsonify({
                    "success": True,
                    "status": "payment_required",
                    "scope": scope,
                    "access": access,
                    "items": [],
                    "counts": {"total": 0},
                    "cursor": None,
                    "as_of": datetime.now(timezone.utc).isoformat(),
                    "data_warnings": [],
                    "available_actions": [],
                    "filters": {},
                    "preview": {
                        "title": "Посмотрите, как работает раздел",
                        "summary": access.get("reason"),
                        "skeleton_count": 3,
                    },
                })
        if module == "settings":
            user_id = str(user_data.get("user_id") or user_data.get("id") or "")
            preferences = load_control_preferences(cursor, user_id)
            notifications = preferences.get("notification_preferences_json") if isinstance(preferences, dict) else {}
            preference_key = f"{scope.get('kind')}:{scope.get('id') or 'all'}"
            return jsonify({
                "success": True,
                "status": "available",
                "scope": scope,
                "items": [{"id": "notifications", "kind": "settings", "title": "Уведомления", "subtitle": "Настройки для выбранного масштаба", "status": "active"}],
                "counts": {"total": 1},
                "cursor": None,
                "as_of": datetime.now(timezone.utc).isoformat(),
                "freshness": {"status": "live"},
                "data_warnings": [],
                "available_actions": [{"key": "notifications.update", "label": "Сохранить"}],
                "filters": {},
                "preferences": (notifications or {}).get(preference_key, {}),
            })
        if module == "diagnostics" and scope.get("kind") != "platform":
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        result = list_operator_mobile_module(cursor, module=module, scope=scope)
        if module == "content" and scope.get("kind") == "business" and scope.get("id"):
            filters = result.get("filters") if isinstance(result.get("filters"), dict) else {}
            filters["period_days"] = get_allowed_content_plan_horizons(str(scope.get("id")))
            filters["density"] = ["light", "standard", "active"]
            result["filters"] = filters
        return jsonify({"success": True, **result})
    finally:
        db.close()


def _mobile_scope_allows_business(scope: dict, business_id: str) -> bool:
    if scope.get("kind") == "platform":
        return True
    return business_id in {str(item) for item in scope.get("business_ids") or []}


def _mobile_business_from_payload(
    cursor,
    user_data: dict,
    payload: dict,
    required_capability: str | None = None,
) -> tuple[dict | None, str, tuple | None]:
    user_id = str(user_data.get("user_id") or user_data.get("id") or "")
    kind, scope_id = _scope_request_values(payload)
    scope = resolve_control_scope(cursor, user_id=user_id, requested_kind=kind, requested_id=scope_id)
    business_id = str(payload.get("business_id") or (scope or {}).get("id") or "").strip()
    if not scope:
        return None, business_id, (jsonify({"success": False, "error": "Раздел недоступен"}), 403)
    if scope.get("kind") != "business" and not payload.get("business_id"):
        return scope, "", (jsonify({"success": False, "error": "Сначала выберите точку"}), 400)
    if not business_id or not _mobile_scope_allows_business(scope, business_id):
        return scope, business_id, (jsonify({"success": False, "error": "Точка недоступна"}), 403)
    has_access, _owner_id = verify_business_access(cursor, business_id, user_data)
    if not has_access:
        return scope, business_id, (jsonify({"success": False, "error": "Точка недоступна"}), 403)
    if required_capability:
        business_scope = {"kind": "business", "id": business_id, "business_ids": [business_id]}
        access = _scope_capability_access(cursor, business_scope, required_capability, bool(user_data.get("is_superadmin")))
        if not access.get("allowed"):
            return scope, business_id, _mobile_payment_required_response(access)
    return scope, business_id, None


@operator_bp.route("/mobile/cards/schedule", methods=["PUT"])
def operator_mobile_card_schedule_update():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    payload = request.get_json(silent=True) or {}
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope, business_id, error_response = _mobile_business_from_payload(cursor, user_data, payload, "maps")
        if error_response:
            return error_response
        current = get_card_automation_snapshot(db.conn, business_id).get("settings") or {}
        merged = dict(current)
        merged.update({
            "review_sync_enabled": bool(payload.get("enabled")),
            "review_sync_interval_hours": int(payload.get("interval_hours") or 24),
            "review_sync_schedule_mode": "interval",
            "review_sync_schedule_days": [],
            "review_sync_schedule_time": None,
        })
        snapshot = save_card_automation_settings(
            db.conn,
            business_id,
            str(user_data.get("user_id") or user_data.get("id") or ""),
            merged,
        )
        return jsonify({
            "success": True,
            "scope": scope,
            **snapshot,
            "cost_per_run_credits": DEFAULT_MAP_REFRESH_ESTIMATED_CREDITS,
        })
    except (TypeError, ValueError):
        db.conn.rollback()
        return jsonify({"success": False, "error": "Выберите корректный интервал"}), 400
    finally:
        db.close()


@operator_bp.route("/mobile/content/plans/generate", methods=["POST"])
def operator_mobile_content_plan_generate():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    payload = request.get_json(silent=True) or {}
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope, business_id, error_response = _mobile_business_from_payload(cursor, user_data, payload, "social_content")
        if error_response:
            return error_response
    finally:
        db.close()
    try:
        plan = create_generated_content_plan(
            str(user_data.get("user_id") or user_data.get("id") or ""),
            business_id,
            scope_type="single_business",
            scope_target_id=business_id,
            period_days=int(payload.get("period_days") or 30),
            density=str(payload.get("density") or "standard"),
            content_mix=payload.get("content_mix") if isinstance(payload.get("content_mix"), dict) else {},
        )
        return jsonify({"success": True, "scope": scope, "plan": plan})
    except (PermissionError, ValueError):
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 400


@operator_bp.route("/mobile/content/plans/<plan_id>", methods=["DELETE"])
def operator_mobile_content_plan_delete(plan_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    payload = request.get_json(silent=True) or {}
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope, business_id, error_response = _mobile_business_from_payload(cursor, user_data, payload, "social_content")
        if error_response:
            return error_response
        cursor.execute("SELECT business_id FROM contentplans WHERE id = %s", (plan_id,))
        plan_row = cursor.fetchone()
        plan_business_id = str(dict(plan_row or {}).get("business_id") or "")
        if not plan_row or plan_business_id != business_id:
            return jsonify({"success": False, "error": "Контент-план не найден в выбранном бизнесе"}), 404
    finally:
        db.close()
    try:
        delete_content_plan(str(user_data.get("user_id") or user_data.get("id") or ""), plan_id)
        return jsonify({"success": True, "scope": scope, "deleted_plan_id": plan_id})
    except PermissionError:
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 403
    except ValueError:
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 404


@operator_bp.route("/mobile/services/analyze", methods=["POST"])
def operator_mobile_services_analyze():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    payload = request.get_json(silent=True) or {}
    mode = str(payload.get("mode") or "optimize").strip()
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope, business_id, error_response = _mobile_business_from_payload(cursor, user_data, payload, "maps.services")
        if error_response:
            return error_response
        cursor.execute(
            "SELECT id, name, description, category, price FROM userservices WHERE business_id = %s AND COALESCE(is_active, TRUE) ORDER BY category, name LIMIT 100",
            (business_id,),
        )
        services = [dict(item) for item in cursor.fetchall() or []]
        if not services:
            return jsonify({"success": False, "error": "Сначала добавьте услуги"}), 400
        service_ids = [str(item.get("id") or "") for item in services]
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        action_id = str(payload.get("action_id") or "").strip()
        action = {}
        if bool(payload.get("confirmed")):
            cursor.execute("SELECT * FROM operatoractions WHERE id = %s AND user_id = %s FOR UPDATE", (action_id, user_id))
            action = dict(cursor.fetchone() or {})
            if not action or str(action.get("capability") or "") != f"services.{mode}":
                return jsonify({"success": False, "error": "Проверка устарела. Подготовьте её заново."}), 400
            if str(action.get("status") or "") == "completed":
                stored_result = action.get("result_json") if isinstance(action.get("result_json"), dict) else json.loads(str(action.get("result_json") or "{}"))
                return jsonify({"success": True, "scope": scope, "mode": mode, "result": stored_result, "idempotent": True})
            if action.get("expires_at") and action.get("expires_at") < datetime.now(timezone.utc):
                return jsonify({"success": False, "error": "Проверка устарела. Подготовьте её заново."}), 400
            envelope = action.get("envelope_json") if isinstance(action.get("envelope_json"), dict) else json.loads(str(action.get("envelope_json") or "{}"))
            if str(envelope.get("business_id") or "") != business_id or envelope.get("service_ids") != service_ids:
                return jsonify({"success": False, "error": "Список услуг изменился. Проверьте действие заново."}), 409

        def store_service_preview(preview_payload: dict) -> str:
            preview_action_id = str(uuid.uuid4())
            stable_preview = json.dumps(
                {"business_id": business_id, "capability": f"services.{mode}", "service_ids": service_ids},
                ensure_ascii=False,
                sort_keys=True,
            )
            idempotency_key = hashlib.sha256(f"{user_id}|{stable_preview}".encode("utf-8")).hexdigest()[:32]
            expires_at = datetime.now(timezone.utc) + timedelta(minutes=15)
            cursor.execute(
                """
                INSERT INTO operatoractions (
                    id, conversation_id, business_id, user_id, capability, idempotency_key,
                    envelope_json, scope_type, scope_id, target_business_ids_json, preview_json,
                    estimated_credits, external_effects, is_mass_action, expires_at
                ) VALUES (%s, NULL, %s, %s, %s, %s, %s::jsonb, %s, %s, %s::jsonb, %s::jsonb, %s, FALSE, TRUE, %s)
                ON CONFLICT (user_id, idempotency_key)
                DO UPDATE SET preview_json = EXCLUDED.preview_json, envelope_json = EXCLUDED.envelope_json,
                              expires_at = EXCLUDED.expires_at, updated_at = NOW()
                RETURNING id
                """,
                (
                    preview_action_id,
                    business_id,
                    user_id,
                    f"services.{mode}",
                    idempotency_key,
                    json.dumps({"business_id": business_id, "service_ids": service_ids}, ensure_ascii=False),
                    str(scope.get("kind") or "business"),
                    str(scope.get("id") or "") or None,
                    json.dumps([business_id]),
                    json.dumps(preview_payload, ensure_ascii=False, default=str),
                    int(preview_payload.get("estimated_credits") or 0),
                    expires_at,
                ),
            )
            stored_id = str(dict(cursor.fetchone() or {}).get("id") or preview_action_id)
            db.conn.commit()
            return stored_id

        def complete_service_action(result_payload: dict) -> None:
            cursor.execute(
                """
                UPDATE operatoractions SET status = 'completed', confirmed_at = COALESCE(confirmed_at, NOW()),
                    executed_at = COALESCE(executed_at, NOW()), result_json = %s::jsonb, updated_at = NOW()
                WHERE id = %s AND user_id = %s
                """,
                (json.dumps(result_payload, ensure_ascii=False, default=str), action_id, user_id),
            )
        if mode == "compress":
            analysis = build_service_catalog_compression_draft(services)
            if bool(payload.get("confirmed")):
                created_service_ids = []
                archived_service_ids = []
                for group in analysis.get("groups") or []:
                    if str(group.get("action") or "") not in {"apply", "promotion"}:
                        continue
                    source_ids = [str(item) for item in group.get("source_service_ids") or [] if str(item)]
                    if not source_ids:
                        continue
                    cursor.execute(
                        "SELECT id FROM userservices WHERE business_id = %s AND id = ANY(%s) AND COALESCE(is_active, TRUE)",
                        (business_id, source_ids),
                    )
                    found_ids = [str(dict(item).get("id") or "") for item in cursor.fetchall() or []]
                    if not found_ids:
                        continue
                    if str(group.get("action") or "") == "apply":
                        target = group.get("target") if isinstance(group.get("target"), dict) else {}
                        created_id = str(uuid.uuid4())
                        cursor.execute(
                            """
                            INSERT INTO userservices (
                                id, user_id, business_id, category, name, description,
                                keywords, price, is_active, created_at, updated_at
                            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, TRUE, NOW(), NOW())
                            """,
                            (
                                created_id,
                                str(user_data.get("user_id") or user_data.get("id") or ""),
                                business_id,
                                str(target.get("category") or "Общие услуги"),
                                str(target.get("name") or group.get("title") or "Объединённая услуга"),
                                str(target.get("description") or ""),
                                json.dumps(target.get("keywords") or [], ensure_ascii=False),
                                str(target.get("price") or ""),
                            ),
                        )
                        created_service_ids.append(created_id)
                    cursor.execute(
                        "UPDATE userservices SET is_active = FALSE, updated_at = NOW() WHERE business_id = %s AND id = ANY(%s)",
                        (business_id, found_ids),
                    )
                    archived_service_ids.extend(found_ids)
                result_payload = {
                    "status": "completed",
                    "created_count": len(created_service_ids),
                    "archived_count": len(set(archived_service_ids)),
                    "provider_write_performed": False,
                }
                complete_service_action(result_payload)
                db.conn.commit()
                return jsonify({
                    "success": True,
                    "scope": scope,
                    "mode": mode,
                    "result": result_payload,
                })
            preview_payload = {"mode": mode, "analysis": analysis, "confirmation_required": True, "estimated_credits": 0}
            return jsonify({"success": True, "scope": scope, **preview_payload, "action_id": store_service_preview(preview_payload)})
        if bool(payload.get("confirmed")):
            result = optimize_services_from_operator(
                cursor,
                business_id=business_id,
                user_id=str(user_data.get("user_id") or user_data.get("id") or ""),
                limit=len(services),
                channel="telegram_mini_app",
            )
            if str(result.get("status") or "") != "completed":
                db.conn.rollback()
                return jsonify({"success": False, "error": result.get("chat_response") or "Не удалось улучшить услуги", "result": result}), 400
            complete_service_action(result)
            db.conn.commit()
            return jsonify({"success": True, "scope": scope, "mode": "optimize", "result": result})
        preview_payload = {
            "success": True,
            "scope": scope,
            "mode": "optimize",
            "service_count": len(services),
            "estimated_credits": len(services) * SERVICES_OPTIMIZE_CREDITS_PER_SERVICE,
            "confirmation_required": True,
            "changes": [{"id": item.get("id"), "name": item.get("name")} for item in services],
        }
        preview_payload["action_id"] = store_service_preview(preview_payload)
        return jsonify(preview_payload)
    finally:
        db.close()


def _operator_json_object(value: object) -> dict:
    text = str(value or "").strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.IGNORECASE)
    try:
        parsed = json.loads(text)
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        start, end = text.find("{"), text.rfind("}")
        if start >= 0 and end > start:
            try:
                parsed = json.loads(text[start:end + 1])
                return parsed if isinstance(parsed, dict) else {}
            except Exception:
                return {}
    return {}


def _normalize_finance_transaction_date(value: object) -> str:
    text = str(value or "").strip()
    if not text:
        return datetime.now(timezone.utc).date().isoformat()
    for date_format in ("%d.%m", "%d/%m", "%d-%m"):
        try:
            parsed = datetime.strptime(text, date_format).date()
            return parsed.replace(year=datetime.now(timezone.utc).year).isoformat()
        except ValueError:
            continue
    for date_format in ("%Y-%m-%d", "%d.%m.%Y", "%d.%m.%y", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(text, date_format).date().isoformat()
        except ValueError:
            continue
    return text


@operator_bp.route("/mobile/finance/recognize", methods=["POST"])
def operator_mobile_finance_recognize():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    payload = request.form.to_dict() if request.files else (request.get_json(silent=True) or {})
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope, business_id, error_response = _mobile_business_from_payload(cursor, user_data, payload, "finance")
        if error_response:
            return error_response
    finally:
        db.close()
    today = datetime.now(timezone.utc).date()
    prompt = f"""Извлеки продажи из данных. Для каждой строки определи sale_type: service — основная услуга, upsell — допродажа к основной услуге, cross_sell — отдельный товар или кросс-продажа. Сегодня {today.isoformat()}. Если в дате не указан год, используй {today.year}. Не превращай день месяца в год. Верни только JSON: {{\"transactions\":[{{\"transaction_date\":\"YYYY-MM-DD\",\"amount\":0,\"title\":\"название\",\"sale_type\":\"service|upsell|cross_sell\",\"notes\":\"\"}}]}}"""
    uploaded = request.files.get("file") or request.files.get("photo")
    try:
        if uploaded and str(uploaded.mimetype or "").startswith("image/"):
            raw_result = analyze_screenshot_with_gigachat(
                base64.b64encode(uploaded.read()).decode("utf-8"),
                prompt,
                task_type="finance_sales_recognition",
                business_id=business_id,
                user_id=str(user_data.get("user_id") or user_data.get("id") or ""),
            )
        else:
            source_text = str(payload.get("text") or "").strip()
            if uploaded:
                source, extraction_error = build_agent_source_from_upload(uploaded)
                if extraction_error:
                    return jsonify({"success": False, "error": extraction_error.get("message") or "Не удалось прочитать документ"}), 400
                source_text = str(source.get("content_text") or "").strip()
            if not source_text:
                return jsonify({"success": False, "error": "Добавьте текст, фото или документ с продажами"}), 400
            raw_result = analyze_text_with_gigachat(
                f"{prompt}\n\nДанные:\n{source_text}",
                task_type="finance_sales_recognition",
                business_id=business_id,
                user_id=str(user_data.get("user_id") or user_data.get("id") or ""),
            )
        recognized = _operator_json_object(raw_result)
        transactions = recognized.get("transactions") if isinstance(recognized.get("transactions"), list) else []
        transactions = [
            {
                **item,
                "transaction_date": _normalize_finance_transaction_date(item.get("transaction_date")),
            }
            for item in transactions
            if isinstance(item, dict)
        ]
        return jsonify({"success": True, "scope": scope, "business_id": business_id, "transactions": transactions, "confirmation_required": True})
    except Exception:
        return jsonify({"success": False, "error": f"Не удалось распознать продажи: {sys.exc_info()[1]}"}), 400


@operator_bp.route("/mobile/services/<service_id>", methods=["PUT"])
def operator_mobile_service_update(service_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    payload = request.get_json(silent=True) or {}
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        cursor.execute("SELECT business_id FROM userservices WHERE id = %s", (service_id,))
        row = cursor.fetchone()
        business_id = str((dict(row) if row else {}).get("business_id") or "")
        if not business_id:
            return jsonify({"success": False, "error": "Услуга не найдена"}), 404
        if not scope or not _mobile_scope_allows_business(scope, business_id):
            return jsonify({"success": False, "error": "Услуга недоступна"}), 403
        access = _scope_capability_access(cursor, scope, "maps.services", bool(user_data.get("is_superadmin")))
        if not access.get("allowed"):
            return _mobile_payment_required_response(access)
        updates = []
        params = []
        for field in ("name", "description", "price", "category"):
            if field not in payload:
                continue
            value = str(payload.get(field) or "").strip()
            if field == "name" and not value:
                return jsonify({"success": False, "error": "Название не может быть пустым"}), 400
            updates.append(f"{field} = %s")
            params.append(value)
        if not updates:
            return jsonify({"success": False, "error": "Нет изменений"}), 400
        params.extend([service_id, business_id])
        cursor.execute(
            f"""
            UPDATE userservices
            SET {', '.join(updates)}, updated_at = CURRENT_TIMESTAMP
            WHERE id = %s AND business_id = %s
            RETURNING id, business_id, name AS title, description AS subtitle,
                      price, category, updated_at,
                      CASE WHEN COALESCE(is_active, TRUE) THEN 'active' ELSE 'archived' END AS status
            """,
            tuple(params),
        )
        updated = dict(cursor.fetchone() or {})
        db.conn.commit()
        return jsonify({"success": True, "scope": scope, "item": updated})
    except Exception:
        db.conn.rollback()
        raise
    finally:
        db.close()


def _mobile_content_item_scope(cursor, user_data: dict, item_id: str):
    scope = _resolve_mobile_scope(cursor, user_data)
    cursor.execute("SELECT business_id FROM contentplanitems WHERE id = %s", (item_id,))
    row = cursor.fetchone()
    business_id = str((dict(row) if row else {}).get("business_id") or "")
    if not business_id:
        return scope, business_id, (jsonify({"success": False, "error": "Элемент плана не найден"}), 404)
    if not scope or not _mobile_scope_allows_business(scope, business_id):
        return scope, business_id, (jsonify({"success": False, "error": "Элемент плана недоступен"}), 403)
    access = _scope_capability_access(cursor, scope, "social_content", bool(user_data.get("is_superadmin")))
    if not access.get("allowed"):
        return scope, business_id, _mobile_payment_required_response(access)
    return scope, business_id, None


@operator_bp.route("/mobile/content/items/<item_id>", methods=["PUT"])
def operator_mobile_content_item_update(item_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    payload = request.get_json(silent=True) or {}
    allowed_payload = {
        key: payload.get(key)
        for key in ("theme", "goal", "draft_text", "scheduled_for")
        if key in payload
    }
    if not allowed_payload:
        return jsonify({"success": False, "error": "Нет изменений"}), 400
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope, _business_id, error_response = _mobile_content_item_scope(cursor, user_data, item_id)
        if error_response:
            return error_response
    finally:
        db.close()
    try:
        plan = update_content_plan_item(str(user_data.get("user_id") or user_data.get("id") or ""), item_id, allowed_payload)
        return jsonify({"success": True, "scope": scope, "plan": plan})
    except PermissionError as exc:
        return jsonify({"success": False, "error": str(exc)}), 403
    except ValueError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400


@operator_bp.route("/mobile/content/items/<item_id>/generate-draft", methods=["POST"])
def operator_mobile_content_item_generate_draft(item_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope, _business_id, error_response = _mobile_content_item_scope(cursor, user_data, item_id)
        if error_response:
            return error_response
    finally:
        db.close()
    try:
        result = generate_draft_for_plan_item(str(user_data.get("user_id") or user_data.get("id") or ""), item_id)
        return jsonify({"success": True, "scope": scope, **result})
    except PermissionError as exc:
        return jsonify({"success": False, "error": str(exc)}), 403
    except ValueError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400


@operator_bp.route("/mobile/settings/notifications", methods=["PUT"])
def operator_mobile_notification_settings_update():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    payload = request.get_json(silent=True) or {}
    notifications = payload.get("notifications") if isinstance(payload.get("notifications"), dict) else None
    if notifications is None:
        return jsonify({"success": False, "error": "Настройки не переданы"}), 400
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        saved = save_scope_notification_preferences(
            cursor,
            user_id=user_id,
            telegram_id=str(user_data.get("telegram_id") or ""),
            scope=scope,
            notifications=notifications,
        )
        db.conn.commit()
        return jsonify({"success": True, "scope": scope, "preferences": saved})
    except Exception:
        db.conn.rollback()
        raise
    finally:
        db.close()


@operator_bp.route("/mobile/reviews", methods=["GET"])
def operator_mobile_reviews():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        access = _scope_capability_access(cursor, scope, "maps.reviews", bool(user_data.get("is_superadmin")))
        if not access.get("allowed"):
            return _mobile_payment_required_response(access)
        status = str(request.args.get("status") or "unanswered").strip().lower()
        source = str(request.args.get("source") or "").strip().lower()
        location_id = str(request.args.get("location_id") or "").strip()
        review_id = str(request.args.get("review_id") or "").strip()
        rating = str(request.args.get("rating") or "").strip()
        try:
            limit = max(1, min(int(request.args.get("limit") or 20), 50))
            offset = max(0, int(request.args.get("cursor") or 0))
        except ValueError:
            return jsonify({"success": False, "error": "Некорректная пагинация"}), 400
        conditions = ["COALESCE(TRIM(r.text), '') <> ''"]
        params: list = []
        business_ids = [str(item) for item in scope.get("business_ids") or [] if str(item)]
        if scope.get("kind") != "platform":
            conditions.append("r.business_id = ANY(%s)")
            params.append(business_ids)
        if location_id:
            if scope.get("kind") != "platform" and location_id not in business_ids:
                return jsonify({"success": False, "error": "Точка недоступна"}), 403
            conditions.append("r.business_id = %s")
            params.append(location_id)
        if source:
            conditions.append("LOWER(r.source) = %s")
            params.append(source)
        if rating:
            try:
                rating_value = max(1, min(int(rating), 5))
            except ValueError:
                return jsonify({"success": False, "error": "Некорректный рейтинг"}), 400
            conditions.append("r.rating = %s")
            params.append(rating_value)
        base_where_sql = " AND ".join(conditions)
        cursor.execute(
            f"""
            {CANONICAL_REVIEWS_CTE}
            SELECT COUNT(DISTINCT r.id) AS total,
                   COUNT(DISTINCT r.id) FILTER (WHERE COALESCE(TRIM(r.response_text), '') = '') AS unanswered,
                   COUNT(DISTINCT r.id) FILTER (WHERE d.id IS NOT NULL AND d.status IN ('draft','generated','pending_review','edited')) AS drafts
            FROM canonical_reviews r
            LEFT JOIN reviewreplydrafts d ON d.review_id = r.id
            WHERE {base_where_sql}
            """,
            tuple(params),
        )
        counts = dict(cursor.fetchone() or {})
        list_conditions = list(conditions)
        if review_id:
            list_conditions.append("r.id = %s")
            params.append(review_id)
        if status == "unanswered":
            list_conditions.append("COALESCE(TRIM(r.response_text), '') = ''")
        elif status == "drafts":
            list_conditions.append("d.id IS NOT NULL AND d.status IN ('draft','generated','pending_review','edited')")
        elif status == "answered":
            list_conditions.append("COALESCE(TRIM(r.response_text), '') <> ''")
        where_sql = " AND ".join(list_conditions)
        cursor.execute(
            f"""
            {CANONICAL_REVIEWS_CTE}
            SELECT COUNT(DISTINCT r.id) AS total
            FROM canonical_reviews r
            LEFT JOIN reviewreplydrafts d ON d.review_id = r.id
            WHERE {where_sql}
            """,
            tuple(params),
        )
        filtered_total = int(dict(cursor.fetchone() or {}).get("total") or 0)
        cursor.execute(
            f"""
            {CANONICAL_REVIEWS_CTE}
            SELECT r.id, r.business_id, r.source, r.rating, r.author_name, r.text,
                   r.response_text, r.response_at, COALESCE(r.published_at, r.created_at) AS published_at,
                   r.created_at AS loaded_at, r.updated_at, b.name AS location_name,
                   d.id AS reply_draft_id, d.generated_text AS reply_draft_text,
                   d.status AS reply_draft_status, d.updated_at AS reply_draft_updated_at
            FROM canonical_reviews r
            LEFT JOIN businesses b ON b.id = r.business_id
            LEFT JOIN LATERAL (
                SELECT id, COALESCE(edited_text, generated_text) AS generated_text, status, updated_at FROM reviewreplydrafts
                WHERE review_id = r.id ORDER BY updated_at DESC LIMIT 1
            ) d ON TRUE
            WHERE {where_sql}
            ORDER BY COALESCE(r.published_at, r.created_at) DESC
            LIMIT %s OFFSET %s
            """,
            tuple([*params, limit, offset]),
        )
        items = [dict(row) for row in cursor.fetchall() or []]
        total = int(counts.get("total") or 0)
        cursor.execute(
            """
            SELECT DISTINCT r.source FROM externalbusinessreviews r
            WHERE (%s OR r.business_id = ANY(%s)) AND COALESCE(TRIM(r.source), '') <> ''
            ORDER BY r.source
            """,
            (scope.get("kind") == "platform", business_ids),
        )
        sources = [str(dict(row).get("source") or "") for row in (cursor.fetchall() or [])]
        cursor.execute(
            """
            SELECT id, name FROM businesses
            WHERE (%s OR id = ANY(%s))
            ORDER BY name
            LIMIT 200
            """,
            (scope.get("kind") == "platform", business_ids),
        )
        locations = [dict(row) for row in (cursor.fetchall() or [])]
        return jsonify({
            "success": True,
            "scope": scope,
            "items": items,
            "counts": {"total": total, "unanswered": int(counts.get("unanswered") or 0), "drafts": int(counts.get("drafts") or 0)},
            "cursor": str(offset + limit) if offset + len(items) < filtered_total else None,
            "as_of": datetime.now(timezone.utc).isoformat(),
            "data_warnings": [],
            "available_actions": [{"key": "generate", "label": "Подготовить ответы"}],
            "filters": {"statuses": ["unanswered", "drafts", "answered", "all"], "sources": sources, "ratings": [1, 2, 3, 4, 5], "locations": locations},
        })
    finally:
        db.close()


@operator_bp.route("/mobile/actions/preview", methods=["POST"])
def operator_mobile_action_preview():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    payload = request.get_json(silent=True) or {}
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        scope = resolve_control_scope(cursor, user_id=user_id, requested_kind=str(payload.get("scope_type") or ""), requested_id=str(payload.get("scope_id") or "") or None)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        capability = str(payload.get("capability") or payload.get("action_key") or "").strip()
        input_payload = payload.get("input") if isinstance(payload.get("input"), dict) else payload
        required_capability = _mobile_capability_for_action(capability)
        if required_capability:
            access = _scope_capability_access(cursor, scope, required_capability, bool(user_data.get("is_superadmin")))
            if not access.get("allowed"):
                return _mobile_payment_required_response(access)
        preview = create_mobile_action_preview(
            cursor,
            user_id=user_id,
            scope=scope,
            capability=capability,
            input_payload=input_payload,
        )
        if preview.get("status") == "blocked":
            return jsonify({"success": False, "error": "Действие недоступно", "preview": preview}), 400
        db.conn.commit()
        return jsonify({"success": True, "preview": preview})
    except Exception:
        db.conn.rollback()
        raise
    finally:
        db.close()


@operator_bp.route("/mobile/actions/<action_id>", methods=["GET"])
def operator_mobile_action_status(action_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        job = load_mobile_job(cursor, job_id=action_id, user_id=user_id, scope=scope)
        if not job or job.get("kind") != "operator_action":
            return jsonify({"success": False, "error": "Действие не найдено"}), 404
        cursor.execute(
            "SELECT preview_json, estimated_credits, external_effects, is_mass_action, expires_at FROM operatoractions WHERE id = %s AND user_id = %s",
            (action_id, user_id),
        )
        row = cursor.fetchone()
        values = dict(row) if row else {}
        return jsonify({"success": True, "action": {**job, **values}})
    finally:
        db.close()


@operator_bp.route("/mobile/actions/<action_id>/confirm", methods=["POST"])
def operator_mobile_action_confirm(action_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    user_id = str(user_data.get("user_id") or user_data.get("id") or "")
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        cursor.execute(
            "SELECT capability, scope_type, scope_id FROM operatoractions WHERE id = %s AND user_id = %s",
            (action_id, user_id),
        )
        stored_action = dict(cursor.fetchone() or {})
        if not stored_action:
            return jsonify({"success": False, "error": "Действие не найдено"}), 404
        stored_scope = resolve_control_scope(
            cursor,
            user_id=user_id,
            requested_kind=str(stored_action.get("scope_type") or "business"),
            requested_id=str(stored_action.get("scope_id") or "") or None,
        )
        if not stored_scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        required_capability = _mobile_capability_for_action(str(stored_action.get("capability") or ""))
        if required_capability:
            access = _scope_capability_access(cursor, stored_scope, required_capability, bool(user_data.get("is_superadmin")))
            if not access.get("allowed"):
                return _mobile_payment_required_response(access)

        def scope_resolver(kind: str, scope_id: str | None):
            return resolve_control_scope(cursor, user_id=user_id, requested_kind=kind, requested_id=scope_id)

        def target_authorizer(targets: list[str]):
            for business_id in targets:
                has_access, _owner_id = verify_business_write_access(cursor, business_id, user_data)
                if not has_access:
                    return False
            return True


        def generate_executor(envelope: dict, targets: list[str], _scope: dict):
            review_ids = [str(item) for item in envelope.get("review_ids") or []]
            drafts: list[dict] = []
            charged_credits = 0
            blocked_reasons: list[str] = []
            for business_id in targets:
                cursor.execute(
                    "SELECT id FROM externalbusinessreviews WHERE business_id = %s AND id = ANY(%s)",
                    (business_id, review_ids),
                )
                scoped_review_ids = [str(dict(item).get("id") or "") for item in (cursor.fetchall() or [])]
                if not scoped_review_ids:
                    continue
                generated = generate_review_reply_drafts_for_unanswered_reviews(
                    cursor,
                    business_id=business_id,
                    user_id=user_id,
                    limit=len(scoped_review_ids),
                    review_ids=scoped_review_ids,
                    channel="telegram_mini_app",
                )
                if str(generated.get("status") or "") != "completed":
                    blocked_reasons.extend(str(item) for item in generated.get("blocked_reasons") or ["generation_failed"])
                drafts.extend(generated.get("drafts") or [])
                charged_credits += int(generated.get("charged_credits") or 0)
            if blocked_reasons:
                return {"status": "blocked", "blocked_reasons": list(dict.fromkeys(blocked_reasons))}
            return {
                "status": "completed",
                "capability": "review_replies.generate",
                "drafts": drafts,
                "charged_credits": charged_credits,
                "manual_publication_only": True,
                "external_writes_performed": False,
            }

        def finance_sales_executor(envelope: dict, targets: list[str], _scope: dict):
            business_id = str(envelope.get("business_id") or "")
            transactions = envelope.get("transactions") if isinstance(envelope.get("transactions"), list) else []
            if len(targets) != 1 or business_id != targets[0] or not transactions:
                return {"status": "blocked", "blocked_reasons": ["finance_preview_changed"]}
            cursor.execute(
                "SELECT column_name FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'financialtransactions'"
            )
            columns = {str(dict(item).get("column_name") or "") for item in cursor.fetchall() or []}
            created = []
            for item in transactions:
                transaction_id = str(uuid.uuid4())
                sale_type = str(item.get("sale_type") or "service")
                title = str(item.get("title") or "Продажа")
                notes = str(item.get("notes") or "")
                description = f"{title} · {sale_type}" + (f" · {notes}" if notes else "")
                fields = ["id", "business_id", "amount"]
                values = [transaction_id, business_id, item.get("amount")]
                if "user_id" in columns:
                    fields.append("user_id")
                    values.append(user_id)
                if "transaction_date" in columns:
                    fields.append("transaction_date")
                    values.append(str(item.get("transaction_date") or datetime.now(timezone.utc).date().isoformat()))
                if "transaction_type" in columns:
                    fields.append("transaction_type")
                    values.append("income")
                if "description" in columns:
                    fields.append("description")
                    values.append(description)
                if "client_type" in columns:
                    fields.append("client_type")
                    values.append("returning")
                if "services" in columns:
                    fields.append("services")
                    values.append(json.dumps([{"name": title, "sale_type": sale_type}], ensure_ascii=False))
                if "notes" in columns:
                    fields.append("notes")
                    values.append(description)
                placeholders = ", ".join(["%s"] * len(fields))
                cursor.execute(
                    f"INSERT INTO financialtransactions ({', '.join(fields)}) VALUES ({placeholders})",
                    tuple(values),
                )
                created.append({"id": transaction_id, **item})
            return {
                "status": "completed",
                "capability": "finance.sales_import",
                "transactions": created,
                "created_count": len(created),
                "external_writes_performed": False,
            }

        def finance_transaction_delete_executor(envelope: dict, targets: list[str], _scope: dict):
            business_id = str(envelope.get("business_id") or "")
            transaction_id = str(envelope.get("transaction_id") or "")
            if len(targets) != 1 or targets[0] != business_id or not transaction_id:
                return {"status": "blocked", "blocked_reasons": ["finance_preview_changed"]}
            cursor.execute(
                "DELETE FROM financialtransactions WHERE id = %s AND business_id = %s RETURNING id",
                (transaction_id, business_id),
            )
            if not cursor.fetchone():
                return {"status": "blocked", "blocked_reasons": ["transaction_changed_after_preview"]}
            return {
                "status": "completed",
                "capability": "finance.transaction.delete",
                "deleted_transaction_id": transaction_id,
                "external_writes_performed": False,
            }

        def partnership_delete_executor(envelope: dict, targets: list[str], _scope: dict):
            business_id = str(envelope.get("business_id") or "")
            lead_ids = list(dict.fromkeys(str(item).strip() for item in envelope.get("lead_ids") or [] if str(item).strip()))
            if len(targets) != 1 or targets[0] != business_id or not lead_ids:
                return {"status": "blocked", "blocked_reasons": ["partnership_delete_preview_changed"]}
            cursor.execute(
                """
                DELETE FROM lead_workstreams
                WHERE lead_id = ANY(%s)
                  AND client_business_id = %s
                  AND workstream_type = 'client_partnership'
                RETURNING lead_id
                """,
                (lead_ids, business_id),
            )
            deleted_ids = [str(dict(item).get("lead_id") or "") for item in (cursor.fetchall() or [])]
            if set(deleted_ids) != set(lead_ids):
                return {"status": "blocked", "blocked_reasons": ["partnership_leads_changed_after_preview"]}
            cursor.execute(
                """
                DELETE FROM prospectingleads lead
                WHERE lead.id = ANY(%s)
                  AND NOT EXISTS (
                    SELECT 1 FROM lead_workstreams workstream WHERE workstream.lead_id = lead.id
                  )
                """,
                (deleted_ids,),
            )
            return {
                "status": "completed",
                "capability": "partnerships.lead.delete" if len(deleted_ids) == 1 else "partnerships.leads.bulk_delete",
                "deleted_ids": deleted_ids,
                "deleted_count": len(deleted_ids),
                "external_writes_performed": False,
            }

        def community_source_unsubscribe_executor(envelope: dict, targets: list[str], _scope: dict):
            business_id = str(envelope.get("business_id") or "")
            source_id = str(envelope.get("source_id") or "")
            if len(targets) != 1 or targets[0] != business_id or not source_id:
                return {"status": "blocked", "blocked_reasons": ["community_source_preview_changed"]}
            cursor.execute(
                """
                UPDATE knowledge_source_subscriptions
                SET is_active = FALSE, updated_at = NOW()
                WHERE business_id = %s AND source_id = %s AND is_active = TRUE
                RETURNING source_id
                """,
                (business_id, source_id),
            )
            if not cursor.fetchone():
                return {"status": "blocked", "blocked_reasons": ["community_source_changed_after_preview"]}
            return {
                "status": "completed",
                "capability": "community_sources.unsubscribe",
                "source_id": source_id,
                "external_writes_performed": False,
            }

        def partnership_draft_delete_executor(envelope: dict, targets: list[str], _scope: dict):
            business_id = str(envelope.get("business_id") or "")
            draft_id = str(envelope.get("draft_id") or "")
            if len(targets) != 1 or targets[0] != business_id or not draft_id:
                return {"status": "blocked", "blocked_reasons": ["partnership_draft_preview_changed"]}
            cursor.execute(
                """
                DELETE FROM outreachmessagedrafts draft
                USING prospectingleads lead
                WHERE draft.id = %s
                  AND draft.lead_id = lead.id
                  AND lead.business_id = %s
                  AND COALESCE(lead.intent, 'client_outreach') = 'partnership_outreach'
                RETURNING draft.id
                """,
                (draft_id, business_id),
            )
            if not cursor.fetchone():
                return {"status": "blocked", "blocked_reasons": ["partnership_draft_changed_after_preview"]}
            return {
                "status": "completed",
                "capability": "partnerships.draft.delete",
                "draft_id": draft_id,
                "external_writes_performed": False,
            }

        def card_schedule_executor(envelope: dict, targets: list[str], _scope: dict):
            business_id = str(envelope.get("business_id") or "")
            if len(targets) != 1 or targets[0] != business_id:
                return {"status": "blocked", "blocked_reasons": ["schedule_preview_changed"]}
            current = get_card_automation_snapshot(db.conn, business_id).get("settings") or {}
            merged = dict(current)
            merged.update({
                "review_sync_enabled": bool(envelope.get("enabled")),
                "review_sync_interval_hours": int(envelope.get("interval_hours") or 24),
                "review_sync_schedule_mode": "interval",
                "review_sync_schedule_days": [],
                "review_sync_schedule_time": None,
            })
            snapshot = save_card_automation_settings(db.conn, business_id, user_id, merged)
            return {
                "status": "completed",
                "capability": "cards.schedule.update",
                "business_id": business_id,
                "settings": snapshot.get("settings") or {},
                "next_run_at": (snapshot.get("settings") or {}).get("review_sync_next_run_at"),
                "external_writes_performed": False,
            }

        def card_refresh_executor(envelope: dict, targets: list[str], _scope: dict):
            business_id = str(envelope.get("business_id") or "")
            if len(targets) != 1 or targets[0] != business_id:
                return {"status": "blocked", "blocked_reasons": ["card_refresh_preview_changed"]}
            refresh = enqueue_paid_operator_map_refresh(
                cursor,
                business_id=business_id,
                user_id=user_id,
                estimated_credits=DEFAULT_MAP_REFRESH_ESTIMATED_CREDITS,
                explicit_consent=True,
                metadata={
                    "channel": "telegram_mini_app",
                    "operator_action_id": str(envelope.get("_action_id") or ""),
                    "operator_idempotency_key": str(envelope.get("_idempotency_key") or ""),
                    "requested_source": str(envelope.get("source") or "all"),
                },
            )
            if str(refresh.get("status") or "") != "queued":
                return {"status": "blocked", "blocked_reasons": refresh.get("blocked_reasons") or ["card_refresh_failed"], "refresh": refresh}
            return {
                "status": "completed",
                "capability": "cards.refresh",
                "job_id": str(refresh.get("queue_id") or ""),
                "job_kind": "map_refresh",
                "queue_status": str(refresh.get("queue_status") or "pending"),
                "estimated_credits": DEFAULT_MAP_REFRESH_ESTIMATED_CREDITS,
                "external_writes_performed": False,
            }

        def diagnostic_retry_executor(envelope: dict, targets: list[str], resolved_scope: dict):
            business_id = str(envelope.get("business_id") or "")
            source_job_id = str(envelope.get("job_id") or "")
            if resolved_scope.get("kind") != "platform" or len(targets) != 1 or targets[0] != business_id:
                return {"status": "blocked", "blocked_reasons": ["diagnostic_retry_preview_changed"]}
            cursor.execute("SELECT status, url FROM parsequeue WHERE id = %s AND business_id = %s", (source_job_id, business_id))
            source_job = cursor.fetchone()
            if not source_job or str(dict(source_job).get("status") or "").lower() not in {"failed", "error", "stuck", "captcha_required"}:
                return {"status": "blocked", "blocked_reasons": ["diagnostic_job_changed"]}
            retry = enqueue_paid_operator_map_refresh(
                cursor,
                business_id=business_id,
                user_id=user_id,
                explicit_url=str(dict(source_job).get("url") or envelope.get("url") or ""),
                estimated_credits=DEFAULT_MAP_REFRESH_ESTIMATED_CREDITS,
                explicit_consent=True,
                metadata={
                    "channel": "telegram_mini_app_diagnostics",
                    "retry_source_queue_id": source_job_id,
                    "operator_action_id": str(envelope.get("_action_id") or ""),
                },
            )
            if str(retry.get("status") or "") != "queued":
                return {"status": "blocked", "blocked_reasons": retry.get("blocked_reasons") or ["diagnostic_retry_failed"]}
            return {
                "status": "completed",
                "capability": "diagnostics.retry",
                "job_id": str(retry.get("queue_id") or ""),
                "job_kind": "map_refresh",
                "source_job_id": source_job_id,
                "external_writes_performed": False,
            }

        def content_plan_generate_executor(envelope: dict, targets: list[str], resolved_scope: dict):
            business_id = str(envelope.get("business_id") or "")
            action_key = str(envelope.get("_idempotency_key") or envelope.get("_action_id") or "")
            if len(targets) != 1 or targets[0] != business_id or not action_key:
                return {"status": "blocked", "blocked_reasons": ["content_plan_preview_changed"]}
            job = create_operator_async_job(
                cursor,
                user_id=user_id,
                action_id=str(envelope.get("_action_id") or "") or None,
                business_id=business_id,
                kind="content_plan_generate",
                payload={
                    "scope_type": str(resolved_scope.get("kind") or "business"),
                    "scope_target_id": str(resolved_scope.get("id") or business_id),
                    "period_days": int(envelope.get("period_days") or 30),
                    "density": str(envelope.get("density") or "standard"),
                    "content_mix": envelope.get("content_mix") if isinstance(envelope.get("content_mix"), dict) else {},
                },
                idempotency_key=f"content-plan:{action_key}:{business_id}",
                stage="Собираем данные о бизнесе",
            )
            return {
                "status": "completed",
                "capability": "content.plan.generate",
                "job_id": job.get("id"),
                "job": job,
                "external_writes_performed": False,
            }

        def content_item_generate_executor(envelope: dict, targets: list[str], _scope: dict):
            business_id = str(envelope.get("business_id") or "")
            item_id = str(envelope.get("item_id") or "")
            action_key = str(envelope.get("_idempotency_key") or envelope.get("_action_id") or "")
            if len(targets) != 1 or targets[0] != business_id or not item_id or not action_key:
                return {"status": "blocked", "blocked_reasons": ["content_item_preview_changed"]}
            cursor.execute("SELECT business_id FROM contentplanitems WHERE id = %s", (item_id,))
            current = cursor.fetchone()
            if not current or str(dict(current).get("business_id") or "") != business_id:
                return {"status": "blocked", "blocked_reasons": ["content_item_changed"]}
            job = create_operator_async_job(
                cursor,
                user_id=user_id,
                action_id=str(envelope.get("_action_id") or "") or None,
                business_id=business_id,
                kind="content_draft_generate",
                payload={"item_id": item_id, "language": str(envelope.get("language") or "ru")},
                idempotency_key=f"content-draft:{action_key}:{item_id}",
                stage="Сверяем тему с данными бизнеса",
            )
            return {
                "status": "completed",
                "capability": "content.item.generate",
                "job_id": job.get("id"),
                "job": job,
                "external_writes_performed": False,
            }

        def content_item_delete_executor(envelope: dict, targets: list[str], _scope: dict):
            business_id = str(envelope.get("business_id") or "")
            item_id = str(envelope.get("item_id") or "")
            if len(targets) != 1 or targets[0] != business_id or not item_id:
                return {"status": "blocked", "blocked_reasons": ["content_item_preview_changed"]}
            cursor.execute(
                "DELETE FROM contentplanitems WHERE id = %s AND business_id = %s RETURNING id",
                (item_id, business_id),
            )
            if not cursor.fetchone():
                return {"status": "blocked", "blocked_reasons": ["content_item_changed"]}
            return {
                "status": "completed",
                "capability": "content.item.delete",
                "deleted_item_id": item_id,
                "external_writes_performed": False,
            }

        def content_plan_delete_executor(envelope: dict, targets: list[str], _scope: dict):
            business_id = str(envelope.get("business_id") or "")
            plan_id = str(envelope.get("plan_id") or "")
            if len(targets) != 1 or targets[0] != business_id or not plan_id:
                return {"status": "blocked", "blocked_reasons": ["content_plan_preview_changed"]}
            cursor.execute(
                "DELETE FROM contentplans WHERE id = %s AND business_id = %s RETURNING id, title",
                (plan_id, business_id),
            )
            deleted = cursor.fetchone()
            if not deleted:
                return {"status": "blocked", "blocked_reasons": ["content_plan_changed"]}
            deleted_row = dict(deleted)
            record_operator_event(
                cursor,
                business_id=business_id,
                user_id=user_id,
                event_type="content_plan_deleted",
                action_key="content.plan.delete",
                status="completed",
                input_summary={"plan_id": plan_id},
                output_summary={"title": str(deleted_row.get("title") or "")},
                metadata={"channel": "telegram_mini_app"},
            )
            return {
                "status": "completed",
                "capability": "content.plan.delete",
                "deleted_plan_id": plan_id,
                "external_writes_performed": False,
            }

        def current_service_rows(business_id: str) -> list[dict]:
            cursor.execute(
                """
                SELECT id, business_id, name, description, category, price
                FROM userservices
                WHERE business_id = %s AND COALESCE(is_active, TRUE)
                ORDER BY category, name
                LIMIT 100
                """,
                (business_id,),
            )
            return [dict(item) for item in (cursor.fetchall() or [])]

        def service_targets_unchanged(envelope: dict, targets: list[str], services: list[dict]) -> tuple[bool, str]:
            business_id = str(envelope.get("business_id") or "")
            expected_ids = [str(item) for item in envelope.get("service_ids") or []]
            current_ids = [str(item.get("id") or "") for item in services]
            return len(targets) == 1 and targets[0] == business_id and expected_ids == current_ids, business_id

        def services_optimize_executor(envelope: dict, targets: list[str], _scope: dict):
            business_id = str(envelope.get("business_id") or "")
            services = current_service_rows(business_id)
            unchanged, business_id = service_targets_unchanged(envelope, targets, services)
            if not unchanged:
                return {"status": "blocked", "blocked_reasons": ["services_changed_after_preview"]}
            result = optimize_services_from_operator(
                cursor,
                business_id=business_id,
                user_id=user_id,
                limit=len(services),
                channel="telegram_mini_app",
            )
            if str(result.get("status") or "") != "completed":
                return {"status": "blocked", "blocked_reasons": result.get("blocked_reasons") or ["service_optimization_failed"]}
            return {**result, "capability": "services.optimize", "external_writes_performed": False}

        def services_compress_executor(envelope: dict, targets: list[str], _scope: dict):
            business_id = str(envelope.get("business_id") or "")
            services = current_service_rows(business_id)
            unchanged, business_id = service_targets_unchanged(envelope, targets, services)
            if not unchanged:
                return {"status": "blocked", "blocked_reasons": ["services_changed_after_preview"]}
            analysis = build_service_catalog_compression_draft(services)
            created_service_ids: list[str] = []
            archived_service_ids: list[str] = []
            for group in analysis.get("groups") or []:
                if str(group.get("action") or "") not in {"apply", "promotion"}:
                    continue
                source_ids = [str(item) for item in group.get("source_service_ids") or [] if str(item)]
                if not source_ids:
                    continue
                cursor.execute(
                    "SELECT id FROM userservices WHERE business_id = %s AND id = ANY(%s) AND COALESCE(is_active, TRUE)",
                    (business_id, source_ids),
                )
                found_ids = [str(dict(item).get("id") or "") for item in (cursor.fetchall() or [])]
                if not found_ids:
                    continue
                if str(group.get("action") or "") == "apply":
                    target = group.get("target") if isinstance(group.get("target"), dict) else {}
                    created_id = str(uuid.uuid4())
                    cursor.execute(
                        """
                        INSERT INTO userservices (
                            id, user_id, business_id, category, name, description,
                            keywords, price, is_active, created_at, updated_at
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, TRUE, NOW(), NOW())
                        """,
                        (
                            created_id,
                            user_id,
                            business_id,
                            str(target.get("category") or "Общие услуги"),
                            str(target.get("name") or group.get("title") or "Объединённая услуга"),
                            str(target.get("description") or ""),
                            json.dumps(target.get("keywords") or [], ensure_ascii=False),
                            str(target.get("price") or ""),
                        ),
                    )
                    created_service_ids.append(created_id)
                cursor.execute(
                    "UPDATE userservices SET is_active = FALSE, updated_at = NOW() WHERE business_id = %s AND id = ANY(%s)",
                    (business_id, found_ids),
                )
                archived_service_ids.extend(found_ids)
            return {
                "status": "completed",
                "capability": "services.compress",
                "created_count": len(created_service_ids),
                "archived_count": len(set(archived_service_ids)),
                "external_writes_performed": False,
            }

        def service_active_state_executor(envelope: dict, targets: list[str], _scope: dict):
            business_id = str(envelope.get("business_id") or "")
            service_id = str(envelope.get("service_id") or "")
            expected_active = bool(envelope.get("expected_active"))
            if len(targets) != 1 or targets[0] != business_id or not service_id:
                return {"status": "blocked", "blocked_reasons": ["service_preview_changed"]}
            cursor.execute(
                """
                UPDATE userservices
                SET is_active = %s, updated_at = NOW()
                WHERE id = %s AND business_id = %s AND COALESCE(is_active, TRUE) = %s
                RETURNING id, is_active
                """,
                (not expected_active, service_id, business_id, expected_active),
            )
            updated = cursor.fetchone()
            if not updated:
                return {"status": "blocked", "blocked_reasons": ["service_state_changed"]}
            return {
                "status": "completed",
                "capability": "services.archive" if expected_active else "services.restore",
                "service_id": service_id,
                "is_active": not expected_active,
                "external_writes_performed": False,
            }

        def agent_run_executor(envelope: dict, targets: list[str], _scope: dict):
            business_id = str(envelope.get("business_id") or "")
            if targets != [business_id]:
                return {"status": "blocked", "blocked_reasons": ["agent_preview_changed"]}
            from services.operator_agent_runs import execute_mobile
            return execute_mobile(cursor, business_id=business_id, user_id=user_id, envelope=envelope,
                actor_context=user_data)

        def agent_lifecycle_executor(envelope: dict, targets: list[str], _scope: dict):
            business_id = str(envelope.get("business_id") or "")
            if targets != [business_id]:
                return {"status": "blocked", "blocked_reasons": ["agent_preview_changed"]}
            from services.operator_agent_management import execute_lifecycle
            return execute_lifecycle(cursor, business_id=business_id, user_id=user_id,
                                     envelope=envelope, actor_context=user_data)

        result, idempotent = confirm_mobile_action(
            cursor,
            action_id=action_id,
            user_id=user_id,
            scope_resolver=scope_resolver,
            target_authorizer=target_authorizer,
            executors={
                "review_replies.generate": generate_executor,
                "finance.sales_import": finance_sales_executor,
                "finance.transaction.delete": finance_transaction_delete_executor,
                "partnerships.lead.delete": partnership_delete_executor,
                "partnerships.leads.bulk_delete": partnership_delete_executor,
                "partnerships.draft.delete": partnership_draft_delete_executor,
                "community_sources.unsubscribe": community_source_unsubscribe_executor,
                "cards.schedule.update": card_schedule_executor,
                "cards.refresh": card_refresh_executor,
                "diagnostics.retry": diagnostic_retry_executor,
                "content.plan.generate": content_plan_generate_executor,
                "content.plan.delete": content_plan_delete_executor,
                "content.item.generate": content_item_generate_executor,
                "content.item.delete": content_item_delete_executor,
                "services.archive": service_active_state_executor,
                "services.restore": service_active_state_executor,
                "services.optimize": services_optimize_executor,
                "services.compress": services_compress_executor,
                "agents.run": agent_run_executor,
                "agents.lifecycle": agent_lifecycle_executor,
            },
        )
        if result.get("status") == "blocked":
            db.conn.rollback()
            return jsonify({"success": False, "error": "Действие не выполнено", "operator_result": result}), 400
        db.conn.commit()
        return jsonify({"success": True, "idempotent": idempotent, "operator_result": result})
    except Exception:
        db.conn.rollback()
        raise
    finally:
        db.close()


@operator_bp.route("/mobile/jobs", methods=["GET"])
def operator_mobile_jobs():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        payload = list_operator_async_jobs(
            cursor,
            user_id=str(user_data.get("user_id") or user_data.get("id") or ""),
            scope=scope,
            is_superadmin=bool(user_data.get("is_superadmin")),
            status=str(request.args.get("status") or ""),
            cursor_value=str(request.args.get("cursor") or ""),
            limit=int(request.args.get("limit") or 25),
        )
        return jsonify({"success": True, **payload})
    finally:
        db.close()


@operator_bp.route("/mobile/jobs/<job_id>", methods=["GET"])
def operator_mobile_job_status(job_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        job = load_operator_async_job(
            cursor,
            job_id=job_id,
            user_id=user_id,
            scope=scope,
            is_superadmin=bool(user_data.get("is_superadmin")),
        )
        if not job:
            job = load_mobile_job(
                cursor,
                job_id=job_id,
                user_id=user_id,
                scope=scope,
            )
        if not job:
            return jsonify({"success": False, "error": "Задача не найдена или недоступна"}), 404
        return jsonify({"success": True, "job": job})
    finally:
        db.close()


@operator_bp.route("/mobile/jobs/<job_id>/retry", methods=["POST"])
def operator_mobile_job_retry(job_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        job = retry_operator_async_job(
            cursor,
            job_id=job_id,
            user_id=str(user_data.get("user_id") or user_data.get("id") or ""),
            scope=scope,
            is_superadmin=bool(user_data.get("is_superadmin")),
        )
        if not job:
            return jsonify({"success": False, "error": "Задача не найдена или недоступна"}), 404
        if job.get("blocked_reason"):
            return jsonify({"success": False, "error": "Повтор недоступен", "job": job}), 409
        db.conn.commit()
        return jsonify({"success": True, "job": job})
    except Exception:
        db.conn.rollback()
        raise
    finally:
        db.close()


@operator_bp.route("/mobile/jobs/<job_id>/cancel", methods=["POST"])
def operator_mobile_job_cancel(job_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        job = cancel_operator_async_job(
            cursor,
            job_id=job_id,
            user_id=str(user_data.get("user_id") or user_data.get("id") or ""),
            scope=scope,
            is_superadmin=bool(user_data.get("is_superadmin")),
        )
        if not job:
            return jsonify({"success": False, "error": "Задача не найдена или недоступна"}), 404
        if job.get("blocked_reason"):
            return jsonify({"success": False, "error": "Остановить задачу нельзя", "job": job}), 409
        db.conn.commit()
        return jsonify({"success": True, "job": job})
    except Exception:
        db.conn.rollback()
        raise
    finally:
        db.close()


@operator_bp.route("/mobile/review-drafts/<draft_id>", methods=["PUT"])
def operator_mobile_review_draft_update(draft_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    payload = request.get_json(silent=True) or {}
    reply_text = str(payload.get("reply_text") or "").strip()
    if not reply_text:
        return jsonify({"success": False, "error": "Текст ответа не может быть пустым"}), 400
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        scope = resolve_control_scope(
            cursor,
            user_id=user_id,
            requested_kind=str(payload.get("scope_type") or ""),
            requested_id=str(payload.get("scope_id") or "") or None,
        )
        cursor.execute("SELECT business_id FROM reviewreplydrafts WHERE id = %s", (draft_id,))
        row = cursor.fetchone()
        business_id = str((dict(row) if row else {}).get("business_id") or "")
        if not scope or (scope.get("kind") != "platform" and business_id not in [str(item) for item in scope.get("business_ids") or []]):
            return jsonify({"success": False, "error": "Черновик недоступен"}), 403
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            return jsonify({"success": False, "error": "Нет доступа" if owner_id else "Черновик не найден"}), 403 if owner_id else 404
        access = _scope_capability_access(cursor, scope, "maps.reviews", bool(user_data.get("is_superadmin")))
        if not access.get("allowed"):
            return _mobile_payment_required_response(access)
        cursor.execute(
            """
            UPDATE reviewreplydrafts
            SET edited_text = %s, status = 'edited', updated_at = NOW()
            WHERE id = %s AND business_id = %s
            RETURNING id, review_id, edited_text, status, updated_at
            """,
            (reply_text, draft_id, business_id),
        )
        updated = dict(cursor.fetchone() or {})
        db.conn.commit()
        return jsonify({"success": True, "draft": updated})
    except Exception:
        db.conn.rollback()
        raise
    finally:
        db.close()


@operator_bp.route("/mobile/review-drafts/<draft_id>/mark-manual-published", methods=["POST"])
def operator_mobile_review_draft_manual_publish(draft_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    payload = request.get_json(silent=True) or {}
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        scope = resolve_control_scope(
            cursor,
            user_id=user_id,
            requested_kind=str(payload.get("scope_type") or ""),
            requested_id=str(payload.get("scope_id") or "") or None,
        )
        cursor.execute("SELECT business_id FROM reviewreplydrafts WHERE id = %s", (draft_id,))
        row = cursor.fetchone()
        business_id = str((dict(row) if row else {}).get("business_id") or "")
        if not scope or (scope.get("kind") != "platform" and business_id not in [str(item) for item in scope.get("business_ids") or []]):
            return jsonify({"success": False, "error": "Черновик недоступен"}), 403
        has_access, _owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            return jsonify({"success": False, "error": "Черновик недоступен"}), 403
        access = _scope_capability_access(cursor, scope, "maps.reviews", bool(user_data.get("is_superadmin")))
        if not access.get("allowed"):
            return _mobile_payment_required_response(access)
        result = mark_review_reply_draft_manual_published(
            cursor,
            business_id=business_id,
            user_id=user_id,
            draft_id=draft_id,
        )
        if result.get("status") != "completed":
            db.conn.rollback()
            return jsonify({"success": False, "error": "Не удалось отметить публикацию", "manual_publish": result}), 400
        db.conn.commit()
        return jsonify({"success": True, "manual_publish": result})
    except Exception:
        db.conn.rollback()
        raise
    finally:
        db.close()


@operator_bp.route("/mobile/operator/history", methods=["GET"])
def operator_mobile_history():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        scope = _resolve_mobile_scope(cursor, user_data)
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        access = _scope_capability_access(cursor, scope, "operator", bool(user_data.get("is_superadmin")))
        if not access.get("allowed"):
            return _mobile_payment_required_response(access)
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        if scope.get("kind") != "business":
            limit = max(1, min(int(request.args.get("limit") or 100), 200))
            platform = scope.get("kind") == "platform"
            business_ids = [str(item) for item in scope.get("business_ids") or []]
            cursor.execute(
                """
                SELECT message.id, message.role, message.content, message.capability,
                       message.status, message.result_json, message.created_at,
                       message.business_id, business.name AS business_name
                FROM operatormessages message
                JOIN operatorconversations conversation ON conversation.id = message.conversation_id
                LEFT JOIN businesses business ON business.id = message.business_id
                WHERE message.user_id = %s
                  AND conversation.channel = 'telegram_mini_app'
                  AND (%s OR message.business_id = ANY(%s))
                ORDER BY message.created_at DESC
                LIMIT %s
                """,
                (user_id, platform, business_ids, limit),
            )
            items = [dict(item) for item in (cursor.fetchall() or [])]
            items.reverse()
            return jsonify({
                "success": True,
                "scope": scope,
                "conversation": None,
                "items": items,
                "counts": {"total": len(items)},
                "cursor": None,
                "as_of": datetime.now(timezone.utc).isoformat(),
                "freshness": {"status": "live"},
                "data_warnings": [],
                "available_actions": [{"key": "select_business", "label": "Выбрать точку для поручения"}],
                "requires_business_selection": True,
            })
        business_id = str(scope.get("id") or "")
        conversation = find_latest_operator_conversation(
            cursor,
            business_id=business_id,
            user_id=user_id,
            channel="telegram_mini_app",
        )
        conversation_id = str(conversation.get("id") or "")
        items = list_operator_messages(
            cursor,
            conversation_id=conversation_id,
            business_id=business_id,
            limit=request.args.get("limit") or 100,
        ) if conversation_id else []
        return jsonify({
            "success": True,
            "scope": scope,
            "conversation": conversation or None,
            "items": items,
            "counts": {"total": len(items)},
            "cursor": None,
            "as_of": datetime.now(timezone.utc).isoformat(),
            "freshness": {"status": "live"},
            "data_warnings": [],
            "available_actions": [{"key": "send_message", "label": "Поручить LocalOS"}],
        })
    finally:
        db.close()


@operator_bp.route("/mobile/reviews/<review_id>/generate", methods=["POST"])
def operator_mobile_review_reply_generate(review_id: str):
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401
    payload = request.get_json(silent=True) or {}
    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        user_id = str(user_data.get("user_id") or user_data.get("id") or "")
        scope = resolve_control_scope(
            cursor,
            user_id=user_id,
            requested_kind=str(payload.get("scope_type") or ""),
            requested_id=str(payload.get("scope_id") or "") or None,
        )
        if not scope:
            return jsonify({"success": False, "error": "Раздел недоступен"}), 403
        access = _scope_capability_access(cursor, scope, "maps.reviews", bool(user_data.get("is_superadmin")))
        if not access.get("allowed"):
            return _mobile_payment_required_response(access)
        cursor.execute("SELECT business_id FROM externalbusinessreviews WHERE id = %s", (review_id,))
        row = cursor.fetchone()
        business_id = str((dict(row) if row else {}).get("business_id") or "")
        targets = [str(item) for item in scope.get("business_ids") or []]
        if scope.get("kind") != "platform" and business_id not in targets:
            return jsonify({"success": False, "error": "Отзыв недоступен"}), 403
        has_access, _owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            return jsonify({"success": False, "error": "Отзыв недоступен"}), 403
        if not bool(payload.get("confirmed")):
            return jsonify({"success": True, "preview": {
                "action_key": "review_reply_generate",
                "scope": scope,
                "business_ids": [business_id],
                "changes": [{"review_id": review_id, "operation": "create_reply_draft"}],
                "estimated_credits": 1,
                "external_effects": False,
                "confirmation_required": True,
                "idempotency_key": f"mobile:{user_id}:review_reply_generate:{review_id}",
            }})
        result = generate_review_reply_drafts_for_unanswered_reviews(
            cursor,
            business_id=business_id,
            user_id=user_id,
            limit=1,
            review_id=review_id,
            channel="telegram_mini_app",
        )
        db.conn.commit()
        return jsonify({"success": str(result.get("status") or "") == "completed", "operator_result": result})
    except Exception:
        db.conn.rollback()
        raise
    finally:
        db.close()


@operator_bp.route("/events", methods=["GET"])
def operator_events():
    user_data = require_auth_from_request()
    if not user_data:
        return jsonify({"success": False, "error": "Требуется авторизация"}), 401

    business_id = str(request.args.get("business_id") or "").strip()
    if not business_id:
        return jsonify({"success": False, "error": "business_id обязателен"}), 400

    db = DatabaseManager()
    cursor = db.conn.cursor()
    try:
        has_access, owner_id = verify_business_access(cursor, business_id, user_data)
        if not has_access:
            status_code = 403 if owner_id else 404
            message = "Нет доступа" if owner_id else "Бизнес не найден"
            return jsonify({"success": False, "error": message}), status_code

        events = list_operator_events(cursor, business_id=business_id, limit=request.args.get("limit") or 20)
        return jsonify({"success": True, "events": events})
    except Exception:
        return jsonify({"success": False, "error": str(sys.exc_info()[1])}), 500
    finally:
        db.close()

# Voice extends the same Operator API and authentication surface.
from api.operator_audio_api import register_audio_routes
register_audio_routes(operator_bp)
from api.operator_workday_api import register_workday_routes
register_workday_routes(operator_bp)

from api.operator_input_settings_api import register_input_settings_routes
register_input_settings_routes(operator_bp)
from api.business_member_directory_api import register_member_directory_routes
register_member_directory_routes(operator_bp)
from api.business_management_api import register_business_management_routes
register_business_management_routes(operator_bp)
